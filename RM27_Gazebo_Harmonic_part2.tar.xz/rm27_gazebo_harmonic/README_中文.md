# RM27 Gazebo Harmonic 场景包

## 可以直接做什么

这是已完成格式转换的独立场景包，不需要先打开 Blender。目标是 Gazebo Harmonic（Gazebo Sim 8 / Ogre2），不是 Gazebo Classic。

附件分为两个压缩包，两份都要解压到同一个目录，文件会合并为 rm27_gazebo_harmonic/；不需要拼接文件。请勿只解压其中一份。

```bash
tar -xJf RM27_Gazebo_Harmonic_part1.tar.xz
tar -xJf RM27_Gazebo_Harmonic_part2.tar.xz
cd rm27_gazebo_harmonic
```

解压后，在已安装 Gazebo Harmonic 的 Linux 终端进入本目录：

```bash
bash scripts/run_scene.sh -r
```

脚本只为当前进程设置场景资源路径。若只检查无界面加载：

```bash
bash scripts/check_runtime.sh
```

后一个脚本先调用 Gazebo 自带的 SDF 校验，再启动无界面服务器；需要可用的 Ogre2/EGL 环境，按 Ctrl+C 停止。它不会自动安装软件，不会改系统配置。

## 转换内容

- 185 个源可视对象完整保留：111 个网格实例复用 85 份带材质的 Collada（.dae）文件，另有 74 个原生 box。
- 607 个源碰撞代理完整保留：574 个网格实例复用 548 份小型闭合 STL 凸包，另有 33 个原生 box。
- model.sdf、model.config、独立 world、启动/校验脚本和可选导航仓库接入脚本已包含。
- 可视网格从上次已检查的 Blender 4.3.2 工程提取。材质保留源 RGBA，以及该工程的粗糙度和金属度；Collada 中也带基础颜色。
- 摄影台、背景地板、相机和摄影灯没有作为碰撞物或可视障碍导出。world 只有照明用太阳，不增加场外地面。
- 不简化、拉伸或改造场地布局。可视几何约 154 万三角面，首次加载和 GPU 占用可能较高。

## 坐标与地图：必须注意

所有坐标为米，Z 轴向上；保留 RM27 源坐标，场景整体 pose 为 0 0 0 0 0 0。场地地面顶面 z=0，碰撞地面大小为 29.05 × 16.05 米。没有照搬旧场景的 z=1.65。

- 可视范围约：x [-14.901, 14.861]，y [-8.025, 8.025]，z [-0.200, 3.486] 米。
- 碰撞范围：x [-14.525, 14.525]，y [-8.025, 8.025]，z [-0.200, 2.747] 米。
- 目标导航仓库现有地图覆盖 y [-5.86, 9.14]，与新场地范围不同。不能把换场景视为旧导航地图已对齐。

推荐先加载独立场景；随后使用仓库原机器人与手动控制检查碰撞、坡道、隧道、雷达。自动导航必须另行生成或核实与新场景同坐标的栅格地图、点云地图和高程图。

可选接入步骤见 [integration/README_zh.md](integration/README_zh.md)。脚本默认仅预览，真正应用时只新增独立 world 键及资源，不覆盖原有默认，不改导航算法、传感器配置或真值里程计开关。机器人出生点需要明确提供，不直接复用旧点。

## 验证到什么程度

已完成：

1. 185 个可视对象与 Blender/源模型逐对象核对，包围盒或变换最大差异 < 0.9 微米。
2. 导出 SDF、Collada、STL 的 XML、资源路径、索引、数值、法线、材质绑定及包围盒离线校验。
3. 548 份碰撞网格闭合且体积为正；607 个代理保留分离语义，没有把整场或多个分离障碍合成一个凸包。
4. 所有 633 份网格通过独立 Assimp 导入器解析。
5. 目标导航仓库的启动入口、场景配置、出生点配置、地图和高程文件已作只读审计。

未完成：此制作环境没有 Gazebo、libsdformat 或 ROS 2。因此没有实际执行 Gazebo 加载、官方 SDF schema 校验、Ogre2 画面、GPU LiDAR 测量、机器人接地或导航测试。离线检查通过不等于运行验收通过。

源可视模型包含 190 个近零面积三角形；为保持几何忠实，没有擅自清理。独立解析通过，但仍需观察真实 Gazebo 加载日志。

详细结果见 [checks/static_validation.json](checks/static_validation.json)、[checks/conversion_audit.json](checks/conversion_audit.json) 和 [docs/navigation_alignment.md](docs/navigation_alignment.md)。

## 碰撞与外观说明

MuJoCo 对每个 mesh 使用其凸包参与碰撞，因此转换对每个原始碰撞代理独立取完整顶点集合的凸包；不使用可视大网格代替碰撞，不合并不同代理，也不做新的近似分解。少量 STL 的面片拓扑与原 MSH 不同，接触轮廓取自原代理凸包。

Gazebo 与 MuJoCo 物理求解器不同。滑动摩擦写入 mu=mu2=0.8，但扭转/滚动摩擦及 solref/solimp 没有冒充为精确等价参数。world 采用目标仓库使用的 DART/Bullet 组合；运行中仍需检查轮子、缝隙和坡道接触。

GPU LiDAR 使用渲染几何，因此完整保留源可视障碍，并设为不透明、双面材质。不能仅凭碰撞模型存在就断言 LiDAR 一定可见，真实传感器输出仍需验收。

Gazebo Ogre2 与 Blender Cycles 的光照、色彩管理和材质实现不同。本包迁移几何与基础材质，不承诺与此前 Cycles 图片逐像素相同。

## 来源与复现

场景来源：

https://github.com/CosmosMount/rm_mjcf/tree/38230a17573816c6a46cb75c1e35a9308af0b12f/rm27_battlefield_mjcf

源提交：38230a17573816c6a46cb75c1e35a9308af0b12f。

目标导航仓库：

https://github.com/PnX-HKUSTGZ/sentry_navgation_RM27/tree/b55a9d22b677f37409b60af19c8e80a6d980fdc4

核对分支为 replace_gicp（下划线），提交 b55a9d22b677f37409b60af19c8e80a6d980fdc4。

源仓库及原始资产的权利仍属于各自权利人。此包不改变或另行授予原资产许可。

重新生成需要上次 rm27_preview.blend、上述固定提交的 model.xml 及引用资产、Blender 4.3.2、Python 3 + numpy + scipy：

```bash
blender -b /path/to/rm27_preview.blend --python scripts/export_blender_visuals.py -- --out /tmp/rm27_visuals
python3 scripts/build_gazebo_scene.py --source /path/to/rm_mjcf/rm27_battlefield_mjcf/model.xml --blender-export /tmp/rm27_visuals --out /path/to/new_output
python3 scripts/validate_scene.py --package /path/to/new_output --source /path/to/rm_mjcf/rm27_battlefield_mjcf/model.xml
```

离线复核现成包只需要 Python 3 + numpy；若已有 Assimp，校验脚本会额外导入检查。包内没有包含整份 Blender 工程，也不会自动下载依赖。
