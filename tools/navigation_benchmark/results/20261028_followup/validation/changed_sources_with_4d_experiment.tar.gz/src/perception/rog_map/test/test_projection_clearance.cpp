#include <gtest/gtest.h>

#include <cmath>
#include <filesystem>
#include <fstream>
#include <initializer_list>
#include <memory>
#include <vector>

#include <rog_map/prior_map.hpp>
#include <rog_map/projection_layer.hpp>
#include <rog_map/projection_ground_reference.hpp>
#include <rog_map/query_adapter.hpp>

namespace {

TEST(ProjectionGroundReference, TiltedLidarOnLevelChassisRemainsLevel) {
  auto config = rog_map::ProjectionLayerConfig{};
  config.robot_origin_to_ground = 0.21;
  config.max_ground_slope_deg = 28.0;
  const Eigen::Vector3d mount(std::acos(-1.0) / 6.0, 0.0, 0.0);
  const Eigen::Quaterniond sensor(
      Eigen::AngleAxisd(mount.x(), Eigen::Vector3d::UnitX()));
  rog_map::setProjectionRobotPose(config, {1.0, 2.126, 0.21}, sensor, mount,
                                 {0.0, -0.126}, true);
  ASSERT_TRUE(config.reference_ground_plane_valid);
  EXPECT_NEAR(config.reference_ground_slope_x, 0.0, 1.0e-12);
  EXPECT_NEAR(config.reference_ground_slope_y, 0.0, 1.0e-12);
  EXPECT_NEAR(config.reference_ground_z_abs, 0.0, 1.0e-12);
  EXPECT_NEAR(config.robot_x, 1.0, 1.0e-12);
  EXPECT_NEAR(config.robot_y, 2.0, 1.0e-12);
}

TEST(ProjectionGroundReference, PreservesRealSlopeAndYawWithCompoundMount) {
  auto config = rog_map::ProjectionLayerConfig{};
  config.robot_origin_to_ground = 0.21;
  config.max_ground_slope_deg = 28.0;
  const double pi = std::acos(-1.0);
  const Eigen::Vector3d mount(pi / 6.0, 0.05, -0.2);
  const Eigen::Quaterniond body =
      Eigen::AngleAxisd(pi / 2.0, Eigen::Vector3d::UnitZ()) *
      Eigen::AngleAxisd(-0.15, Eigen::Vector3d::UnitY());
  const Eigen::Quaterniond mounting =
      Eigen::AngleAxisd(mount.z(), Eigen::Vector3d::UnitZ()) *
      Eigen::AngleAxisd(mount.y(), Eigen::Vector3d::UnitY()) *
      Eigen::AngleAxisd(mount.x(), Eigen::Vector3d::UnitX());
  rog_map::setProjectionRobotPose(config, {1.126, 2.0, 0.21}, body * mounting,
                                 mount, {0.0, -0.126}, true);
  ASSERT_TRUE(config.reference_ground_plane_valid);
  EXPECT_NEAR(config.robot_yaw, pi / 2.0, 1.0e-12);
  EXPECT_NEAR(config.robot_x, 1.252, 1.0e-12);
  EXPECT_NEAR(config.robot_y, 2.0, 1.0e-12);
  EXPECT_NEAR(config.reference_ground_slope_x, 0.0, 1.0e-12);
  EXPECT_NEAR(config.reference_ground_slope_y, std::tan(0.15), 1.0e-12);
}

TEST(ProjectionGroundReference, UncompensatedMountExceedsTerrainLimit) {
  auto config = rog_map::ProjectionLayerConfig{};
  config.robot_origin_to_ground = 0.21;
  config.max_ground_slope_deg = 28.0;
  const Eigen::Quaterniond sensor(Eigen::AngleAxisd(
      std::acos(-1.0) / 6.0, Eigen::Vector3d::UnitX()));
  rog_map::setProjectionRobotPose(config, {0.0, 0.126, 0.21}, sensor,
                                 Eigen::Vector3d::Zero(), {0.0, -0.126}, true);
  EXPECT_FALSE(config.reference_ground_plane_valid);
}

constexpr int kWidth = 5;
constexpr int kHeight = 5;
constexpr double kResolution = 0.10;
const Eigen::Vector2d kOrigin(0.0, 0.0);

rog_map::ProjectionLayerConfig clearanceConfig() {
  rog_map::ProjectionLayerConfig config;
  config.clearance_check_en = true;
  config.unknown_as_occupied = true;
  config.min_observed_voxels = 1;
  config.surface_height_delta_max = 0.10;
  config.vehicle_height = 0.30;
  config.headroom_margin = 0.05;
  config.body_bottom_clearance = 0.02;
  config.ground_seed_tolerance = 0.06;
  config.max_ground_height_delta = 0.35;
  config.max_ground_step = 0.05;
  config.max_ground_slope_deg = 28.0;
  config.ground_seed_radius = 0.18;
  config.min_headroom_known_ratio = 0.50;
  config.clearance_unknown_as_occupied = true;
  config.robot_x = 0.25;
  config.robot_y = 0.25;
  config.reference_ground_z_abs = 0.05;
  config.hysteresis_en = false;
  config.obstacle_hold_time = 0.0;
  config.mask_filter_en = false;
  return config;
}

rog_map::ColumnStats column(std::initializer_list<int> occupied_indices) {
  rog_map::ColumnStats stats;
  stats.scan_z_index_min = 0;
  stats.scan_z_min_abs = -0.10;
  stats.vertical_states.assign(11U, rog_map::VerticalVoxelState::KNOWN_FREE);
  stats.observed_count = static_cast<int>(stats.vertical_states.size());
  for (const int index : occupied_indices) {
    stats.vertical_states.at(static_cast<size_t>(index)) =
        rog_map::VerticalVoxelState::OCCUPIED;
    ++stats.occupied_count;
    stats.occupied_z_index_min = std::min(stats.occupied_z_index_min, index);
    stats.occupied_z_index_max = std::max(stats.occupied_z_index_max, index);
    const double z =
        stats.scan_z_min_abs + static_cast<double>(index) * kResolution;
    stats.occupied_z_min_abs = std::min(stats.occupied_z_min_abs, z);
    stats.occupied_z_max_abs = std::max(stats.occupied_z_max_abs, z);
  }
  return stats;
}

rog_map::ColumnStats groundColumn(double ground_z, double resolution) {
  rog_map::ColumnStats stats;
  stats.scan_z_index_min = 0;
  stats.scan_z_min_abs = -0.5 * resolution;
  stats.vertical_states.assign(40U, rog_map::VerticalVoxelState::KNOWN_FREE);
  stats.observed_count = static_cast<int>(stats.vertical_states.size());
  const int index = static_cast<int>(std::llround(ground_z / resolution));
  stats.vertical_states.at(static_cast<size_t>(index)) =
      rog_map::VerticalVoxelState::OCCUPIED;
  stats.occupied_count = 1;
  stats.occupied_z_index_min = index;
  stats.occupied_z_index_max = index;
  const double occupied_z =
      stats.scan_z_min_abs + static_cast<double>(index) * resolution;
  stats.occupied_z_min_abs = occupied_z;
  stats.occupied_z_max_abs = occupied_z;
  return stats;
}

rog_map::ColumnStats emptyColumn(double resolution,
                                 bool body_volume_known = true) {
  rog_map::ColumnStats stats;
  stats.scan_z_index_min = 0;
  stats.scan_z_min_abs = -0.5 * resolution;
  stats.vertical_states.assign(
      40U, body_volume_known ? rog_map::VerticalVoxelState::KNOWN_FREE
                             : rog_map::VerticalVoxelState::UNKNOWN);
  if (!body_volume_known) {
    stats.vertical_states.back() = rog_map::VerticalVoxelState::KNOWN_FREE;
    stats.observed_count = 1;
  } else {
    stats.observed_count = static_cast<int>(stats.vertical_states.size());
  }
  return stats;
}

const rog_map::CellData &center(const rog_map::ProjectionLayer &layer) {
  return layer.cells().at(2U * kWidth + 2U);
}

rog_map::ProjectionLayerConfig requiredSupportConfig() {
  auto config = clearanceConfig();
  config.require_ground_support = true;
  config.ground_support_tolerance = 0.051;
  config.observed_empty_as_free = false;
  return config;
}

void attachSupport(rog_map::ColumnStats &stats, double support_z,
                   bool known_free = true, bool support_known = true) {
  stats.prior_known_free = known_free ? 1U : 0U;
  stats.ground_support_known = support_known ? 1U : 0U;
  stats.ground_support_z_abs = support_z;
}

TEST(ProjectionClearance, AcceptsThinOverheadWithKnownBodyClearance) {
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.observed_empty_as_free = true;
  config.clear_robot_footprint_unknown = true;
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               [](int, int) { return column({6}); });

  EXPECT_EQ(center(layer).type, rog_map::CellType::PASSABLE);
  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::OVERHEAD_CLEARANCE_OK);
  EXPECT_EQ(center(layer).ground_verified, 0U);
  EXPECT_EQ(center(layer).clearance_verified, 1U);
  EXPECT_EQ(center(layer).traversable, 1U);
  EXPECT_FLOAT_EQ(center(layer).headroom_known_ratio, 1.0F);
}

TEST(ProjectionClearance, ConservativeVoxelBoundariesRejectMarginalGap) {
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               [](int, int) { return column({1, 5}); });

  EXPECT_EQ(center(layer).type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::HEADROOM_BLOCKED);
  EXPECT_NEAR(center(layer).headroom, 0.30F, 1.0e-5F);
}

TEST(ProjectionClearance, CenterEstimateAcceptsQuantizedSimulatedGap) {
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.headroom_voxel_inset_fraction = 0.0;
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               [](int, int) { return column({1, 5}); });

  EXPECT_EQ(center(layer).type, rog_map::CellType::PASSABLE);
  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::CLEARANCE_OK);
  EXPECT_NEAR(center(layer).headroom, 0.40F, 1.0e-5F);
}

TEST(ProjectionClearance, CenterEstimateStillRejectsLowCeiling) {
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.headroom_voxel_inset_fraction = 0.0;
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               [](int, int) { return column({1, 4}); });

  EXPECT_EQ(center(layer).type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::HEADROOM_BLOCKED);
}

TEST(GroundSupportProjection, IsolatedPlateCannotSelfSeedWithoutSupport) {
  rog_map::ProjectionLayer layer;
  auto config = requiredSupportConfig();
  config.reference_ground_z_abs = 0.25;
  config.ground_seed_radius = 10.0;
  layer.update(
      kWidth, kHeight, kResolution, kOrigin, 1.0, config, [](int x, int y) {
        auto stats = (x == 2 && y == 2) ? groundColumn(0.25, kResolution)
                                        : emptyColumn(kResolution, false);
        stats.prior_known_free = 1U;
        return stats;
      });

  EXPECT_EQ(center(layer).type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(center(layer).ground_verified, 0U);
  EXPECT_EQ(center(layer).ground_support_verified, 0U);
}

TEST(GroundSupportProjection, PitEmptyWithoutSupportStaysClosed) {
  rog_map::ProjectionLayer layer;
  auto config = requiredSupportConfig();
  config.clear_robot_footprint_unknown = true;
  config.near_field_prior_fill_en = true;
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               [](int, int) {
                 auto stats = emptyColumn(kResolution, true);
                 attachSupport(stats, 0.0, true, false);
                 return stats;
               });

  EXPECT_EQ(center(layer).type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(center(layer).empty_support_verified, 0U);
  EXPECT_EQ(center(layer).near_field_prior_fill_eligible, 0U);
}

TEST(GroundSupportProjection,
     CurrentFootprintBootstrapsOnlyWithMatchingContinuousSupport) {
  rog_map::ProjectionLayer layer;
  auto config = requiredSupportConfig();
  config.clear_robot_footprint_unknown = true;
  config.robot_footprint_clear_length = 0.20;
  config.robot_footprint_clear_width = 0.20;
  config.reference_ground_z_abs = 0.0;
  layer.update(
      kWidth, kHeight, kResolution, kOrigin, 1.0, config, [](int, int) {
        rog_map::ColumnStats stats;
        stats.vertical_states.assign(11U, rog_map::VerticalVoxelState::UNKNOWN);
        attachSupport(stats, 0.0);
        return stats;
      });

  EXPECT_EQ(center(layer).type, rog_map::CellType::FREE);
  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::ROBOT_FOOTPRINT_CLEAR);
  EXPECT_EQ(center(layer).ground_support_verified, 1U);
  EXPECT_EQ(center(layer).clearance_verified, 1U);
  const auto &outside = layer.cells().at(2U * kWidth + 4U);
  EXPECT_EQ(outside.type, rog_map::CellType::UNKNOWN);
  EXPECT_EQ(outside.traversable, 0U);
}

TEST(GroundSupportProjection,
     CurrentFootprintRasterizesIntersectingBoundaryCell) {
  rog_map::ProjectionLayer layer;
  auto config = requiredSupportConfig();
  config.clear_robot_footprint_unknown = true;
  config.robot_footprint_clear_length = 0.20;
  config.robot_footprint_clear_width = 0.20;
  config.robot_x = 0.26;
  config.reference_ground_z_abs = 0.0;
  layer.update(
      kWidth, kHeight, kResolution, kOrigin, 1.0, config, [](int, int) {
        rog_map::ColumnStats stats;
        stats.vertical_states.assign(11U, rog_map::VerticalVoxelState::UNKNOWN);
        attachSupport(stats, 0.0);
        return stats;
      });

  // The footprint starts at x=0.16. The x=0.15 cell center is outside the
  // continuous rectangle, but its 0.10 m cell intersects the footprint.
  const auto &boundary = layer.cells().at(2U * kWidth + 1U);
  EXPECT_EQ(boundary.type, rog_map::CellType::FREE);
  EXPECT_EQ(boundary.raw_reason,
            rog_map::ProjectionClassReason::ROBOT_FOOTPRINT_CLEAR);
  const auto &non_intersecting = layer.cells().at(2U * kWidth);
  EXPECT_EQ(non_intersecting.type, rog_map::CellType::UNKNOWN);
}

TEST(GroundSupportProjection,
     CurrentFootprintDoesNotBootstrapAtMismatchedSupportHeight) {
  rog_map::ProjectionLayer layer;
  auto config = requiredSupportConfig();
  config.clear_robot_footprint_unknown = true;
  config.robot_footprint_clear_length = 0.20;
  config.robot_footprint_clear_width = 0.20;
  config.reference_ground_z_abs = 0.20;
  layer.update(
      kWidth, kHeight, kResolution, kOrigin, 1.0, config, [](int, int) {
        rog_map::ColumnStats stats;
        stats.vertical_states.assign(11U, rog_map::VerticalVoxelState::UNKNOWN);
        attachSupport(stats, 0.0);
        return stats;
      });

  EXPECT_EQ(center(layer).type, rog_map::CellType::UNKNOWN);
  EXPECT_EQ(center(layer).ground_support_verified, 0U);
  EXPECT_EQ(center(layer).clearance_verified, 0U);
  EXPECT_EQ(center(layer).traversable, 0U);
}

TEST(GroundSupportProjection,
     CurrentFootprintDoesNotDilateAdjacentSupportDiscontinuity) {
  rog_map::ProjectionLayer layer;
  auto config = requiredSupportConfig();
  config.clear_robot_footprint_unknown = true;
  config.robot_footprint_clear_length = 0.20;
  config.robot_footprint_clear_width = 0.20;
  config.reference_ground_z_abs = 0.0;
  layer.update(
      kWidth, kHeight, kResolution, kOrigin, 1.0, config, [](int x, int) {
        rog_map::ColumnStats stats;
        stats.vertical_states.assign(11U, rog_map::VerticalVoxelState::UNKNOWN);
        attachSupport(stats, x == 3 ? 0.30 : 0.0);
        return stats;
      });

  EXPECT_EQ(center(layer).type, rog_map::CellType::FREE);
  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::ROBOT_FOOTPRINT_CLEAR);
  EXPECT_EQ(center(layer).ground_support_verified, 1U);
  EXPECT_EQ(center(layer).clearance_verified, 1U);
  EXPECT_EQ(center(layer).traversable, 1U);
}

TEST(GroundSupportProjection, CurrentFootprintDoesNotBootstrapIsolatedSupport) {
  rog_map::ProjectionLayer layer;
  auto config = requiredSupportConfig();
  config.clear_robot_footprint_unknown = true;
  config.robot_footprint_clear_length = 0.20;
  config.robot_footprint_clear_width = 0.20;
  config.reference_ground_z_abs = 0.0;
  layer.update(
      kWidth, kHeight, kResolution, kOrigin, 1.0, config, [](int x, int y) {
        rog_map::ColumnStats stats;
        stats.vertical_states.assign(11U, rog_map::VerticalVoxelState::UNKNOWN);
        attachSupport(stats, x == 2 && y == 2 ? 0.0 : 0.30);
        return stats;
      });

  EXPECT_EQ(center(layer).type, rog_map::CellType::UNKNOWN);
  EXPECT_EQ(center(layer).ground_support_verified, 0U);
  EXPECT_EQ(center(layer).clearance_verified, 0U);
  EXPECT_EQ(center(layer).traversable, 0U);
}

TEST(GroundSupportProjection, CurrentFootprintNeverOverridesOccupiedEvidence) {
  rog_map::ProjectionLayer layer;
  auto config = requiredSupportConfig();
  config.clear_robot_footprint_unknown = true;
  config.robot_footprint_clear_length = 0.20;
  config.robot_footprint_clear_width = 0.20;
  config.reference_ground_z_abs = 0.0;
  layer.update(
      kWidth, kHeight, kResolution, kOrigin, 1.0, config, [](int, int) {
        rog_map::ColumnStats stats;
        stats.vertical_states.assign(11U, rog_map::VerticalVoxelState::UNKNOWN);
        stats.vertical_states.at(5U) = rog_map::VerticalVoxelState::OCCUPIED;
        stats.observed_count = 1;
        stats.occupied_count = 1;
        attachSupport(stats, 0.0);
        return stats;
      });

  EXPECT_NE(center(layer).type, rog_map::CellType::FREE);
  EXPECT_EQ(center(layer).ground_support_verified, 0U);
  EXPECT_EQ(center(layer).clearance_verified, 0U);
  EXPECT_EQ(center(layer).traversable, 0U);
}

TEST(GroundSupportProjection,
     CurrentFootprintClearDoesNotWaitForFreeSpaceHysteresis) {
  rog_map::ProjectionLayer layer;
  auto config = requiredSupportConfig();
  config.clear_robot_footprint_unknown = true;
  config.robot_footprint_clear_length = 0.20;
  config.robot_footprint_clear_width = 0.20;
  config.reference_ground_z_abs = 0.0;
  config.hysteresis_en = true;
  config.hysteresis_count = 2;
  config.obstacle_hold_time = 0.0;

  layer.update(
      kWidth, kHeight, kResolution, kOrigin, 1.0, config, [](int, int) {
        rog_map::ColumnStats stats;
        stats.vertical_states.assign(11U, rog_map::VerticalVoxelState::UNKNOWN);
        stats.vertical_states.at(6U) = rog_map::VerticalVoxelState::OCCUPIED;
        stats.observed_count = 1;
        stats.occupied_count = 1;
        attachSupport(stats, 0.0);
        return stats;
      });
  ASSERT_EQ(center(layer).type, rog_map::CellType::OCCUPIED);

  layer.update(
      kWidth, kHeight, kResolution, kOrigin, 2.0, config, [](int, int) {
        rog_map::ColumnStats stats;
        stats.vertical_states.assign(11U, rog_map::VerticalVoxelState::UNKNOWN);
        attachSupport(stats, 0.0);
        return stats;
      });

  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::ROBOT_FOOTPRINT_CLEAR);
  EXPECT_EQ(center(layer).raw_type, rog_map::CellType::FREE);
  EXPECT_EQ(center(layer).type, rog_map::CellType::FREE);
  EXPECT_EQ(center(layer).pending_count, 0U);
}

TEST(GroundSupportProjection, ZeroHitUnknownDoesNotStartMeasuredObstacleHold) {
  rog_map::ProjectionLayer layer;
  auto config = requiredSupportConfig();
  config.clear_robot_footprint_unknown = false;
  config.reference_ground_z_abs = 0.0;
  config.hysteresis_en = false;
  config.obstacle_hold_time = 0.50;

  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               [](int, int) {
                 auto stats = emptyColumn(kResolution, false);
                 attachSupport(stats, 0.0);
                 return stats;
               });
  ASSERT_EQ(center(layer).type, rog_map::CellType::OCCUPIED);
  ASSERT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::HEADROOM_UNVERIFIED);

  config.clear_robot_footprint_unknown = true;
  config.robot_footprint_clear_length = 0.20;
  config.robot_footprint_clear_width = 0.20;
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.10, config,
               [](int, int) {
                 auto stats = emptyColumn(kResolution, false);
                 attachSupport(stats, 0.0);
                 return stats;
               });

  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::ROBOT_FOOTPRINT_CLEAR);
  EXPECT_EQ(center(layer).type, rog_map::CellType::FREE);
}

TEST(GroundSupportProjection, MeasuredObstacleStillUsesConfiguredHold) {
  rog_map::ProjectionLayer layer;
  auto config = requiredSupportConfig();
  config.hysteresis_en = false;
  config.obstacle_hold_time = 0.50;

  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               [](int, int) {
                 auto stats = column({1, 4});
                 attachSupport(stats, 0.05);
                 return stats;
               });
  ASSERT_EQ(center(layer).type, rog_map::CellType::OCCUPIED);
  ASSERT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::HEADROOM_BLOCKED);

  const auto verified_empty = [](int, int) {
    auto stats = emptyColumn(kResolution, true);
    attachSupport(stats, 0.05);
    return stats;
  };
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.10, config,
               verified_empty);
  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::EMPTY_COLUMN);
  EXPECT_EQ(center(layer).type, rog_map::CellType::OCCUPIED);
  EXPECT_GT(center(layer).occupied_clear_deadline, 1.10);

  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.61, config,
               verified_empty);
  EXPECT_EQ(center(layer).type, rog_map::CellType::FREE);
}

TEST(GroundSupportProjection,
     VerifiedEmptyColumnDoesNotWaitForFreeSpaceHysteresis) {
  rog_map::ProjectionLayer layer;
  auto config = requiredSupportConfig();
  config.hysteresis_en = true;
  config.hysteresis_count = 2;
  config.obstacle_hold_time = 0.0;

  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               [](int, int) {
                 auto stats = column({1, 4});
                 attachSupport(stats, 0.05);
                 return stats;
               });
  ASSERT_EQ(center(layer).type, rog_map::CellType::OCCUPIED);

  layer.update(kWidth, kHeight, kResolution, kOrigin, 2.0, config,
               [](int, int) {
                 auto stats = emptyColumn(kResolution, true);
                 attachSupport(stats, 0.05);
                 return stats;
               });

  EXPECT_EQ(center(layer).type, rog_map::CellType::FREE);
  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::EMPTY_COLUMN);
  EXPECT_EQ(center(layer).clearance_verified, 1U);
  EXPECT_EQ(center(layer).pending_count, 0U);
}

TEST(GroundSupportProjection,
     BoundedZeroHitHeadroomDropoutRetainsPriorClearance) {
  rog_map::ProjectionLayer layer;
  auto config = requiredSupportConfig();
  config.clearance_dropout_hold_time = 0.25;

  const auto verified_empty = [](int, int) {
    auto stats = emptyColumn(kResolution, true);
    attachSupport(stats, 0.05);
    return stats;
  };
  const auto zero_hit_dropout = [](int, int) {
    auto stats = emptyColumn(kResolution, false);
    attachSupport(stats, 0.05);
    return stats;
  };

  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               verified_empty);
  ASSERT_EQ(center(layer).type, rog_map::CellType::FREE);
  ASSERT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::EMPTY_COLUMN);

  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.10, config,
               zero_hit_dropout);
  EXPECT_EQ(center(layer).type, rog_map::CellType::FREE);
  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::CLEARANCE_DROPOUT_HOLD);
  EXPECT_EQ(center(layer).clearance_verified, 1U);
  EXPECT_EQ(center(layer).ground_support_verified, 1U);

  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.20, config,
               zero_hit_dropout);
  EXPECT_EQ(center(layer).type, rog_map::CellType::FREE);
  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::CLEARANCE_DROPOUT_HOLD);

  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.36, config,
               zero_hit_dropout);
  EXPECT_EQ(center(layer).type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::HEADROOM_UNVERIFIED);
  EXPECT_EQ(center(layer).clearance_verified, 0U);
}

TEST(GroundSupportProjection,
     ClearanceDropoutHoldNeverOverridesAnOccupiedReturn) {
  rog_map::ProjectionLayer layer;
  auto config = requiredSupportConfig();
  config.clearance_dropout_hold_time = 0.25;
  config.min_observed_overhead_headroom_known_ratio = 0.80;

  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               [](int, int) {
                 auto stats = emptyColumn(kResolution, true);
                 attachSupport(stats, 0.05);
                 return stats;
               });
  ASSERT_EQ(center(layer).type, rog_map::CellType::FREE);

  layer.update(
      kWidth, kHeight, kResolution, kOrigin, 1.10, config, [](int, int) {
        auto stats = column({6});
        std::fill(stats.vertical_states.begin(), stats.vertical_states.end(),
                  rog_map::VerticalVoxelState::UNKNOWN);
        stats.vertical_states.at(6U) = rog_map::VerticalVoxelState::OCCUPIED;
        stats.observed_count = 1;
        attachSupport(stats, 0.05);
        return stats;
      });

  EXPECT_EQ(center(layer).type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::HEADROOM_UNVERIFIED);
  EXPECT_EQ(center(layer).clearance_verified, 0U);
}

TEST(GroundSupportProjection,
     BoundedClearanceHoleFillRequiresOpposingVerifiedEndpoints) {
  rog_map::ProjectionLayer layer;
  auto config = requiredSupportConfig();
  config.clearance_hole_fill_en = true;
  config.clearance_hole_fill_max_width = kResolution;

  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               [](int x, int y) {
                 const bool verified_neighbor = y == 2 && (x == 1 || x == 3);
                 auto stats = emptyColumn(kResolution, verified_neighbor);
                 attachSupport(stats, 0.05);
                 return stats;
               });

  EXPECT_EQ(center(layer).type, rog_map::CellType::FREE);
  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::CLEARANCE_BOUNDED_HOLE_FILL);
  EXPECT_EQ(center(layer).clearance_verified, 1U);
  EXPECT_EQ(center(layer).ground_support_verified, 1U);
}

TEST(GroundSupportProjection, BoundedClearanceHoleFillSupportsTwoCellGap) {
  rog_map::ProjectionLayer layer;
  auto config = requiredSupportConfig();
  config.clearance_hole_fill_en = true;
  config.clearance_hole_fill_max_width = 2.0 * kResolution;

  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               [](int x, int y) {
                 const bool verified_endpoint = y == 2 && (x == 1 || x == 4);
                 auto stats = emptyColumn(kResolution, verified_endpoint);
                 attachSupport(stats, 0.05);
                 return stats;
               });

  const auto &cells = layer.cells();
  EXPECT_EQ(cells.at(2U * kWidth + 2U).type, rog_map::CellType::FREE);
  EXPECT_EQ(cells.at(2U * kWidth + 3U).type, rog_map::CellType::FREE);
  EXPECT_EQ(cells.at(2U * kWidth + 2U).raw_reason,
            rog_map::ProjectionClassReason::CLEARANCE_BOUNDED_HOLE_FILL);
  EXPECT_EQ(cells.at(2U * kWidth + 3U).raw_reason,
            rog_map::ProjectionClassReason::CLEARANCE_BOUNDED_HOLE_FILL);
}

TEST(GroundSupportProjection,
     BoundedClearanceHoleFillDoesNotExceedConfiguredWidth) {
  rog_map::ProjectionLayer layer;
  auto config = requiredSupportConfig();
  config.clearance_hole_fill_en = true;
  config.clearance_hole_fill_max_width = 2.0 * kResolution;

  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               [](int x, int y) {
                 const bool verified_endpoint = y == 2 && (x == 0 || x == 4);
                 auto stats = emptyColumn(kResolution, verified_endpoint);
                 attachSupport(stats, 0.05);
                 return stats;
               });

  EXPECT_EQ(center(layer).type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::HEADROOM_UNVERIFIED);
}

TEST(GroundSupportProjection,
     BoundedClearanceHoleFillNeverOverridesOccupiedReturn) {
  rog_map::ProjectionLayer layer;
  auto config = requiredSupportConfig();
  config.clearance_hole_fill_en = true;
  config.clearance_hole_fill_max_width = 2.0 * kResolution;

  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               [](int x, int y) {
                 if (x == 2 && y == 2) {
                   auto stats = column({1, 4});
                   attachSupport(stats, 0.05);
                   return stats;
                 }
                 const bool verified_neighbor = y == 2 && (x == 1 || x == 3);
                 auto stats = emptyColumn(kResolution, verified_neighbor);
                 attachSupport(stats, 0.05);
                 return stats;
               });

  EXPECT_EQ(center(layer).type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::HEADROOM_BLOCKED);
  EXPECT_EQ(center(layer).clearance_verified, 0U);
}

TEST(GroundSupportProjection, EmptyWithSupportAndObservedBodyIsFree) {
  rog_map::ProjectionLayer layer;
  auto config = requiredSupportConfig();
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               [](int, int) {
                 auto stats = emptyColumn(kResolution, true);
                 attachSupport(stats, 0.0);
                 return stats;
               });

  EXPECT_EQ(center(layer).type, rog_map::CellType::FREE);
  EXPECT_EQ(center(layer).empty_support_verified, 1U);
  EXPECT_EQ(center(layer).clearance_verified, 1U);
}

TEST(GroundSupportProjection, MatchingRampCandidatesAreVerifiedBySurvey) {
  rog_map::ProjectionLayer layer;
  auto config = requiredSupportConfig();
  config.max_ground_height_delta = 0.05;
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               [](int x, int) {
                 const double support_z = 0.05 * static_cast<double>(x);
                 auto stats = groundColumn(support_z, kResolution);
                 attachSupport(stats, support_z);
                 return stats;
               });

  EXPECT_EQ(center(layer).type, rog_map::CellType::PASSABLE);
  EXPECT_EQ(center(layer).ground_verified, 1U);
  EXPECT_EQ(center(layer).ground_support_verified, 1U);
}

TEST(GroundSupportProjection,
     SurveyedVerticalStepDoesNotDilateIntoConnectedSurface) {
  rog_map::ProjectionLayer layer;
  auto config = requiredSupportConfig();
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               [](int x, int) {
                 const double support_z = x < 2 ? 0.0 : 0.20;
                 auto stats = groundColumn(support_z, kResolution);
                 attachSupport(stats, support_z);
                 return stats;
               });

  EXPECT_EQ(center(layer).type, rog_map::CellType::PASSABLE);
  EXPECT_EQ(center(layer).ground_verified, 1U);
  EXPECT_EQ(center(layer).ground_support_verified, 1U);
}

TEST(GroundSupportProjection, IsolatedSurveyedSupportSpikeIsRejected) {
  rog_map::ProjectionLayer layer;
  auto config = requiredSupportConfig();
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               [](int x, int y) {
                 const double support_z = x == 2 && y == 2 ? 0.20 : 0.0;
                 auto stats = groundColumn(support_z, kResolution);
                 attachSupport(stats, support_z);
                 return stats;
               });

  EXPECT_EQ(center(layer).type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(center(layer).ground_verified, 0U);
  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::GROUND_UNVERIFIED);
}

TEST(GroundSupportProjection,
     EmptyColumnBesideStepKeepsConnectedSurveyedSupport) {
  rog_map::ProjectionLayer layer;
  auto config = requiredSupportConfig();
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               [](int x, int) {
                 auto stats = emptyColumn(kResolution, true);
                 attachSupport(stats, x < 2 ? 0.0 : 0.20);
                 return stats;
               });

  EXPECT_EQ(center(layer).type, rog_map::CellType::FREE);
  EXPECT_EQ(center(layer).empty_support_verified, 1U);
  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::EMPTY_COLUMN);
}

TEST(GroundSupportProjection,
     FootprintClearAllowsContinuousSurveyedSlopeAroundRobot) {
  rog_map::ProjectionLayer layer;
  auto config = requiredSupportConfig();
  config.ground_support_tolerance = 0.02;
  config.clear_robot_footprint_unknown = true;
  config.robot_footprint_clear_length = 0.40;
  config.robot_footprint_clear_width = 0.20;
  config.reference_ground_z_abs = 0.0;
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               [](int x, int) {
                 auto stats = emptyColumn(kResolution, false);
                 attachSupport(stats, 0.05 * static_cast<double>(x - 2));
                 return stats;
               });

  const auto &front_footprint = layer.cells().at(2U * kWidth + 4U);
  EXPECT_EQ(front_footprint.type, rog_map::CellType::FREE);
  EXPECT_EQ(front_footprint.raw_reason,
            rog_map::ProjectionClassReason::ROBOT_FOOTPRINT_CLEAR);
  EXPECT_EQ(front_footprint.ground_support_verified, 1U);
  EXPECT_EQ(front_footprint.clearance_verified, 1U);
}

TEST(GroundSupportProjection,
     SurveyedNearFieldClearsZeroHitMotionSweepOutsideFootprint) {
  rog_map::ProjectionLayer layer;
  auto config = requiredSupportConfig();
  config.clear_robot_footprint_unknown = true;
  config.robot_footprint_clear_length = 0.20;
  config.robot_footprint_clear_width = 0.20;
  config.near_field_prior_fill_en = true;
  config.near_field_prior_fill_length = 0.60;
  config.near_field_prior_fill_width = 0.60;
  config.reference_ground_z_abs = 0.0;
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               [](int, int) {
                 auto stats = emptyColumn(kResolution, false);
                 attachSupport(stats, 0.0);
                 return stats;
               });

  const auto &outside_footprint = layer.cells().at(2U * kWidth + 4U);
  EXPECT_EQ(outside_footprint.type, rog_map::CellType::FREE);
  EXPECT_EQ(outside_footprint.raw_reason,
            rog_map::ProjectionClassReason::SURVEYED_NEAR_FIELD_CLEAR);
  EXPECT_EQ(outside_footprint.ground_support_verified, 1U);
  EXPECT_EQ(outside_footprint.clearance_verified, 1U);
}

TEST(GroundSupportProjection,
     SurveyedNearFieldClearsMatchingGroundWhenHeadroomRaysAreMissing) {
  rog_map::ProjectionLayer layer;
  auto config = requiredSupportConfig();
  config.clear_robot_footprint_unknown = true;
  config.robot_footprint_clear_length = 0.20;
  config.robot_footprint_clear_width = 0.20;
  config.near_field_prior_fill_en = true;
  config.near_field_prior_fill_length = 0.60;
  config.near_field_prior_fill_width = 0.60;
  config.reference_ground_z_abs = 0.0;
  layer.update(
      kWidth, kHeight, kResolution, kOrigin, 1.0, config, [](int, int) {
        auto stats = groundColumn(0.0, kResolution);
        std::fill(stats.vertical_states.begin(), stats.vertical_states.end(),
                  rog_map::VerticalVoxelState::UNKNOWN);
        stats.vertical_states.front() = rog_map::VerticalVoxelState::OCCUPIED;
        stats.observed_count = 1;
        attachSupport(stats, 0.0);
        return stats;
      });

  const auto &outside_footprint = layer.cells().at(2U * kWidth + 4U);
  EXPECT_EQ(outside_footprint.type, rog_map::CellType::FREE);
  EXPECT_EQ(outside_footprint.raw_reason,
            rog_map::ProjectionClassReason::SURVEYED_NEAR_FIELD_CLEAR);
  EXPECT_EQ(outside_footprint.ground_verified, 1U);
  EXPECT_EQ(outside_footprint.clearance_verified, 1U);
}

TEST(GroundSupportProjection, SurveyedNearFieldIsFailClosedByDefault) {
  rog_map::ProjectionLayer layer;
  auto config = requiredSupportConfig();
  config.clear_robot_footprint_unknown = true;
  config.robot_footprint_clear_length = 0.20;
  config.robot_footprint_clear_width = 0.20;
  config.near_field_prior_fill_length = 0.60;
  config.near_field_prior_fill_width = 0.60;
  config.reference_ground_z_abs = 0.0;
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               [](int, int) {
                 auto stats = emptyColumn(kResolution, false);
                 attachSupport(stats, 0.0);
                 return stats;
               });

  const auto &outside_footprint = layer.cells().at(2U * kWidth + 4U);
  EXPECT_EQ(outside_footprint.type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(outside_footprint.raw_reason,
            rog_map::ProjectionClassReason::HEADROOM_UNVERIFIED);
}

TEST(GroundSupportProjection,
     SurveyedNearFieldRejectsDiscontinuousSupportAndWrongHeightReturns) {
  auto config = requiredSupportConfig();
  config.clear_robot_footprint_unknown = true;
  config.robot_footprint_clear_length = 0.20;
  config.robot_footprint_clear_width = 0.20;
  config.near_field_prior_fill_en = true;
  config.near_field_prior_fill_length = 0.60;
  config.near_field_prior_fill_width = 0.60;
  config.reference_ground_z_abs = 0.0;

  rog_map::ProjectionLayer step_layer;
  step_layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
                    [](int x, int y) {
                      auto stats = emptyColumn(kResolution, false);
                      attachSupport(stats, x == 4 && y == 2 ? 0.10 : 0.0);
                      return stats;
                    });
  const auto &step = step_layer.cells().at(2U * kWidth + 4U);
  EXPECT_EQ(step.type, rog_map::CellType::OCCUPIED);
  EXPECT_NE(step.raw_reason,
            rog_map::ProjectionClassReason::SURVEYED_NEAR_FIELD_CLEAR);

  rog_map::ProjectionLayer occupied_layer;
  occupied_layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
                        [](int x, int) {
                          if (x != 4) {
                            auto stats = emptyColumn(kResolution, false);
                            attachSupport(stats, 0.0);
                            return stats;
                          }
                          auto stats = groundColumn(0.20, kResolution);
                          attachSupport(stats, 0.0);
                          return stats;
                        });
  const auto &occupied = occupied_layer.cells().at(2U * kWidth + 4U);
  EXPECT_EQ(occupied.type, rog_map::CellType::OCCUPIED);
  EXPECT_NE(occupied.raw_reason,
            rog_map::ProjectionClassReason::SURVEYED_NEAR_FIELD_CLEAR);

  rog_map::ProjectionLayer low_obstacle_layer;
  low_obstacle_layer.update(
      kWidth, kHeight, kResolution, kOrigin, 1.0, config, [](int x, int) {
        if (x != 4) {
          auto stats = emptyColumn(kResolution, false);
          attachSupport(stats, 0.0);
          return stats;
        }
        auto stats = groundColumn(0.0, kResolution);
        stats.vertical_states.at(2U) = rog_map::VerticalVoxelState::OCCUPIED;
        ++stats.observed_count;
        ++stats.occupied_count;
        stats.occupied_z_index_max = 2;
        stats.occupied_z_max_abs = 0.15;
        attachSupport(stats, 0.0);
        return stats;
      });
  const auto &low_obstacle = low_obstacle_layer.cells().at(2U * kWidth + 4U);
  EXPECT_EQ(low_obstacle.type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(low_obstacle.raw_reason,
            rog_map::ProjectionClassReason::HEADROOM_BLOCKED);
}

TEST(GroundSupportProjection, WrongHeightFloatingPlateIsBlocked) {
  rog_map::ProjectionLayer layer;
  auto config = requiredSupportConfig();
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               [](int, int) {
                 auto stats = groundColumn(0.20, kResolution);
                 attachSupport(stats, 0.0);
                 return stats;
               });

  EXPECT_EQ(center(layer).type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::GROUND_UNVERIFIED);
  EXPECT_EQ(center(layer).ground_verified, 0U);
}

TEST(GroundSupportProjection, PriorOccupiedVetoesMatchingCandidate) {
  rog_map::ProjectionLayer layer;
  auto config = requiredSupportConfig();
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               [](int, int) {
                 auto stats = groundColumn(0.0, kResolution);
                 attachSupport(stats, 0.0, false, true);
                 return stats;
               });

  EXPECT_EQ(center(layer).type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(center(layer).ground_verified, 0U);
}

TEST(GroundSupportProjection, DynamicLowObstacleVetoesMatchingGroundSupport) {
  rog_map::ProjectionLayer layer;
  auto config = requiredSupportConfig();
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               [](int, int) {
                 auto stats = column({1, 4});
                 attachSupport(stats, 0.05);
                 return stats;
               });

  EXPECT_EQ(center(layer).type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::HEADROOM_BLOCKED);
  EXPECT_EQ(center(layer).clearance_verified, 0U);
}

TEST(GroundSupportProjection, OverheadUsesLocalSupportAndKnownBodyBand) {
  auto config = requiredSupportConfig();

  rog_map::ProjectionLayer supported_layer;
  supported_layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
                         [](int, int) {
                           auto stats = column({6});
                           attachSupport(stats, 0.05);
                           return stats;
                         });
  EXPECT_EQ(center(supported_layer).type, rog_map::CellType::PASSABLE);
  EXPECT_EQ(center(supported_layer).raw_reason,
            rog_map::ProjectionClassReason::OVERHEAD_CLEARANCE_OK);

  rog_map::ProjectionLayer missing_support_layer;
  missing_support_layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0,
                               config, [](int, int) {
                                 auto stats = column({6});
                                 stats.prior_known_free = 1U;
                                 return stats;
                               });
  EXPECT_EQ(center(missing_support_layer).type, rog_map::CellType::OCCUPIED);

  rog_map::ProjectionLayer unknown_body_layer;
  unknown_body_layer.update(
      kWidth, kHeight, kResolution, kOrigin, 1.0, config, [](int, int) {
        auto stats = column({6});
        std::fill(stats.vertical_states.begin(), stats.vertical_states.end(),
                  rog_map::VerticalVoxelState::UNKNOWN);
        stats.vertical_states.at(6U) = rog_map::VerticalVoxelState::OCCUPIED;
        stats.observed_count = 1;
        attachSupport(stats, 0.05);
        return stats;
      });
  EXPECT_EQ(center(unknown_body_layer).type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(center(unknown_body_layer).raw_reason,
            rog_map::ProjectionClassReason::HEADROOM_UNVERIFIED);
}

TEST(GroundSupportProjection,
     UnsupportedUnknownIsBlockedEvenIfLegacyPolicyIsOpen) {
  rog_map::ProjectionLayer layer;
  auto config = requiredSupportConfig();
  config.unknown_as_occupied = false;
  layer.update(
      kWidth, kHeight, kResolution, kOrigin, 1.0, config, [](int, int) {
        rog_map::ColumnStats stats;
        stats.scan_z_min_abs = -0.5 * kResolution;
        stats.vertical_states.assign(40U, rog_map::VerticalVoxelState::UNKNOWN);
        return stats;
      });

  EXPECT_EQ(center(layer).type, rog_map::CellType::UNKNOWN);
  EXPECT_EQ(center(layer).mask, 0U);
  EXPECT_EQ(center(layer).traversable, 0U);
}

TEST(GroundSupportProjection,
     RequiredGateCannotBeBypassedByDisablingClearance) {
  rog_map::ProjectionLayer layer;
  auto config = requiredSupportConfig();
  config.clearance_check_en = false;
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               [](int, int) {
                 auto stats = groundColumn(0.20, kResolution);
                 attachSupport(stats, 0.0);
                 return stats;
               });

  EXPECT_EQ(center(layer).type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(center(layer).ground_verified, 0U);
  EXPECT_EQ(center(layer).mask, 0U);
}

TEST(ProjectionClearance, RejectsThinOverheadWithoutGroundlessMode) {
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.observed_empty_as_free = false;
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               [](int, int) { return column({6}); });

  EXPECT_EQ(center(layer).type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::GROUND_UNVERIFIED);
  EXPECT_EQ(center(layer).clearance_verified, 0U);
  EXPECT_EQ(center(layer).traversable, 0U);
}

TEST(ProjectionClearance, RejectsThinOverheadWithUnknownBodyBand) {
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.observed_empty_as_free = true;
  layer.update(
      kWidth, kHeight, kResolution, kOrigin, 1.0, config, [](int, int) {
        auto stats = column({6});
        std::fill(stats.vertical_states.begin(), stats.vertical_states.end(),
                  rog_map::VerticalVoxelState::UNKNOWN);
        stats.vertical_states.at(6U) = rog_map::VerticalVoxelState::OCCUPIED;
        stats.observed_count = 1;
        return stats;
      });

  EXPECT_EQ(center(layer).type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::HEADROOM_UNVERIFIED);
  EXPECT_EQ(center(layer).clearance_verified, 0U);
  EXPECT_EQ(center(layer).traversable, 0U);
}

TEST(GroundSupportProjection,
     ObservedOverheadThresholdDoesNotWeakenEmptyColumnGate) {
  rog_map::ProjectionLayer layer;
  auto config = requiredSupportConfig();
  config.min_headroom_known_ratio = 0.80;
  config.min_observed_overhead_headroom_known_ratio = 0.0;
  layer.update(
      kWidth, kHeight, kResolution, kOrigin, 1.0, config, [](int x, int y) {
        auto stats =
            x == 2 && y == 2 ? column({6}) : emptyColumn(kResolution, false);
        if (x == 2 && y == 2) {
          std::fill(stats.vertical_states.begin(), stats.vertical_states.end(),
                    rog_map::VerticalVoxelState::UNKNOWN);
          stats.vertical_states.at(6U) = rog_map::VerticalVoxelState::OCCUPIED;
          stats.observed_count = 1;
        }
        attachSupport(stats, 0.05);
        return stats;
      });

  EXPECT_EQ(center(layer).type, rog_map::CellType::PASSABLE);
  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::OVERHEAD_CLEARANCE_OK);
  EXPECT_FLOAT_EQ(center(layer).headroom_known_ratio, 0.0F);
  EXPECT_EQ(center(layer).clearance_verified, 1U);

  const auto &empty_neighbor = layer.cells().at(2U * kWidth + 1U);
  EXPECT_EQ(empty_neighbor.type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(empty_neighbor.raw_reason,
            rog_map::ProjectionClassReason::HEADROOM_UNVERIFIED);
}

TEST(GroundSupportProjection,
     ZeroObservedOverheadThresholdStillRequiresSurveyedSupport) {
  rog_map::ProjectionLayer layer;
  auto config = requiredSupportConfig();
  config.min_observed_overhead_headroom_known_ratio = 0.0;
  layer.update(
      kWidth, kHeight, kResolution, kOrigin, 1.0, config, [](int, int) {
        auto stats = column({6});
        std::fill(stats.vertical_states.begin(), stats.vertical_states.end(),
                  rog_map::VerticalVoxelState::UNKNOWN);
        stats.vertical_states.at(6U) = rog_map::VerticalVoxelState::OCCUPIED;
        stats.observed_count = 1;
        attachSupport(stats, 0.05, true, false);
        return stats;
      });
  EXPECT_EQ(center(layer).type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::GROUND_UNVERIFIED);
  EXPECT_EQ(center(layer).clearance_verified, 0U);
}

TEST(GroundSupportProjection,
     ZeroObservedOverheadThresholdNeverOverridesLowOccupiedReturn) {
  rog_map::ProjectionLayer layer;
  auto config = requiredSupportConfig();
  config.min_observed_overhead_headroom_known_ratio = 0.0;
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               [](int, int) {
                 auto stats = column({1, 3, 6});
                 attachSupport(stats, 0.05);
                 return stats;
               });
  EXPECT_EQ(center(layer).type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::HEADROOM_BLOCKED);
  EXPECT_EQ(center(layer).clearance_verified, 0U);
}

TEST(ProjectionClearance, AcceptsVerifiedGroundWithEnoughHeadroom) {
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               [](int, int) { return column({1, 7}); });

  EXPECT_EQ(center(layer).type, rog_map::CellType::PASSABLE);
  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::CLEARANCE_OK);
  EXPECT_EQ(center(layer).ground_verified, 1U);
  EXPECT_EQ(center(layer).clearance_verified, 1U);
  EXPECT_GT(center(layer).headroom,
            config.vehicle_height + config.headroom_margin);
}

TEST(ProjectionClearance, RejectsVerifiedGroundUnderLowCeiling) {
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.vehicle_height = 0.40;
  config.clear_robot_footprint_unknown = true;
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               [](int, int) { return column({1, 6}); });

  EXPECT_EQ(center(layer).type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::HEADROOM_BLOCKED);
  EXPECT_EQ(center(layer).ground_verified, 1U);
  EXPECT_EQ(center(layer).clearance_verified, 0U);
}

TEST(ProjectionClearance, AcceptsHighVerticalRunWithKnownBodyClearance) {
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.observed_empty_as_free = true;
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               [](int, int) { return column({6, 7, 8}); });

  EXPECT_EQ(center(layer).type, rog_map::CellType::PASSABLE);
  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::OVERHEAD_CLEARANCE_OK);
  EXPECT_EQ(center(layer).ground_candidate, 0U);
  EXPECT_EQ(center(layer).clearance_verified, 1U);
  EXPECT_EQ(center(layer).traversable, 1U);
  EXPECT_FLOAT_EQ(center(layer).headroom_known_ratio, 1.0F);
  EXPECT_GE(center(layer).headroom,
            config.vehicle_height + config.headroom_margin);
  EXPECT_EQ(layer.mask().at(2U * kWidth + 2U), 1U);
}

TEST(ProjectionClearance, RejectsHighVerticalRunWithoutGroundlessMode) {
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.observed_empty_as_free = false;
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               [](int, int) { return column({6, 7, 8}); });

  EXPECT_EQ(center(layer).type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::GROUND_UNVERIFIED);
  EXPECT_EQ(center(layer).clearance_verified, 0U);
  EXPECT_EQ(center(layer).traversable, 0U);
  EXPECT_EQ(layer.mask().at(2U * kWidth + 2U), 0U);
}

TEST(ProjectionClearance, RejectsVerticalRunInsideVehicleBodyBand) {
  rog_map::ProjectionLayer layer;
  const auto config = clearanceConfig();
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               [](int, int) { return column({3, 4, 5}); });

  EXPECT_EQ(center(layer).type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::HEADROOM_BLOCKED);
  EXPECT_EQ(center(layer).clearance_verified, 0U);
  EXPECT_EQ(center(layer).traversable, 0U);
  EXPECT_EQ(layer.mask().at(2U * kWidth + 2U), 0U);
}

TEST(ProjectionClearance,
     RechecksDownhillRoofAgainstConnectedLocalGroundInSameFrame) {
  constexpr int width = 13;
  constexpr int height = 9;
  constexpr double resolution = 0.05;
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.robot_x = 0.575;
  config.robot_y = 0.225;
  config.reference_ground_z_abs = 0.15;
  config.vehicle_height = 0.17;
  config.headroom_margin = 0.0;
  config.headroom_voxel_inset_fraction = 0.0;
  config.surface_height_delta_max = 0.12;
  config.ground_seed_radius = 1.0;
  config.ground_seed_tolerance = 0.18;
  config.observed_empty_as_free = true;
  config.min_observed_overhead_headroom_known_ratio = 0.0;
  layer.update(width, height, resolution, kOrigin, 1.0, config,
               [resolution](int x, int y) {
                 rog_map::ColumnStats stats;
                 if (x == 4 && y == 4) {
                   stats = groundColumn(0.0, resolution);
                   for (const int index : {5, 6, 7, 8}) {
                     stats.vertical_states.at(static_cast<size_t>(index)) =
                         rog_map::VerticalVoxelState::OCCUPIED;
                   }
                   stats.vertical_states.at(0U) =
                       rog_map::VerticalVoxelState::KNOWN_FREE;
                   stats.occupied_count = 4;
                   stats.occupied_z_index_min = 5;
                   stats.occupied_z_index_max = 8;
                   stats.occupied_z_min_abs = 0.225;
                   stats.occupied_z_max_abs = 0.375;
                 } else {
                   stats = groundColumn(0.0, resolution);
                 }
                 stats.prior_known_free = 1U;
                 return stats;
               });

  const auto &roof = layer.cells().at(4U * width + 4U);
  EXPECT_EQ(roof.type, rog_map::CellType::PASSABLE);
  EXPECT_EQ(roof.raw_reason,
            rog_map::ProjectionClassReason::OVERHEAD_CLEARANCE_OK);
  EXPECT_EQ(roof.clearance_verified, 1U);
  EXPECT_NEAR(roof.reference_ground_z_abs, -0.025F, 1.0e-5F);
  EXPECT_NEAR(roof.headroom, 0.250F, 1.0e-5F);
}

TEST(ProjectionClearance,
     RechecksRoofOverStaticProjectionWithoutAuthorizingDisconnectedGround) {
  constexpr int width = 15;
  constexpr int height = 9;
  constexpr double resolution = 0.05;
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.robot_x = 0.725;
  config.robot_y = 0.225;
  config.reference_ground_z_abs = 0.15;
  config.vehicle_height = 0.17;
  config.headroom_margin = 0.0;
  config.headroom_voxel_inset_fraction = 0.0;
  config.surface_height_delta_max = 0.12;
  config.ground_seed_radius = 1.0;
  config.ground_seed_tolerance = 0.18;
  config.observed_empty_as_free = true;
  config.bridge_observed_empty_for_ground_connectivity = false;
  config.min_observed_overhead_headroom_known_ratio = 0.0;
  layer.update(width, height, resolution, kOrigin, 1.0, config,
               [resolution](int x, int y) {
                 rog_map::ColumnStats stats;
                 if (x == 4 && y == 4) {
                   stats = groundColumn(0.0, resolution);
                   for (const int index : {5, 6, 7, 8}) {
                     stats.vertical_states.at(static_cast<size_t>(index)) =
                         rog_map::VerticalVoxelState::OCCUPIED;
                   }
                   stats.vertical_states.at(0U) =
                       rog_map::VerticalVoxelState::KNOWN_FREE;
                   stats.occupied_count = 4;
                   stats.occupied_z_index_min = 5;
                   stats.occupied_z_index_max = 8;
                   stats.occupied_z_min_abs = 0.225;
                   stats.occupied_z_max_abs = 0.375;
                 } else if (x <= 6) {
                   stats = groundColumn(0.0, resolution);
                 } else if (x <= 12) {
                   stats = emptyColumn(resolution);
                 } else {
                   stats = groundColumn(0.15, resolution);
                 }
                 stats.prior_known_free = (x == 4 && y == 4) ? 0U : 1U;
                 return stats;
               });

  const auto &roof = layer.cells().at(4U * width + 4U);
  const auto &disconnected_ground = layer.cells().at(4U * width + 3U);
  EXPECT_EQ(roof.type, rog_map::CellType::PASSABLE);
  EXPECT_EQ(roof.raw_reason,
            rog_map::ProjectionClassReason::OVERHEAD_CLEARANCE_OK);
  EXPECT_EQ(disconnected_ground.type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(disconnected_ground.raw_reason,
            rog_map::ProjectionClassReason::GROUND_UNVERIFIED);
  EXPECT_EQ(disconnected_ground.ground_verified, 0U);
}

TEST(ProjectionClearance, LocalGroundRecheckKeepsLowReturnBlocked) {
  constexpr int width = 13;
  constexpr int height = 9;
  constexpr double resolution = 0.05;
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.robot_x = 0.575;
  config.robot_y = 0.225;
  config.reference_ground_z_abs = 0.15;
  config.vehicle_height = 0.17;
  config.headroom_margin = 0.0;
  config.headroom_voxel_inset_fraction = 0.0;
  config.surface_height_delta_max = 0.08;
  config.ground_seed_radius = 1.0;
  config.ground_seed_tolerance = 0.18;
  config.observed_empty_as_free = true;
  config.min_observed_overhead_headroom_known_ratio = 0.0;
  layer.update(width, height, resolution, kOrigin, 1.0, config,
               [resolution](int x, int y) {
                 rog_map::ColumnStats stats;
                 if (x == 4 && y == 4) {
                   stats = groundColumn(0.0, resolution);
                   for (const int index : {3, 4, 5}) {
                     stats.vertical_states.at(static_cast<size_t>(index)) =
                         rog_map::VerticalVoxelState::OCCUPIED;
                   }
                   stats.vertical_states.at(0U) =
                       rog_map::VerticalVoxelState::KNOWN_FREE;
                   stats.occupied_count = 3;
                   stats.occupied_z_index_min = 3;
                   stats.occupied_z_index_max = 5;
                   stats.occupied_z_min_abs = 0.125;
                   stats.occupied_z_max_abs = 0.225;
                 } else {
                   stats = groundColumn(0.0, resolution);
                 }
                 stats.prior_known_free = 1U;
                 return stats;
               });

  const auto &obstacle = layer.cells().at(4U * width + 4U);
  EXPECT_EQ(obstacle.type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(obstacle.raw_reason,
            rog_map::ProjectionClassReason::HEADROOM_BLOCKED);
  EXPECT_EQ(obstacle.clearance_verified, 0U);
}

TEST(ProjectionClearance, NavigationOverlayIsNeutralUnlessEvidenceIsStrong) {
  rog_map::CellData neutral;
  neutral.raw_type = rog_map::CellType::OCCUPIED;
  neutral.raw_reason = rog_map::ProjectionClassReason::GROUND_UNVERIFIED;
  neutral.occupied_z_min_abs = 0.0F;
  neutral.occupied_z_max_abs = 0.05F;
  EXPECT_EQ(rog_map::navigationOverlayValue(neutral), -1);

  auto measured_low_obstacle = neutral;
  measured_low_obstacle.type = rog_map::CellType::OCCUPIED;
  measured_low_obstacle.raw_reason =
      rog_map::ProjectionClassReason::HEADROOM_BLOCKED;
  EXPECT_EQ(rog_map::navigationOverlayValue(measured_low_obstacle), 100);

  rog_map::CellData verified_roof;
  verified_roof.type = rog_map::CellType::PASSABLE;
  verified_roof.raw_type = rog_map::CellType::PASSABLE;
  verified_roof.raw_reason =
      rog_map::ProjectionClassReason::OVERHEAD_CLEARANCE_OK;
  verified_roof.clearance_verified = 1U;
  verified_roof.traversable = 1U;
  verified_roof.ceiling_z_abs = 0.225F;
  verified_roof.headroom = 0.178F;
  EXPECT_EQ(rog_map::navigationOverlayValue(verified_roof), 0);

  verified_roof.raw_type = rog_map::CellType::OCCUPIED;
  EXPECT_EQ(rog_map::navigationOverlayValue(verified_roof), -1);

  rog_map::CellData verified_empty;
  verified_empty.type = rog_map::CellType::FREE;
  verified_empty.raw_type = rog_map::CellType::FREE;
  verified_empty.raw_reason = rog_map::ProjectionClassReason::EMPTY_COLUMN;
  verified_empty.clearance_verified = 1U;
  verified_empty.traversable = 1U;
  verified_empty.headroom_known_ratio = 0.667F;
  EXPECT_EQ(rog_map::navigationOverlayValue(verified_empty), -1);
  verified_empty.clearance_verified = 0U;
  EXPECT_EQ(rog_map::navigationOverlayValue(verified_empty), -1);
}

TEST(ProjectionClearance,
     LocalGroundRecheckRejectsOneSidedTerrainWithoutStaticFreeEvidence) {
  constexpr int width = 13;
  constexpr int height = 9;
  constexpr double resolution = 0.05;
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.robot_x = 0.125;
  config.robot_y = 0.225;
  config.reference_ground_z_abs = 0.15;
  config.vehicle_height = 0.17;
  config.headroom_margin = 0.0;
  config.headroom_voxel_inset_fraction = 0.0;
  config.surface_height_delta_max = 0.12;
  config.ground_seed_radius = 1.0;
  config.ground_seed_tolerance = 0.18;
  config.observed_empty_as_free = true;
  config.min_observed_overhead_headroom_known_ratio = 0.0;
  const auto one_sided_scan = [resolution](int x, int y) {
    rog_map::ColumnStats stats;
    if (x == 4 && y == 4) {
      stats = groundColumn(0.0, resolution);
      for (const int index : {5, 6, 7, 8}) {
        stats.vertical_states.at(static_cast<size_t>(index)) =
            rog_map::VerticalVoxelState::OCCUPIED;
      }
      stats.vertical_states.at(0U) = rog_map::VerticalVoxelState::KNOWN_FREE;
      stats.occupied_count = 4;
      stats.occupied_z_index_min = 5;
      stats.occupied_z_index_max = 8;
      stats.occupied_z_min_abs = 0.225;
      stats.occupied_z_max_abs = 0.375;
    } else if (x < 4) {
      stats = groundColumn(0.0, resolution);
    } else {
      stats = emptyColumn(resolution, false);
    }
    stats.prior_known_free = (x == 4 && y == 4) ? 0U : 1U;
    return stats;
  };
  layer.update(width, height, resolution, kOrigin, 1.0, config, one_sided_scan);

  const auto &roof_without_surrounding_ground =
      layer.cells().at(4U * width + 4U);
  EXPECT_EQ(roof_without_surrounding_ground.type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(roof_without_surrounding_ground.raw_reason,
            rog_map::ProjectionClassReason::OVERHEAD_GROUND_UNVERIFIED);
  EXPECT_EQ(roof_without_surrounding_ground.clearance_verified, 0U);

  rog_map::ProjectionLayer static_free_layer;
  static_free_layer.update(width, height, resolution, kOrigin, 1.0, config,
                           [&one_sided_scan](int x, int y) {
                             auto stats = one_sided_scan(x, y);
                             stats.prior_known_free = 1U;
                             return stats;
                           });
  const auto &roof_with_static_free_evidence =
      static_free_layer.cells().at(4U * width + 4U);
  EXPECT_EQ(roof_with_static_free_evidence.type, rog_map::CellType::PASSABLE);
  EXPECT_EQ(roof_with_static_free_evidence.raw_reason,
            rog_map::ProjectionClassReason::OVERHEAD_CLEARANCE_OK);
  EXPECT_EQ(roof_with_static_free_evidence.clearance_verified, 1U);
}

TEST(ProjectionClearance, LocalGroundRecheckKeepsRealityHeadroomGate) {
  constexpr int width = 11;
  constexpr int height = 9;
  constexpr double resolution = 0.10;
  auto config = clearanceConfig();
  config.robot_x = 0.85;
  config.robot_y = 0.45;
  config.reference_ground_z_abs = 0.17;
  config.vehicle_height = 0.42;
  config.headroom_margin = 0.03;
  config.headroom_voxel_inset_fraction = 0.5;
  config.surface_height_delta_max = 0.12;
  config.ground_seed_radius = 2.5;
  config.ground_seed_tolerance = 0.18;
  config.observed_empty_as_free = true;
  config.min_observed_overhead_headroom_known_ratio = 0.0;

  const auto scan = [resolution](int roof_begin, int x, int y) {
    rog_map::ColumnStats stats;
    if (x == 4 && y == 4) {
      stats = groundColumn(0.0, resolution);
      for (int index = roof_begin; index <= roof_begin + 2; ++index) {
        stats.vertical_states.at(static_cast<size_t>(index)) =
            rog_map::VerticalVoxelState::OCCUPIED;
      }
      stats.vertical_states.at(0U) = rog_map::VerticalVoxelState::KNOWN_FREE;
      stats.occupied_count = 3;
      stats.occupied_z_index_min = roof_begin;
      stats.occupied_z_index_max = roof_begin + 2;
      stats.occupied_z_min_abs =
          -0.5 * resolution + static_cast<double>(roof_begin) * resolution;
      stats.occupied_z_max_abs = stats.occupied_z_min_abs + 2.0 * resolution;
    } else {
      stats = groundColumn(0.0, resolution);
    }
    stats.prior_known_free = 1U;
    return stats;
  };

  rog_map::ProjectionLayer clear_layer;
  clear_layer.update(width, height, resolution, kOrigin, 1.0, config,
                     [&scan](int x, int y) { return scan(6, x, y); });
  const auto &clear_roof = clear_layer.cells().at(4U * width + 4U);
  EXPECT_EQ(clear_roof.type, rog_map::CellType::PASSABLE);
  EXPECT_EQ(clear_roof.raw_reason,
            rog_map::ProjectionClassReason::OVERHEAD_CLEARANCE_OK);
  EXPECT_NEAR(clear_roof.headroom, 0.50F, 1.0e-5F);

  rog_map::ProjectionLayer low_layer;
  low_layer.update(width, height, resolution, kOrigin, 1.0, config,
                   [&scan](int x, int y) { return scan(5, x, y); });
  const auto &low_roof = low_layer.cells().at(4U * width + 4U);
  EXPECT_EQ(low_roof.type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(low_roof.raw_reason,
            rog_map::ProjectionClassReason::HEADROOM_BLOCKED);
  EXPECT_EQ(low_roof.clearance_verified, 0U);
}

TEST(ProjectionClearance, RejectsHighVerticalRunWithUnknownBodyBand) {
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.min_observed_voxels = 2;
  layer.update(
      kWidth, kHeight, kResolution, kOrigin, 1.0, config, [](int, int) {
        auto stats = column({6, 7, 8});
        std::fill(stats.vertical_states.begin(), stats.vertical_states.end(),
                  rog_map::VerticalVoxelState::UNKNOWN);
        for (const size_t index : {6U, 7U, 8U}) {
          stats.vertical_states.at(index) =
              rog_map::VerticalVoxelState::OCCUPIED;
        }
        stats.observed_count = 3;
        return stats;
      });

  EXPECT_EQ(center(layer).type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::HEADROOM_UNVERIFIED);
  EXPECT_EQ(center(layer).clearance_verified, 0U);
  EXPECT_EQ(center(layer).traversable, 0U);
  EXPECT_FLOAT_EQ(center(layer).headroom_known_ratio, 0.0F);
  EXPECT_EQ(layer.mask().at(2U * kWidth + 2U), 0U);
}

TEST(ProjectionClearance, ConnectsShortRampButRejectsHeightDisconnectedPlate) {
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.ground_seed_radius = 0.30;
  config.max_ground_step = 0.10;
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               [](int x, int y) {
                 if (x == 4 && y == 4) {
                   return column({4});
                 }
                 return x < 2 ? column({1}) : column({2});
               });

  const auto &cells = layer.cells();
  EXPECT_EQ(cells.at(2U * kWidth + 3U).type, rog_map::CellType::PASSABLE);
  EXPECT_EQ(cells.at(2U * kWidth + 3U).ground_verified, 1U);
  EXPECT_EQ(cells.at(4U * kWidth + 4U).type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(cells.at(4U * kWidth + 4U).raw_reason,
            rog_map::ProjectionClassReason::GROUND_UNVERIFIED);
}

TEST(ProjectionClearance, RejectsObservedEmptyColumnWithoutGroundSupport) {
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.unknown_as_occupied = false;
  config.clearance_unknown_as_occupied = false;
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               [](int, int) { return column({}); });

  EXPECT_EQ(center(layer).type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::EMPTY_COLUMN);
  EXPECT_EQ(center(layer).traversable, 0U);
  EXPECT_EQ(layer.mask().at(2U * kWidth + 2U), 0U);
}

TEST(ProjectionClearance, PriormapModeMayAcceptObservedEmptyColumn) {
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.observed_empty_as_free = true;
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               [](int, int) { return column({}); });

  EXPECT_EQ(center(layer).type, rog_map::CellType::FREE);
  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::EMPTY_COLUMN);
  EXPECT_EQ(center(layer).traversable, 1U);
  EXPECT_EQ(center(layer).clearance_verified, 1U);
  EXPECT_EQ(center(layer).ground_verified, 0U);
  EXPECT_EQ(layer.mask().at(2U * kWidth + 2U), 1U);
}

TEST(ProjectionClearance,
     PriormapModeRejectsEmptyColumnWithoutVerifiedBodyVolume) {
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.observed_empty_as_free = true;
  config.min_headroom_known_ratio = 0.80;
  layer.update(
      kWidth, kHeight, kResolution, kOrigin, 1.0, config, [](int, int) {
        auto stats = column({});
        // The body interval starts above reference ground 0.05 m. Leave most of
        // that interval unknown even though the column has enough observations.
        stats.vertical_states.assign(11U, rog_map::VerticalVoxelState::UNKNOWN);
        stats.vertical_states.front() = rog_map::VerticalVoxelState::KNOWN_FREE;
        stats.observed_count = 1;
        return stats;
      });

  EXPECT_EQ(center(layer).type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::HEADROOM_UNVERIFIED);
  EXPECT_EQ(center(layer).traversable, 0U);
  EXPECT_EQ(center(layer).clearance_verified, 0U);
  EXPECT_EQ(layer.mask().at(2U * kWidth + 2U), 0U);
}

TEST(ProjectionClearance, KeepsUnknownColumnClosed) {
  rog_map::ProjectionLayer layer;
  const auto config = clearanceConfig();
  layer.update(
      kWidth, kHeight, kResolution, kOrigin, 1.0, config, [](int, int) {
        rog_map::ColumnStats stats;
        stats.vertical_states.assign(11U, rog_map::VerticalVoxelState::UNKNOWN);
        return stats;
      });

  EXPECT_EQ(center(layer).type, rog_map::CellType::UNKNOWN);
  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::INSUFFICIENT_OBSERVATION);
  EXPECT_EQ(center(layer).traversable, 0U);
  EXPECT_EQ(layer.mask().at(2U * kWidth + 2U), 0U);
}

TEST(ProjectionClearance, EmptyHeadroomGapRespectsUnknownPolicy) {
  for (const bool unknown_as_occupied : {false, true}) {
    SCOPED_TRACE(unknown_as_occupied);
    rog_map::ProjectionLayer layer;
    auto config = clearanceConfig();
    config.observed_empty_as_free = true;
    config.clearance_unknown_as_occupied = false;
    config.unknown_as_occupied = unknown_as_occupied;
    layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
                 [](int, int) { return emptyColumn(kResolution, false); });

    EXPECT_EQ(center(layer).type, rog_map::CellType::UNKNOWN);
    EXPECT_EQ(center(layer).raw_reason,
              rog_map::ProjectionClassReason::HEADROOM_UNVERIFIED);
    EXPECT_FLOAT_EQ(center(layer).headroom_known_ratio, 0.0F);
    EXPECT_EQ(center(layer).clearance_verified, 0U);
    EXPECT_EQ(center(layer).value, unknown_as_occupied ? 254U : 255U);
    EXPECT_EQ(center(layer).mask, unknown_as_occupied ? 0U : 1U);
  }
}

TEST(PriorMapFusion, EmptyHeadroomGapFillPreservesMeasuredAndStaticObstacles) {
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.observed_empty_as_free = true;
  config.clearance_unknown_as_occupied = false;
  config.unknown_as_occupied = true;
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               [](int x, int) {
                 if (x == 1) {
                   return column({1, 2, 3, 4, 5});
                 }
                 if (x == 2) {
                   return column({1, 3});
                 }
                 return emptyColumn(kResolution, false);
               });

  rog_map::PriorMapData prior;
  prior.loaded = true;
  prior.transform_ready = true;
  prior.projection_cache_ready = true;
  prior.cached_mask.assign(layer.cells().size(), 1U);
  prior.cached_free_mask.assign(layer.cells().size(), 1U);
  const size_t row = 2U * kWidth;
  prior.cached_mask[row + 3U] = 0U;
  prior.cached_free_mask[row + 3U] = 0U;
  prior.cached_free_mask[row + 4U] = 0U;
  std::vector<uint8_t> unknown_mask;
  for (const auto &cell : layer.cells()) {
    unknown_mask.push_back(cell.type == rog_map::CellType::UNKNOWN ? 1U : 0U);
  }
  const std::vector<uint8_t> no_override(layer.cells().size(), 0U);
  std::vector<uint8_t> fused_mask;
  std::vector<uint8_t> fused_values;
  rog_map::fusePriorMapProjection(
      true, true, prior, layer.mask(), layer.values(), unknown_mask,
      no_override, no_override, fused_mask, fused_values);

  EXPECT_EQ(fused_mask[row], 1U);
  EXPECT_EQ(fused_values[row], 0U);
  for (size_t x = 1U; x < kWidth; ++x) {
    SCOPED_TRACE(x);
    EXPECT_EQ(fused_mask[row + x], 0U);
    EXPECT_EQ(fused_values[row + x], 254U);
  }
}

TEST(ProjectionClearance, RejectsEightCentimeterFloatingPlateInsideSeedRadius) {
  constexpr int width = 9;
  constexpr int height = 9;
  constexpr double resolution = 0.02;
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.robot_x = 0.09;
  config.robot_y = 0.09;
  config.reference_ground_z_abs = 0.0;
  config.reference_ground_plane_valid = true;
  config.reference_ground_slope_x = 0.0;
  config.reference_ground_slope_y = 0.0;
  config.ground_seed_radius = 0.08;
  // Deliberately include the plate in the height tolerance. It must still not
  // become a second seed disconnected from the lower support surface.
  config.ground_seed_tolerance = 0.10;
  config.max_ground_step = 0.03;
  config.min_headroom_known_ratio = 0.80;
  layer.update(width, height, resolution, kOrigin, 1.0, config,
               [](int x, int y) {
                 const bool floating_plate =
                     std::abs(x - 4) <= 1 && std::abs(y - 4) <= 1;
                 return groundColumn(floating_plate ? 0.08 : 0.0, resolution);
               });

  const auto &plate = layer.cells().at(4U * width + 4U);
  EXPECT_EQ(plate.type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(plate.raw_reason,
            rog_map::ProjectionClassReason::GROUND_UNVERIFIED);
  EXPECT_EQ(plate.ground_verified, 0U);
  EXPECT_EQ(layer.cells().at(4U * width + 2U).type,
            rog_map::CellType::PASSABLE);
}

TEST(ProjectionClearance, RobotTangentPlaneSeedsObservedDownhillTerrain) {
  constexpr int width = 21;
  constexpr int height = 9;
  constexpr double resolution = 0.05;
  auto config = clearanceConfig();
  config.robot_x = 0.925;
  config.robot_y = 0.225;
  config.reference_ground_z_abs = 0.20;
  config.ground_seed_radius = 1.0;
  config.ground_seed_tolerance = 0.18;
  config.max_ground_step = 0.06;
  config.observed_empty_as_free = true;
  config.bridge_observed_empty_for_ground_connectivity = false;

  const auto scan = [resolution](int x, int) {
    if (x >= 8 && x <= 12) {
      auto stats = emptyColumn(resolution);
      stats.prior_known_free = 1U;
      return stats;
    }
    const double wx = (static_cast<double>(x) + 0.5) * resolution;
    const double plane_z = 0.20 + 0.20 * (wx - 0.925);
    const double quantized_z = std::round(plane_z / resolution) * resolution;
    auto stats = groundColumn(quantized_z, resolution);
    stats.prior_known_free = 1U;
    return stats;
  };

  rog_map::ProjectionLayer horizontal_reference_layer;
  horizontal_reference_layer.update(width, height, resolution, kOrigin, 1.0,
                                    config, scan);
  const auto &disconnected_downhill =
      horizontal_reference_layer.cells().at(4U * width + 2U);
  EXPECT_EQ(disconnected_downhill.type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(disconnected_downhill.raw_reason,
            rog_map::ProjectionClassReason::GROUND_UNVERIFIED);

  config.reference_ground_plane_valid = true;
  config.reference_ground_slope_x = 0.20;
  config.reference_ground_slope_y = 0.0;
  rog_map::ProjectionLayer tangent_reference_layer;
  tangent_reference_layer.update(width, height, resolution, kOrigin, 1.0,
                                 config, scan);
  const auto &verified_downhill =
      tangent_reference_layer.cells().at(4U * width + 2U);
  EXPECT_EQ(verified_downhill.type, rog_map::CellType::PASSABLE);
  EXPECT_EQ(verified_downhill.ground_verified, 1U);
  EXPECT_NEAR(verified_downhill.reference_ground_z_abs, 0.04F, 1.0e-5F);
  EXPECT_LE(verified_downhill.support_match_error,
            verified_downhill.support_match_tolerance + 1.0e-6F);
}

TEST(ProjectionClearance, GroundConnectivityHoldExpiresWithoutRenewingItself) {
  auto config = clearanceConfig();
  config.reference_ground_z_abs = 0.0;
  config.ground_connectivity_hold_time = 0.8;
  rog_map::ProjectionLayer layer;
  const auto scan = [](int, int) { return groundColumn(0.0, kResolution); };
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config, scan);
  ASSERT_EQ(center(layer).type, rog_map::CellType::PASSABLE);

  config.reference_ground_z_abs = 0.20;
  for (double time : {1.1, 1.4, 1.7}) {
    layer.updateDirty(kWidth, kHeight, kResolution, kOrigin, time, config,
                      scan, {}, false);
    EXPECT_EQ(center(layer).type, rog_map::CellType::PASSABLE);
    EXPECT_EQ(center(layer).raw_reason,
              rog_map::ProjectionClassReason::GROUND_CONNECTIVITY_HOLD);
  }
  layer.updateDirty(kWidth, kHeight, kResolution, kOrigin, 1.81, config,
                    scan, {}, false);
  EXPECT_EQ(center(layer).raw_reason, rog_map::ProjectionClassReason::GROUND_UNVERIFIED);
  EXPECT_EQ(center(layer).type, rog_map::CellType::OCCUPIED);
}

TEST(ProjectionClearance, GroundConnectivityHoldDoesNotHideChangedSurfaceOrObstacle) {
  for (bool low_ceiling : {false, true}) {
    auto config = clearanceConfig();
    config.reference_ground_z_abs = 0.0;
    config.ground_connectivity_hold_time = 0.8;
    rog_map::ProjectionLayer layer;
    layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
                 [](int, int) { return groundColumn(0.0, kResolution); });
    ASSERT_EQ(center(layer).type, rog_map::CellType::PASSABLE);
    config.reference_ground_z_abs = 0.30;
    layer.update(kWidth, kHeight, kResolution, kOrigin, 1.1, config,
                 [low_ceiling](int, int) {
                   return low_ceiling ? column({0, 2}) : groundColumn(0.10, kResolution);
                 });
    EXPECT_EQ(center(layer).type, rog_map::CellType::OCCUPIED);
    EXPECT_NE(center(layer).raw_reason, rog_map::ProjectionClassReason::GROUND_CONNECTIVITY_HOLD);
  }
}

TEST(ProjectionClearance, IncrementalConnectivityRetainsIndependentClearanceEvidence) {
  auto config = clearanceConfig();
  config.reference_ground_z_abs = 0.0;
  config.ground_seed_tolerance = 0.18;
  config.reference_ground_plane_valid = true;
  config.reference_ground_slope_x = 0.20;
  config.clear_robot_footprint_unknown = true;
  config.robot_footprint_clear_length = 0.30;
  config.robot_footprint_clear_width = 0.30;
  config.robot_x = -1.0;
  config.ground_seed_radius = 0.5;
  rog_map::ProjectionLayer incremental, full;
  const auto scan = [](int, int) { return groundColumn(0.10, kResolution); };
  incremental.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config, scan);
  ASSERT_EQ(center(incremental).type, rog_map::CellType::OCCUPIED);
  config.robot_x = 0.25;
  incremental.updateDirty(kWidth, kHeight, kResolution, kOrigin, 1.1, config, scan, {}, false);
  full.update(kWidth, kHeight, kResolution, kOrigin, 1.1, config, scan);
  ASSERT_EQ(center(full).type, rog_map::CellType::PASSABLE);
  EXPECT_EQ(center(incremental).type, center(full).type);
  EXPECT_EQ(center(incremental).ground_verified, 1U);
}

TEST(ProjectionClearance,
     CurrentFootprintUsesConfiguredToleranceForVerifiedRampGround) {
  constexpr int width = 13;
  constexpr int height = 5;
  constexpr double resolution = 0.05;
  constexpr double robot_x = 0.325;
  constexpr double robot_y = 0.125;
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.robot_x = robot_x;
  config.robot_y = robot_y;
  config.reference_ground_z_abs = 0.0;
  config.reference_ground_plane_valid = true;
  config.reference_ground_slope_x = 0.20;
  config.reference_ground_slope_y = 0.0;
  config.ground_seed_radius = 0.50;
  config.ground_seed_tolerance = 0.18;
  config.max_ground_step = 0.06;
  config.clear_robot_footprint_unknown = true;
  config.robot_footprint_clear_length = 0.30;
  config.robot_footprint_clear_width = 0.20;

  layer.update(width, height, resolution, kOrigin, 1.0, config,
               [resolution](int x, int) {
                 const double wx = (static_cast<double>(x) + 0.5) * resolution;
                 const double offset_ramp_z = 0.20 * (wx - robot_x) + 0.10;
                 return groundColumn(offset_ramp_z, resolution);
               });

  const auto &under_robot = layer.cells().at(2U * width + 6U);
  EXPECT_EQ(under_robot.type, rog_map::CellType::PASSABLE);
  EXPECT_EQ(under_robot.ground_verified, 1U);
  EXPECT_EQ(under_robot.inside_current_footprint, 1U);
  EXPECT_LE(under_robot.support_match_error, 0.05F);
  EXPECT_NEAR(under_robot.support_match_tolerance, 0.18F, 1.0e-6F);
}

TEST(ProjectionClearance,
     FootprintGroundCalibratesPlaneInterceptAcrossSensorBlindGap) {
  constexpr int width = 25;
  constexpr int height = 5;
  constexpr double resolution = 0.05;
  constexpr double robot_x = 0.325;
  constexpr double robot_y = 0.125;
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.robot_x = robot_x;
  config.robot_y = robot_y;
  config.reference_ground_z_abs = 0.0;
  config.reference_ground_plane_valid = true;
  config.reference_ground_slope_x = 0.20;
  config.reference_ground_slope_y = 0.0;
  config.ground_seed_radius = 1.0;
  config.ground_seed_tolerance = 0.18;
  config.max_ground_step = 0.06;
  config.clear_robot_footprint_unknown = true;
  config.robot_footprint_clear_length = 0.30;
  config.robot_footprint_clear_width = 0.20;

  layer.update(width, height, resolution, kOrigin, 1.0, config,
               [resolution](int x, int) {
                 if (x > 8 && x < 14) {
                   rog_map::ColumnStats stats;
                   stats.vertical_states.assign(
                       40U, rog_map::VerticalVoxelState::UNKNOWN);
                   return stats;
                 }
                 const double wx = (static_cast<double>(x) + 0.5) * resolution;
                 return groundColumn(0.20 * (wx - robot_x) + 0.10, resolution);
               });

  const auto &ground_beyond_blind_gap = layer.cells().at(2U * width + 16U);
  EXPECT_EQ(ground_beyond_blind_gap.type, rog_map::CellType::PASSABLE);
  EXPECT_EQ(ground_beyond_blind_gap.ground_verified, 1U);
  EXPECT_EQ(ground_beyond_blind_gap.inside_current_footprint, 0U);
  EXPECT_LE(ground_beyond_blind_gap.support_match_error, 0.05F);
  EXPECT_NEAR(ground_beyond_blind_gap.support_match_tolerance, 0.06F, 1.0e-6F);
}

TEST(ProjectionClearance,
     ConfiguredToleranceDoesNotSeedDisconnectedGroundOutsideFootprint) {
  constexpr int width = 13;
  constexpr int height = 5;
  constexpr double resolution = 0.05;
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.robot_x = 0.125;
  config.robot_y = 0.125;
  config.reference_ground_z_abs = 0.0;
  config.reference_ground_plane_valid = true;
  config.reference_ground_slope_x = 0.20;
  config.reference_ground_slope_y = 0.0;
  config.ground_seed_radius = 1.0;
  config.ground_seed_tolerance = 0.18;
  config.max_ground_step = 0.06;
  config.clear_robot_footprint_unknown = true;
  config.robot_footprint_clear_length = 0.20;
  config.robot_footprint_clear_width = 0.20;

  layer.update(width, height, resolution, kOrigin, 1.0, config,
               [resolution](int x, int) {
                 if (x < 8) {
                   rog_map::ColumnStats stats;
                   stats.vertical_states.assign(
                       40U, rog_map::VerticalVoxelState::UNKNOWN);
                   return stats;
                 }
                 const double wx = (static_cast<double>(x) + 0.5) * resolution;
                 return groundColumn(0.20 * (wx - 0.125) + 0.10, resolution);
               });

  const auto &disconnected = layer.cells().at(2U * width + 10U);
  EXPECT_EQ(disconnected.type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(disconnected.raw_reason,
            rog_map::ProjectionClassReason::GROUND_UNVERIFIED);
  EXPECT_EQ(disconnected.ground_verified, 0U);
  EXPECT_EQ(disconnected.inside_current_footprint, 0U);
  EXPECT_NEAR(disconnected.support_match_tolerance, 0.06F, 1.0e-6F);
}

TEST(ProjectionClearance,
     BootstrapsNearRampBeyondStrictPlaneGateWithSlopeEvidence) {
  constexpr int width = 17;
  constexpr int height = 5;
  constexpr double resolution = 0.05;
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.robot_x = 0.125;
  config.robot_y = 0.125;
  config.reference_ground_z_abs = 0.0;
  config.reference_ground_plane_valid = true;
  config.reference_ground_slope_x = 0.0;
  config.reference_ground_slope_y = 0.0;
  config.ground_seed_radius = 1.0;
  config.ground_seed_tolerance = 0.18;
  config.max_ground_step = 0.08;
  config.clear_robot_footprint_unknown = true;
  config.robot_footprint_clear_length = 0.20;
  config.robot_footprint_clear_width = 0.20;
  config.ground_connectivity_bridge_max_length = 0.45;
  config.ground_connectivity_bridge_max_height_delta = 0.15;
  config.ground_connectivity_bridge_landing_min_length = 0.15;
  config.ground_connectivity_bridge_landing_min_height_delta = 0.04;

  layer.update(width, height, resolution, kOrigin, 1.0, config,
               [resolution](int x, int) {
                 if (x == 5 || x == 6) {
                   rog_map::ColumnStats stats;
                   stats.vertical_states.assign(
                       40U, rog_map::VerticalVoxelState::UNKNOWN);
                   return stats;
                 }
                 double ground_z = 0.0;
                 if (x >= 7) {
                   ground_z = 0.10;
                 }
                 if (x >= 9) {
                   ground_z = 0.15;
                 }
                 if (x >= 11) {
                   ground_z = 0.20;
                 }
                 if (x >= 13) {
                   ground_z = 0.25;
                 }
                 return groundColumn(ground_z, resolution);
               });

  const auto &ramp_foot = layer.cells().at(2U * width + 7U);
  const auto &ramp = layer.cells().at(2U * width + 14U);
  EXPECT_EQ(ramp_foot.type, rog_map::CellType::PASSABLE);
  EXPECT_EQ(ramp_foot.ground_verified, 1U);
  EXPECT_EQ(ramp_foot.ground_bridge_verified, 1U);
  EXPECT_GT(ramp_foot.support_match_error, ramp_foot.support_match_tolerance);
  EXPECT_EQ(ramp.type, rog_map::CellType::PASSABLE);
  EXPECT_EQ(ramp.ground_verified, 1U);
}

TEST(ProjectionClearance, SlopeEvidenceMayBridgeBeyondConfiguredSeedTolerance) {
  constexpr int width = 17;
  constexpr int height = 5;
  constexpr double resolution = 0.05;
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.robot_x = 0.125;
  config.robot_y = 0.125;
  config.reference_ground_z_abs = 0.0;
  config.reference_ground_plane_valid = true;
  config.reference_ground_slope_x = -0.20;
  config.reference_ground_slope_y = 0.0;
  config.ground_seed_radius = 1.0;
  config.ground_seed_tolerance = 0.18;
  config.max_ground_height_delta = 0.35;
  config.max_ground_step = 0.08;
  config.clear_robot_footprint_unknown = true;
  config.robot_footprint_clear_length = 0.20;
  config.robot_footprint_clear_width = 0.20;
  config.ground_connectivity_bridge_max_length = 0.45;
  config.ground_connectivity_bridge_max_height_delta = 0.15;
  config.ground_connectivity_bridge_landing_min_length = 0.15;
  config.ground_connectivity_bridge_landing_min_height_delta = 0.04;

  layer.update(width, height, resolution, kOrigin, 1.0, config,
               [resolution](int x, int) {
                 if (x == 5 || x == 6) {
                   rog_map::ColumnStats stats;
                   stats.vertical_states.assign(
                       40U, rog_map::VerticalVoxelState::UNKNOWN);
                   return stats;
                 }
                 double ground_z = 0.05;
                 if (x >= 7) {
                   ground_z = 0.20;
                 }
                 if (x >= 9) {
                   ground_z = 0.25;
                 }
                 if (x >= 11) {
                   ground_z = 0.30;
                 }
                 return groundColumn(ground_z, resolution);
               });

  const auto &ramp_foot = layer.cells().at(2U * width + 7U);
  EXPECT_GT(ramp_foot.support_match_error, config.ground_seed_tolerance);
  EXPECT_EQ(ramp_foot.type, rog_map::CellType::PASSABLE);
  EXPECT_EQ(ramp_foot.ground_verified, 1U);
  EXPECT_EQ(ramp_foot.ground_bridge_verified, 1U);
}

TEST(ProjectionClearance, NearPlaneGateBootstrapRejectsFlatStep) {
  constexpr int width = 17;
  constexpr int height = 5;
  constexpr double resolution = 0.05;
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.robot_x = 0.125;
  config.robot_y = 0.125;
  config.reference_ground_z_abs = 0.0;
  config.reference_ground_plane_valid = true;
  config.reference_ground_slope_x = 0.0;
  config.reference_ground_slope_y = 0.0;
  config.ground_seed_radius = 1.0;
  config.ground_seed_tolerance = 0.18;
  config.max_ground_step = 0.08;
  config.clear_robot_footprint_unknown = true;
  config.robot_footprint_clear_length = 0.20;
  config.robot_footprint_clear_width = 0.20;
  config.ground_connectivity_bridge_max_length = 0.45;
  config.ground_connectivity_bridge_max_height_delta = 0.15;
  config.ground_connectivity_bridge_landing_min_length = 0.15;
  config.ground_connectivity_bridge_landing_min_height_delta = 0.04;

  layer.update(width, height, resolution, kOrigin, 1.0, config,
               [resolution](int x, int) {
                 if (x == 5 || x == 6) {
                   rog_map::ColumnStats stats;
                   stats.vertical_states.assign(
                       40U, rog_map::VerticalVoxelState::UNKNOWN);
                   return stats;
                 }
                 return groundColumn(x >= 7 ? 0.10 : 0.0, resolution);
               });

  const auto &step = layer.cells().at(2U * width + 7U);
  EXPECT_EQ(step.type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(step.ground_verified, 0U);
  EXPECT_EQ(step.raw_reason, rog_map::ProjectionClassReason::GROUND_UNVERIFIED);
}

TEST(ProjectionClearance, AdjacentLowTerrainDoesNotHijackRobotHeightSeed) {
  constexpr int width = 9;
  constexpr int height = 9;
  constexpr double resolution = 0.05;
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.robot_x = 0.225;
  config.robot_y = 0.225;
  config.reference_ground_z_abs = 0.175;
  config.ground_seed_radius = 0.35;
  config.ground_seed_tolerance = 0.18;
  config.max_ground_step = 0.06;
  config.min_headroom_known_ratio = 0.80;
  layer.update(width, height, resolution, kOrigin, 1.0, config,
               [resolution](int x, int) {
                 return groundColumn(x == 0 ? 0.05 : 0.20, resolution);
               });

  const auto &robot_height_ground = layer.cells().at(4U * width + 4U);
  EXPECT_EQ(robot_height_ground.type, rog_map::CellType::PASSABLE);
  EXPECT_EQ(robot_height_ground.ground_verified, 1U);

  const auto &disconnected_low_ground = layer.cells().at(4U * width);
  EXPECT_EQ(disconnected_low_ground.type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(disconnected_low_ground.raw_reason,
            rog_map::ProjectionClassReason::GROUND_UNVERIFIED);
  EXPECT_EQ(disconnected_low_ground.ground_verified, 0U);
}

TEST(ProjectionClearance, BridgesOneVoxelizedRampFootWithContinuingSlope) {
  constexpr int width = 13;
  constexpr int height = 5;
  constexpr double resolution = 0.05;
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.robot_x = 0.125;
  config.robot_y = 0.125;
  config.reference_ground_z_abs = 0.0;
  config.ground_seed_radius = 0.12;
  config.ground_seed_tolerance = 0.18;
  config.max_ground_step = 0.06;
  config.ground_connectivity_bridge_max_height_delta = 0.15;
  config.ground_connectivity_bridge_landing_min_length = 0.25;
  config.ground_connectivity_bridge_landing_min_height_delta = 0.04;
  layer.update(width, height, resolution, kOrigin, 1.0, config,
               [resolution](int x, int) {
                 double height = 0.0;
                 if (x >= 4) {
                   height = 0.10;
                 }
                 if (x >= 7) {
                   height = 0.15;
                 }
                 if (x >= 10) {
                   height = 0.20;
                 }
                 return groundColumn(height, resolution);
               });

  const auto &ramp_foot = layer.cells().at(2U * width + 4U);
  const auto &ramp = layer.cells().at(2U * width + 12U);
  EXPECT_EQ(ramp_foot.type, rog_map::CellType::PASSABLE);
  EXPECT_EQ(ramp_foot.ground_bridge_verified, 1U);
  EXPECT_EQ(ramp.type, rog_map::CellType::PASSABLE);
  EXPECT_EQ(ramp.ground_verified, 1U);
}

TEST(ProjectionClearance,
     BridgesDescendingVoxelizedRampFootWithSlopeBeforeLanding) {
  constexpr int width = 13;
  constexpr int height = 5;
  constexpr double resolution = 0.05;
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.robot_x = 0.625;
  config.robot_y = 0.125;
  config.reference_ground_z_abs = 0.20;
  config.ground_seed_radius = 0.12;
  config.ground_seed_tolerance = 0.18;
  config.max_ground_step = 0.06;
  config.ground_connectivity_bridge_max_height_delta = 0.15;
  config.ground_connectivity_bridge_landing_min_length = 0.25;
  config.ground_connectivity_bridge_landing_min_height_delta = 0.04;
  layer.update(width, height, resolution, kOrigin, 1.0, config,
               [resolution](int x, int) {
                 double height = 0.0;
                 if (x >= 4) {
                   height = 0.10;
                 }
                 if (x >= 7) {
                   height = 0.15;
                 }
                 if (x >= 10) {
                   height = 0.20;
                 }
                 return groundColumn(height, resolution);
               });

  const auto &lower_floor = layer.cells().at(2U * width);
  const auto &ramp_foot = layer.cells().at(2U * width + 3U);
  EXPECT_EQ(ramp_foot.type, rog_map::CellType::PASSABLE);
  EXPECT_EQ(ramp_foot.ground_bridge_verified, 1U);
  EXPECT_EQ(lower_floor.type, rog_map::CellType::PASSABLE);
  EXPECT_EQ(lower_floor.ground_verified, 1U);
}

TEST(ProjectionClearance, AllowsOneBlindBandBeforeOneQuantizedRampFoot) {
  constexpr int width = 17;
  constexpr int height = 5;
  constexpr double resolution = 0.05;
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.robot_x = 0.125;
  config.robot_y = 0.125;
  config.reference_ground_z_abs = 0.0;
  config.ground_seed_radius = 0.12;
  config.ground_seed_tolerance = 0.18;
  config.max_ground_step = 0.06;
  config.observed_empty_as_free = true;
  config.bridge_observed_empty_for_ground_connectivity = true;
  config.ground_connectivity_bridge_max_length = 0.11;
  config.ground_connectivity_bridge_max_height_delta = 0.15;
  layer.update(width, height, resolution, kOrigin, 1.0, config,
               [resolution](int x, int) {
                 if (x == 4) {
                   return emptyColumn(resolution);
                 }
                 double height = 0.0;
                 if (x >= 7) {
                   height = 0.10;
                 }
                 if (x >= 10) {
                   height = 0.15;
                 }
                 if (x >= 13) {
                   height = 0.20;
                 }
                 return groundColumn(height, resolution);
               });

  const auto &blind_band_landing = layer.cells().at(2U * width + 5U);
  const auto &ramp_foot = layer.cells().at(2U * width + 7U);
  const auto &ramp = layer.cells().at(2U * width + 16U);
  EXPECT_EQ(blind_band_landing.type, rog_map::CellType::PASSABLE);
  EXPECT_EQ(blind_band_landing.ground_bridge_verified, 1U);
  EXPECT_EQ(ramp_foot.type, rog_map::CellType::PASSABLE);
  EXPECT_EQ(ramp_foot.ground_bridge_verified, 1U);
  EXPECT_EQ(ramp.type, rog_map::CellType::PASSABLE);
}

TEST(ProjectionClearance, QuantizedRampBridgeRejectsFlatStepLanding) {
  constexpr int width = 13;
  constexpr int height = 5;
  constexpr double resolution = 0.05;
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.robot_x = 0.125;
  config.robot_y = 0.125;
  config.reference_ground_z_abs = 0.0;
  config.ground_seed_radius = 0.12;
  config.ground_seed_tolerance = 0.18;
  config.max_ground_step = 0.06;
  config.ground_connectivity_bridge_max_height_delta = 0.15;
  config.ground_connectivity_bridge_landing_min_length = 0.25;
  config.ground_connectivity_bridge_landing_min_height_delta = 0.04;
  layer.update(width, height, resolution, kOrigin, 1.0, config,
               [resolution](int x, int) {
                 return groundColumn(x >= 4 ? 0.10 : 0.0, resolution);
               });

  const auto &step = layer.cells().at(2U * width + 4U);
  EXPECT_EQ(step.type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(step.ground_verified, 0U);
  EXPECT_EQ(step.raw_reason, rog_map::ProjectionClassReason::GROUND_UNVERIFIED);
}

TEST(ProjectionClearance, SeedsCoplanarGroundArcsSplitBySensorBlindRegion) {
  constexpr int width = 7;
  constexpr int height = 7;
  constexpr double resolution = 0.05;
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.robot_x = 0.175;
  config.robot_y = 0.175;
  config.reference_ground_z_abs = 0.0;
  config.ground_seed_radius = 0.11;
  config.ground_seed_tolerance = 0.06;
  config.max_ground_step = 0.06;
  layer.update(
      width, height, resolution, kOrigin, 1.0, config, [](int x, int y) {
        if (y == 3 && (x == 1 || x == 2 || x == 4 || x == 5)) {
          return groundColumn(0.0, resolution);
        }
        rog_map::ColumnStats stats;
        stats.vertical_states.assign(40U, rog_map::VerticalVoxelState::UNKNOWN);
        return stats;
      });

  const auto &cells = layer.cells();
  EXPECT_EQ(cells.at(3U * width + 2U).type, rog_map::CellType::PASSABLE);
  EXPECT_EQ(cells.at(3U * width + 2U).ground_verified, 1U);
  EXPECT_EQ(cells.at(3U * width + 4U).type, rog_map::CellType::PASSABLE);
  EXPECT_EQ(cells.at(3U * width + 4U).ground_verified, 1U);
  EXPECT_EQ(cells.at(3U * width + 3U).type, rog_map::CellType::UNKNOWN);
}

TEST(ProjectionClearance, BridgesOneClearanceVerifiedObservedEmptyColumn) {
  constexpr int width = 9;
  constexpr int height = 5;
  constexpr double resolution = 0.05;
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.robot_x = 0.125;
  config.robot_y = 0.125;
  config.reference_ground_z_abs = 0.0;
  config.ground_seed_radius = 0.12;
  config.ground_seed_tolerance = 0.06;
  config.max_ground_step = 0.06;
  config.observed_empty_as_free = true;
  config.bridge_observed_empty_for_ground_connectivity = true;
  layer.update(width, height, resolution, kOrigin, 1.0, config,
               [resolution](int x, int) {
                 if (x == 4) {
                   return emptyColumn(resolution);
                 }
                 return groundColumn(x >= 5 ? 0.05 : 0.0, resolution);
               });

  const auto &bridge = layer.cells().at(2U * width + 4U);
  const auto &ramp = layer.cells().at(2U * width + 8U);
  EXPECT_EQ(bridge.type, rog_map::CellType::FREE);
  EXPECT_EQ(bridge.raw_reason, rog_map::ProjectionClassReason::EMPTY_COLUMN);
  EXPECT_EQ(bridge.clearance_verified, 1U);
  EXPECT_EQ(ramp.type, rog_map::CellType::PASSABLE);
  EXPECT_EQ(ramp.ground_verified, 1U);
}

TEST(ProjectionClearance, DoesNotChainAcrossTwoObservedEmptyColumns) {
  constexpr int width = 9;
  constexpr int height = 5;
  constexpr double resolution = 0.05;
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.robot_x = 0.125;
  config.robot_y = 0.125;
  config.reference_ground_z_abs = 0.0;
  config.ground_seed_radius = 0.12;
  config.ground_seed_tolerance = 0.06;
  config.max_ground_step = 0.06;
  config.observed_empty_as_free = true;
  config.bridge_observed_empty_for_ground_connectivity = true;
  layer.update(width, height, resolution, kOrigin, 1.0, config,
               [resolution](int x, int) {
                 if (x == 4 || x == 5) {
                   return emptyColumn(resolution);
                 }
                 return groundColumn(x >= 6 ? 0.05 : 0.0, resolution);
               });

  const auto &disconnected = layer.cells().at(2U * width + 8U);
  EXPECT_EQ(disconnected.type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(disconnected.raw_reason,
            rog_map::ProjectionClassReason::GROUND_UNVERIFIED);
  EXPECT_EQ(disconnected.ground_verified, 0U);
}

TEST(ProjectionClearance, BridgesCalibratedObservedEmptyBlindRegion) {
  constexpr int width = 17;
  constexpr int height = 5;
  constexpr double resolution = 0.05;
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.robot_x = 0.125;
  config.robot_y = 0.125;
  config.reference_ground_z_abs = 0.0;
  config.ground_seed_radius = 0.12;
  config.ground_seed_tolerance = 0.06;
  config.max_ground_step = 0.06;
  config.observed_empty_as_free = true;
  config.bridge_observed_empty_for_ground_connectivity = true;
  config.ground_connectivity_bridge_max_length = 0.31;
  config.ground_connectivity_bridge_max_height_delta = 0.12;
  config.ground_connectivity_bridge_landing_min_length = 0.25;
  config.ground_connectivity_bridge_landing_min_height_delta = 0.04;
  layer.update(width, height, resolution, kOrigin, 1.0, config,
               [resolution](int x, int) {
                 if (x >= 4 && x <= 8) {
                   return emptyColumn(resolution);
                 }
                 const double ramp_height = x >= 13 ? 0.15 : 0.10;
                 return groundColumn(x >= 9 ? ramp_height : 0.0, resolution);
               });

  const auto &landing = layer.cells().at(2U * width + 9U);
  EXPECT_EQ(landing.type, rog_map::CellType::PASSABLE);
  EXPECT_EQ(landing.ground_verified, 1U);
  EXPECT_EQ(landing.ground_bridge_verified, 1U);
  EXPECT_EQ(landing.raw_reason,
            rog_map::ProjectionClassReason::GROUND_BRIDGE_CLEARANCE_OK);
}

TEST(ProjectionClearance, BoundedBridgeRejectsExcessiveLengthOrHeight) {
  constexpr int width = 17;
  constexpr int height = 5;
  constexpr double resolution = 0.05;
  auto config = clearanceConfig();
  config.robot_x = 0.125;
  config.robot_y = 0.125;
  config.reference_ground_z_abs = 0.0;
  config.ground_seed_radius = 0.12;
  config.ground_seed_tolerance = 0.06;
  config.max_ground_step = 0.06;
  config.observed_empty_as_free = true;
  config.bridge_observed_empty_for_ground_connectivity = true;
  config.ground_connectivity_bridge_max_height_delta = 0.12;
  config.ground_connectivity_bridge_landing_min_length = 0.25;
  config.ground_connectivity_bridge_landing_min_height_delta = 0.04;

  rog_map::ProjectionLayer long_gap_layer;
  config.ground_connectivity_bridge_max_length = 0.25;
  long_gap_layer.update(width, height, resolution, kOrigin, 1.0, config,
                        [resolution](int x, int) {
                          if (x >= 4 && x <= 8) {
                            return emptyColumn(resolution);
                          }
                          const double ramp_height = x >= 13 ? 0.15 : 0.10;
                          return groundColumn(x >= 9 ? ramp_height : 0.0,
                                              resolution);
                        });
  const auto &long_gap = long_gap_layer.cells().at(2U * width + 9U);
  EXPECT_EQ(long_gap.type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(long_gap.ground_verified, 0U);
  EXPECT_EQ(long_gap.raw_reason,
            rog_map::ProjectionClassReason::GROUND_UNVERIFIED);

  rog_map::ProjectionLayer high_landing_layer;
  config.ground_connectivity_bridge_max_length = 0.31;
  config.ground_connectivity_bridge_max_height_delta = 0.08;
  high_landing_layer.update(width, height, resolution, kOrigin, 1.0, config,
                            [resolution](int x, int) {
                              if (x >= 4 && x <= 8) {
                                return emptyColumn(resolution);
                              }
                              const double ramp_height = x >= 13 ? 0.15 : 0.10;
                              return groundColumn(x >= 9 ? ramp_height : 0.0,
                                                  resolution);
                            });
  const auto &high_landing = high_landing_layer.cells().at(2U * width + 9U);
  EXPECT_EQ(high_landing.type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(high_landing.ground_verified, 0U);
  EXPECT_EQ(high_landing.raw_reason,
            rog_map::ProjectionClassReason::GROUND_UNVERIFIED);
}

TEST(ProjectionClearance, MultiCellBridgeRejectsHorizontalFloatingLanding) {
  constexpr int width = 17;
  constexpr int height = 5;
  constexpr double resolution = 0.05;
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.robot_x = 0.125;
  config.robot_y = 0.125;
  config.reference_ground_z_abs = 0.0;
  config.ground_seed_radius = 0.12;
  config.ground_seed_tolerance = 0.06;
  config.max_ground_step = 0.06;
  config.observed_empty_as_free = true;
  config.bridge_observed_empty_for_ground_connectivity = true;
  config.ground_connectivity_bridge_max_length = 0.31;
  config.ground_connectivity_bridge_max_height_delta = 0.12;
  config.ground_connectivity_bridge_landing_min_length = 0.25;
  config.ground_connectivity_bridge_landing_min_height_delta = 0.04;
  layer.update(width, height, resolution, kOrigin, 1.0, config,
               [resolution](int x, int) {
                 if (x >= 4 && x <= 8) {
                   return emptyColumn(resolution);
                 }
                 return groundColumn(x >= 9 ? 0.10 : 0.0, resolution);
               });

  const auto &plate = layer.cells().at(2U * width + 9U);
  EXPECT_EQ(plate.type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(plate.ground_verified, 0U);
  EXPECT_EQ(plate.raw_reason,
            rog_map::ProjectionClassReason::GROUND_UNVERIFIED);
}

TEST(ProjectionClearance, DoesNotChainMultipleCalibratedBlindRegionBridges) {
  constexpr int width = 27;
  constexpr int height = 5;
  constexpr double resolution = 0.05;
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.robot_x = 0.125;
  config.robot_y = 0.125;
  config.reference_ground_z_abs = 0.0;
  config.ground_seed_radius = 0.12;
  config.ground_seed_tolerance = 0.06;
  config.max_ground_step = 0.06;
  config.observed_empty_as_free = true;
  config.bridge_observed_empty_for_ground_connectivity = true;
  config.ground_connectivity_bridge_max_length = 0.31;
  config.ground_connectivity_bridge_max_height_delta = 0.12;
  config.ground_connectivity_bridge_landing_min_length = 0.25;
  config.ground_connectivity_bridge_landing_min_height_delta = 0.04;
  layer.update(width, height, resolution, kOrigin, 1.0, config,
               [resolution](int x, int) {
                 if ((x >= 4 && x <= 8) || (x >= 15 && x <= 19)) {
                   return emptyColumn(resolution);
                 }
                 double height = 0.0;
                 if (x >= 20) {
                   height = x >= 24 ? 0.30 : 0.25;
                 } else if (x >= 9) {
                   height = x >= 13 ? 0.15 : 0.10;
                 }
                 return groundColumn(height, resolution);
               });

  const auto &first_landing = layer.cells().at(2U * width + 9U);
  const auto &second_landing = layer.cells().at(2U * width + 20U);
  EXPECT_EQ(first_landing.type, rog_map::CellType::PASSABLE);
  EXPECT_EQ(first_landing.ground_bridge_verified, 1U);
  EXPECT_EQ(second_landing.type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(second_landing.ground_verified, 0U);
  EXPECT_EQ(second_landing.raw_reason,
            rog_map::ProjectionClassReason::GROUND_UNVERIFIED);
}

TEST(ProjectionClearance, BridgeRejectsUnverifiedEmptyColumnAndFloatingPlate) {
  constexpr int width = 9;
  constexpr int height = 5;
  constexpr double resolution = 0.05;
  auto config = clearanceConfig();
  config.robot_x = 0.125;
  config.robot_y = 0.125;
  config.reference_ground_z_abs = 0.0;
  config.ground_seed_radius = 0.12;
  config.ground_seed_tolerance = 0.06;
  config.max_ground_step = 0.06;
  config.observed_empty_as_free = true;
  config.bridge_observed_empty_for_ground_connectivity = true;

  rog_map::ProjectionLayer unknown_gap_layer;
  unknown_gap_layer.update(width, height, resolution, kOrigin, 1.0, config,
                           [resolution](int x, int) {
                             if (x == 4) {
                               return emptyColumn(resolution, false);
                             }
                             return groundColumn(x >= 5 ? 0.05 : 0.0,
                                                 resolution);
                           });
  const auto &unknown_gap = unknown_gap_layer.cells().at(2U * width + 4U);
  const auto &unknown_gap_ramp = unknown_gap_layer.cells().at(2U * width + 8U);
  EXPECT_EQ(unknown_gap.type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(unknown_gap.raw_reason,
            rog_map::ProjectionClassReason::HEADROOM_UNVERIFIED);
  EXPECT_EQ(unknown_gap_ramp.raw_reason,
            rog_map::ProjectionClassReason::GROUND_UNVERIFIED);

  rog_map::ProjectionLayer plate_gap_layer;
  plate_gap_layer.update(width, height, resolution, kOrigin, 1.0, config,
                         [resolution](int x, int) {
                           if (x == 4) {
                             return groundColumn(0.20, resolution);
                           }
                           return groundColumn(x >= 5 ? 0.05 : 0.0, resolution);
                         });
  const auto &plate = plate_gap_layer.cells().at(2U * width + 4U);
  const auto &plate_gap_ramp = plate_gap_layer.cells().at(2U * width + 8U);
  EXPECT_EQ(plate.type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(plate.raw_reason,
            rog_map::ProjectionClassReason::GROUND_UNVERIFIED);
  EXPECT_EQ(plate_gap_ramp.raw_reason,
            rog_map::ProjectionClassReason::GROUND_UNVERIFIED);
}

TEST(ProjectionClearance, ClearsOnlyZeroHitUnknownInsideCurrentRobotFootprint) {
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.observed_empty_as_free = true;
  config.clear_robot_footprint_unknown = true;
  config.robot_footprint_clear_length = 0.20;
  config.robot_footprint_clear_width = 0.20;
  layer.update(
      kWidth, kHeight, kResolution, kOrigin, 1.0, config, [](int, int) {
        rog_map::ColumnStats stats;
        stats.vertical_states.assign(11U, rog_map::VerticalVoxelState::UNKNOWN);
        return stats;
      });

  EXPECT_EQ(center(layer).type, rog_map::CellType::FREE);
  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::ROBOT_FOOTPRINT_CLEAR);
  EXPECT_EQ(center(layer).clearance_verified, 0U);
  EXPECT_EQ(layer.cells().front().type, rog_map::CellType::UNKNOWN);
}

TEST(ProjectionClearance, NoPriorFootprintClearAccumulatesConsecutiveFrames) {
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.require_ground_support = false;
  config.observed_empty_as_free = true;
  config.unknown_as_occupied = false;
  config.clear_robot_footprint_unknown = true;
  config.robot_footprint_clear_length = .20;
  config.robot_footprint_clear_width = .20;
  config.hysteresis_en = true;
  config.hysteresis_count = 2;
  const auto blocked = [](int, int) { return column({1, 2, 3, 4, 5}); };
  const auto blind = [](int, int) {
    rog_map::ColumnStats stats;
    stats.vertical_states.assign(11U, rog_map::VerticalVoxelState::UNKNOWN);
    stats.vertical_states.front() = rog_map::VerticalVoxelState::KNOWN_FREE;
    stats.observed_count = 1;
    return stats;
  };

  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config, blocked);
  ASSERT_EQ(center(layer).type, rog_map::CellType::OCCUPIED);
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.1, config, blind);
  ASSERT_EQ(center(layer).raw_reason, rog_map::ProjectionClassReason::ROBOT_FOOTPRINT_CLEAR);
  EXPECT_EQ(center(layer).type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(center(layer).pending_count, 1U);
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.2, config, blind);
  EXPECT_EQ(center(layer).type, rog_map::CellType::FREE);
  EXPECT_EQ(center(layer).mask, 1U);
  EXPECT_EQ(center(layer).pending_count, 0U);

  // A new measured return must still block immediately and restart clearing.
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.3, config, blocked);
  EXPECT_EQ(center(layer).type, rog_map::CellType::OCCUPIED);
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.4, config, blind);
  EXPECT_EQ(center(layer).type, rog_map::CellType::OCCUPIED);
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.5, config, blocked);
  EXPECT_EQ(center(layer).pending_count, 0U);
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.6, config, blind);
  EXPECT_EQ(center(layer).type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(center(layer).pending_count, 1U);
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.7, config, blind);
  EXPECT_EQ(center(layer).type, rog_map::CellType::FREE);
}

TEST(ProjectionClearance, DisappearedObstacleCanReturnToAllowedUnknown) {
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.unknown_as_occupied = false;
  config.clearance_unknown_as_occupied = false;
  config.hysteresis_en = true;
  config.hysteresis_count = 2;
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               [](int, int) { return column({1, 2, 3, 4, 5}); });
  ASSERT_EQ(center(layer).type, rog_map::CellType::OCCUPIED);
  const auto blind = [](int, int) {
    rog_map::ColumnStats stats;
    stats.vertical_states.assign(11U, rog_map::VerticalVoxelState::UNKNOWN);
    return stats;
  };
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.1, config, blind);
  ASSERT_EQ(center(layer).raw_type, rog_map::CellType::UNKNOWN);
  EXPECT_EQ(center(layer).pending_count, 1U);
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.2, config, blind);
  EXPECT_EQ(center(layer).type, rog_map::CellType::UNKNOWN);
  EXPECT_EQ(center(layer).mask, 1U);
}

TEST(ProjectionClearance,
     ClearsZeroHitHeadroomUnverifiedInsideCurrentRobotFootprint) {
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.observed_empty_as_free = true;
  config.clear_robot_footprint_unknown = true;
  config.robot_footprint_clear_length = 0.20;
  config.robot_footprint_clear_width = 0.20;
  const auto headroom_unverified = [](int, int) {
    rog_map::ColumnStats stats;
    stats.vertical_states.assign(11U, rog_map::VerticalVoxelState::UNKNOWN);
    stats.vertical_states.front() = rog_map::VerticalVoxelState::KNOWN_FREE;
    stats.observed_count = 1;
    return stats;
  };
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               headroom_unverified);

  EXPECT_EQ(center(layer).type, rog_map::CellType::FREE);
  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::ROBOT_FOOTPRINT_CLEAR);
  const auto &outside = layer.cells().at(2U * kWidth + 4U);
  EXPECT_EQ(outside.type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(outside.raw_reason,
            rog_map::ProjectionClassReason::HEADROOM_UNVERIFIED);
}

TEST(ProjectionClearance, BridgesOnePriorNoDataCellFromTwoCardinalSupports) {
  rog_map::ProjectionLayer layer;
  auto config = requiredSupportConfig();
  config.clear_robot_footprint_unknown = true;
  config.robot_footprint_clear_length = 0.20;
  config.robot_footprint_clear_width = 0.20;
  config.observed_ground_support_bridge_en = true;
  config.observed_ground_support_bridge_min_neighbors = 2;
  config.observed_ground_support_bridge_max_height_delta = 0.06;
  config.observed_ground_support_bridge_hysteresis_count = 2;

  const auto scanner = [](int x, int y) {
    if (x == 2 && y == 2) {
      return emptyColumn(kResolution);
    }
    auto stats = groundColumn(0.05, kResolution);
    attachSupport(stats, 0.05);
    return stats;
  };

  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config, scanner);
  EXPECT_EQ(center(layer).type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(center(layer).ground_support_bridge_count, 1U);

  layer.update(kWidth, kHeight, kResolution, kOrigin, 2.0, config, scanner);
  EXPECT_EQ(center(layer).type, rog_map::CellType::FREE);
  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::GROUND_BRIDGE_CLEARANCE_OK);
  EXPECT_EQ(center(layer).ground_bridge_verified, 1U);
  EXPECT_EQ(center(layer).ground_support_bridge_count, 2U);
}

TEST(ProjectionClearance, ObservedSupportBridgeRejectsOccupiedReturn) {
  rog_map::ProjectionLayer layer;
  auto config = requiredSupportConfig();
  config.clear_robot_footprint_unknown = true;
  config.robot_footprint_clear_length = 0.20;
  config.robot_footprint_clear_width = 0.20;
  config.observed_ground_support_bridge_en = true;
  config.observed_ground_support_bridge_min_neighbors = 2;
  config.observed_ground_support_bridge_hysteresis_count = 1;

  const auto scanner = [](int x, int y) {
    if (x == 2 && y == 2) {
      auto stats = column({1, 2, 3, 4, 5});
      attachSupport(stats, 0.05);
      return stats;
    }
    auto stats = groundColumn(0.05, kResolution);
    attachSupport(stats, 0.05);
    return stats;
  };

  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config, scanner);
  EXPECT_EQ(center(layer).type, rog_map::CellType::OCCUPIED);
  EXPECT_NE(center(layer).raw_reason,
            rog_map::ProjectionClassReason::GROUND_BRIDGE_CLEARANCE_OK);
  EXPECT_EQ(center(layer).ground_support_bridge_count, 0U);
}

TEST(ProjectionClearance,
     MarksZeroHitNearFieldForPriorWithoutOpeningDynamicLayer) {
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.observed_empty_as_free = true;
  config.clear_robot_footprint_unknown = true;
  config.robot_footprint_clear_length = 0.20;
  config.robot_footprint_clear_width = 0.20;
  config.near_field_prior_fill_en = true;
  config.near_field_prior_fill_length = 0.60;
  config.near_field_prior_fill_width = 0.40;
  layer.update(
      kWidth, kHeight, kResolution, kOrigin, 1.0, config, [](int, int) {
        rog_map::ColumnStats stats;
        stats.vertical_states.assign(11U, rog_map::VerticalVoxelState::UNKNOWN);
        stats.vertical_states.front() = rog_map::VerticalVoxelState::KNOWN_FREE;
        stats.observed_count = 1;
        return stats;
      });

  const auto &outside_footprint = layer.cells().at(2U * kWidth + 4U);
  EXPECT_EQ(outside_footprint.type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(outside_footprint.raw_reason,
            rog_map::ProjectionClassReason::HEADROOM_UNVERIFIED);
  EXPECT_EQ(outside_footprint.near_field_prior_fill_eligible, 1U);
  EXPECT_EQ(layer.mask().at(2U * kWidth + 4U), 0U);
}

TEST(ProjectionClearance, FootprintClearSurvivesOccupiedHoleFilling) {
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.clear_robot_footprint_unknown = true;
  config.robot_footprint_clear_length = 0.05;
  config.robot_footprint_clear_width = 0.05;
  config.mask_filter_en = true;
  config.fill_occ_min = 7;
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               [](int x, int y) {
                 if (x == 2 && y == 2) {
                   rog_map::ColumnStats stats;
                   stats.vertical_states.assign(
                       11U, rog_map::VerticalVoxelState::UNKNOWN);
                   return stats;
                 }
                 return column({6});
               });

  EXPECT_EQ(center(layer).type, rog_map::CellType::FREE);
  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::ROBOT_FOOTPRINT_CLEAR);
  EXPECT_FALSE(center(layer).hole_filled);
  EXPECT_EQ(layer.mask().at(2U * kWidth + 2U), 1U);
}

TEST(ProjectionClearance, FootprintClearTracksPoseWithoutLeavingAFreeTrail) {
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.clear_robot_footprint_unknown = true;
  config.robot_footprint_clear_length = 0.20;
  config.robot_footprint_clear_width = 0.20;
  config.robot_x = 0.15;
  const auto unknown_scanner = [](int, int) {
    rog_map::ColumnStats stats;
    stats.vertical_states.assign(11U, rog_map::VerticalVoxelState::UNKNOWN);
    return stats;
  };
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               unknown_scanner);
  EXPECT_EQ(layer.cells().at(2U * kWidth + 1U).type, rog_map::CellType::FREE);

  config.robot_x = 0.35;
  layer.updateDirty(kWidth, kHeight, kResolution, kOrigin, 2.0, config,
                    unknown_scanner, {}, false);

  EXPECT_EQ(layer.cells().at(2U * kWidth + 1U).type,
            rog_map::CellType::UNKNOWN);
  EXPECT_EQ(layer.cells().at(2U * kWidth + 3U).type, rog_map::CellType::FREE);
}

TEST(ProjectionClearance, FootprintClearUsesRobotYawAtEnvelopeBoundary) {
  auto config = clearanceConfig();
  config.clear_robot_footprint_unknown = true;
  config.robot_footprint_clear_length = 0.40;
  config.robot_footprint_clear_width = 0.20;
  const auto unknown_scanner = [](int, int) {
    rog_map::ColumnStats stats;
    stats.vertical_states.assign(11U, rog_map::VerticalVoxelState::UNKNOWN);
    return stats;
  };

  rog_map::ProjectionLayer aligned_layer;
  config.robot_yaw = 0.0;
  aligned_layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
                       unknown_scanner);
  EXPECT_EQ(aligned_layer.cells().at(2U * kWidth + 4U).type,
            rog_map::CellType::FREE);

  rog_map::ProjectionLayer rotated_layer;
  config.robot_yaw = 0.5 * std::acos(-1.0);
  rotated_layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
                       unknown_scanner);
  EXPECT_EQ(rotated_layer.cells().at(2U * kWidth + 4U).type,
            rog_map::CellType::UNKNOWN);
}

TEST(ProjectionClearance, FootprintClearNeverOverridesAnOccupiedReturn) {
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.min_observed_voxels = 2;
  config.clear_robot_footprint_unknown = true;
  config.near_field_prior_fill_en = true;
  layer.update(
      kWidth, kHeight, kResolution, kOrigin, 1.0, config, [](int, int) {
        auto stats = column({6});
        stats.vertical_states.assign(11U, rog_map::VerticalVoxelState::UNKNOWN);
        stats.vertical_states.at(6U) = rog_map::VerticalVoxelState::OCCUPIED;
        stats.observed_count = 1;
        stats.occupied_count = 1;
        return stats;
      });

  EXPECT_EQ(center(layer).type, rog_map::CellType::UNKNOWN);
  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::INSUFFICIENT_OBSERVATION);
  EXPECT_EQ(center(layer).traversable, 0U);
  EXPECT_EQ(center(layer).near_field_prior_fill_eligible, 0U);
}

TEST(ProjectionClearance, DoesNotAddSlopeAndStepAllowances) {
  rog_map::ProjectionLayer layer;
  auto config = clearanceConfig();
  config.max_ground_step = 0.05;
  config.max_ground_slope_deg = 28.0;
  layer.update(kWidth, kHeight, kResolution, kOrigin, 1.0, config,
               [](int x, int) { return x < 2 ? column({1}) : column({2}); });

  EXPECT_EQ(center(layer).type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(center(layer).raw_reason,
            rog_map::ProjectionClassReason::GROUND_UNVERIFIED);
}

TEST(QueryAdapter, ExposesSnapshotTimestamp) {
  auto snapshot = std::make_shared<rog_map::MapSnapshot>();
  snapshot->sequence = 3U;
  snapshot->snapshot_sequence = 3U;
  snapshot->stamp = 42.25;
  snapshot->commit_stamp = 42.50;
  snapshot->width = 2;
  snapshot->height = 2;
  snapshot->resolution = 1.0;
  snapshot->values.assign(4U, 0U);
  snapshot->values[0] = 254U;
  snapshot->dynamic_values = {254U, 0U, 0U, 0U};
  snapshot->prior_occupied.assign(4U, 0U);
  snapshot->types.assign(4U, static_cast<uint8_t>(rog_map::CellType::FREE));
  snapshot->types[0] = static_cast<uint8_t>(rog_map::CellType::OCCUPIED);
  snapshot->raw_types.assign(4U, static_cast<uint8_t>(rog_map::CellType::FREE));
  snapshot->candidate_types = snapshot->raw_types;
  snapshot->base_types = snapshot->types;
  snapshot->pending_types = snapshot->raw_types;
  snapshot->pending_counts = {1U, 0U, 0U, 0U};
  snapshot->raw_reasons.assign(
      4U, static_cast<uint8_t>(rog_map::ProjectionClassReason::CLEARANCE_OK));
  snapshot->raw_reasons[0] =
      static_cast<uint8_t>(rog_map::ProjectionClassReason::HEADROOM_BLOCKED);
  snapshot->candidate_reasons = snapshot->raw_reasons;
  snapshot->hole_filled = {0U, 0U, 0U, 0U};
  snapshot->headroom.assign(4U, 1.0F);
  snapshot->headroom[0] = 0.18F;
  snapshot->obstacle_hold_remaining = {0.30F, 0.0F, 0.0F, 0.0F};
  snapshot->distances.assign(4U, 1.0);

  rog_map::QueryAdapter adapter;
  adapter.update(snapshot, nullptr);
  const auto result = adapter.query(Eigen::Vector3d(0.25, 0.25, 0.0));

  ASSERT_TRUE(result.ok);
  ASSERT_TRUE(result.projected_cost_valid);
  EXPECT_EQ(result.projected_cost, 254U);
  EXPECT_DOUBLE_EQ(result.snapshot_stamp, snapshot->stamp);
  EXPECT_DOUBLE_EQ(result.snapshot_commit_stamp, snapshot->commit_stamp);
  EXPECT_DOUBLE_EQ(result.snapshot_processing_age_ms, 250.0);
  ASSERT_TRUE(result.projection.valid);
  EXPECT_EQ(result.projection.cost_source,
            rog_map::ProjectedCostSource::DYNAMIC_PROJECTION);
  EXPECT_EQ(result.projection.cost_cause,
            rog_map::ProjectedCostCause::OBSTACLE_HOLD);
  EXPECT_EQ(result.projection.cell_type,
            static_cast<uint8_t>(rog_map::CellType::OCCUPIED));
  EXPECT_EQ(
      result.projection.raw_reason,
      static_cast<uint8_t>(rog_map::ProjectionClassReason::HEADROOM_BLOCKED));
  EXPECT_FLOAT_EQ(result.projection.headroom, 0.18F);
  EXPECT_EQ(result.projection.base_type,
            static_cast<uint8_t>(rog_map::CellType::OCCUPIED));
  EXPECT_EQ(result.projection.pending_count, 1U);
  EXPECT_FLOAT_EQ(result.projection.obstacle_hold_remaining, 0.30F);
  EXPECT_STREQ(rog_map::projectionClassReasonName(result.projection.raw_reason),
               "HEADROOM_BLOCKED");
}

TEST(QueryAdapter, IdentifiesPriorMapAsFusedLethalSource) {
  auto snapshot = std::make_shared<rog_map::MapSnapshot>();
  snapshot->stamp = 10.0;
  snapshot->commit_stamp = 10.01;
  snapshot->width = 2;
  snapshot->height = 2;
  snapshot->resolution = 1.0;
  snapshot->values.assign(4U, 0U);
  snapshot->values[0] = 254U;
  snapshot->dynamic_values.assign(4U, 0U);
  snapshot->prior_occupied = {1U, 0U, 0U, 0U};
  snapshot->types.assign(4U, static_cast<uint8_t>(rog_map::CellType::FREE));
  snapshot->raw_reasons.assign(
      4U, static_cast<uint8_t>(rog_map::ProjectionClassReason::CLEARANCE_OK));
  snapshot->candidate_reasons = snapshot->raw_reasons;
  snapshot->distances.assign(4U, 1.0);

  rog_map::QueryAdapter adapter;
  adapter.update(snapshot, nullptr);
  const auto result = adapter.query(Eigen::Vector3d(0.25, 0.25, 0.0));

  ASSERT_TRUE(result.ok);
  ASSERT_TRUE(result.projection.valid);
  EXPECT_EQ(result.projection.cost_source,
            rog_map::ProjectedCostSource::PRIOR_MAP);
  EXPECT_EQ(result.projection.cost_cause,
            rog_map::ProjectedCostCause::PRIOR_MAP);
  EXPECT_TRUE(result.projection.prior_occupied);
  EXPECT_EQ(result.projection.dynamic_cost, 0U);
}

TEST(QueryAdapter, IdentifiesFailClosedMaskDenoise) {
  auto snapshot = std::make_shared<rog_map::MapSnapshot>();
  snapshot->stamp = 12.0;
  snapshot->commit_stamp = 12.01;
  snapshot->width = 2;
  snapshot->height = 2;
  snapshot->resolution = 1.0;
  snapshot->values = {254U, 0U, 0U, 0U};
  snapshot->dynamic_values = snapshot->values;
  snapshot->prior_occupied.assign(4U, 0U);
  snapshot->types = {static_cast<uint8_t>(rog_map::CellType::UNKNOWN),
                     static_cast<uint8_t>(rog_map::CellType::FREE),
                     static_cast<uint8_t>(rog_map::CellType::FREE),
                     static_cast<uint8_t>(rog_map::CellType::FREE)};
  snapshot->raw_types.assign(4U,
                             static_cast<uint8_t>(rog_map::CellType::PASSABLE));
  snapshot->candidate_types = snapshot->raw_types;
  snapshot->base_types.assign(4U,
                              static_cast<uint8_t>(rog_map::CellType::FREE));
  snapshot->base_types[0] = static_cast<uint8_t>(rog_map::CellType::OCCUPIED);
  snapshot->pending_types = snapshot->raw_types;
  snapshot->pending_counts.assign(4U, 0U);
  snapshot->raw_reasons.assign(
      4U, static_cast<uint8_t>(rog_map::ProjectionClassReason::CLEARANCE_OK));
  snapshot->candidate_reasons = snapshot->raw_reasons;
  snapshot->hole_filled.assign(4U, 0U);
  snapshot->distances.assign(4U, 0.0);

  rog_map::QueryAdapter adapter;
  adapter.update(snapshot, nullptr);
  const auto result = adapter.query(Eigen::Vector3d(0.25, 0.25, 0.0));

  ASSERT_TRUE(result.ok);
  ASSERT_TRUE(result.projection.valid);
  EXPECT_EQ(result.projection.cost_source,
            rog_map::ProjectedCostSource::DYNAMIC_PROJECTION);
  EXPECT_EQ(result.projection.cost_cause,
            rog_map::ProjectedCostCause::MASK_DENOISE_TO_UNKNOWN);
  EXPECT_STREQ(rog_map::projectedCostCauseName(result.projection.cost_cause),
               "MASK_DENOISE_TO_UNKNOWN");
}

TEST(QueryAdapter, BatchUsesOneSnapshotAndReturnsProjectedCosts) {
  auto snapshot = std::make_shared<rog_map::MapSnapshot>();
  snapshot->sequence = 17U;
  snapshot->snapshot_sequence = 17U;
  snapshot->stamp = 51.0;
  snapshot->width = 3;
  snapshot->height = 2;
  snapshot->resolution = 1.0;
  snapshot->values = {0U, 1U, 2U, 3U, 4U, 5U};
  snapshot->distances.assign(6U, 1.0);

  rog_map::QueryAdapter adapter;
  adapter.update(snapshot, nullptr);
  const auto results = adapter.queryBatch(
      {Eigen::Vector3d(0.25, 0.25, 0.0), Eigen::Vector3d(2.25, 1.25, 0.0)});

  ASSERT_EQ(results.size(), 2U);
  for (const auto &result : results) {
    ASSERT_TRUE(result.ok);
    ASSERT_TRUE(result.projected_cost_valid);
    EXPECT_EQ(result.snapshot_sequence, 17U);
    EXPECT_DOUBLE_EQ(result.snapshot_stamp, 51.0);
  }
  EXPECT_EQ(results[0].projected_cost, 0U);
  EXPECT_EQ(results[1].projected_cost, 5U);
}

TEST(QueryAdapter, SamplesDistanceAtPublishedCellCenter) {
  auto snapshot = std::make_shared<rog_map::MapSnapshot>();
  snapshot->width = 4;
  snapshot->height = 4;
  snapshot->resolution = 0.5;
  snapshot->origin_x = -1.0;
  snapshot->origin_y = -2.0;
  snapshot->values.assign(16U, 0U);
  snapshot->distances = {0.0,  1.0,  2.0,  3.0,  10.0, 11.0, 12.0, 13.0,
                         20.0, 21.0, 22.0, 23.0, 30.0, 31.0, 32.0, 33.0};
  snapshot->field_clamp_distance = false;
  snapshot->interpolation = rog_map::InterpolationMode::BILINEAR;

  rog_map::QueryAdapter adapter;
  adapter.update(snapshot, nullptr);
  const Eigen::Vector3d cell_center(
      snapshot->origin_x + 1.5 * snapshot->resolution,
      snapshot->origin_y + 2.5 * snapshot->resolution, 0.0);
  const auto result = adapter.query(cell_center);

  ASSERT_TRUE(result.ok);
  EXPECT_DOUBLE_EQ(result.distance, snapshot->distances.at(9U));
}

TEST(DynamicLayer, EvaluateMatchesStoredDistanceAtCellCenter) {
  constexpr int width = 5;
  constexpr int height = 5;
  constexpr double resolution = 0.2;
  const Eigen::Vector2d origin(-0.5, -0.5);
  std::vector<uint8_t> mask(static_cast<size_t>(width * height), 1U);
  mask.at(0U) = 0U;

  rog_map::DynamicLayer field;
  field.rebuild(width, height, resolution, origin, mask, 0.0, 3.0, -1.0, true,
                rog_map::InterpolationMode::BILINEAR);
  const auto distances = field.distances();
  const int x = 2;
  const int y = 2;
  const Eigen::Vector3d cell_center(
      origin.x() + (static_cast<double>(x) + 0.5) * resolution,
      origin.y() + (static_cast<double>(y) + 0.5) * resolution, 0.0);
  double distance = 0.0;
  Eigen::Vector3d gradient = Eigen::Vector3d::Zero();
  field.evaluate(cell_center, distance, gradient);

  EXPECT_DOUBLE_EQ(distance, distances.at(static_cast<size_t>(y * width + x)));
}

TEST(PriorMapFusion, KnownFreeFillsOnlyDynamicUnknown) {
  rog_map::PriorMapData prior;
  prior.loaded = true;
  prior.transform_ready = true;
  prior.projection_cache_ready = true;
  prior.cached_mask = {1U, 1U, 0U, 1U};
  prior.cached_free_mask = {1U, 1U, 0U, 0U};

  // Match the active configuration: unknown_as_occupied encodes UNKNOWN as
  // value 254/mask 0, exactly like OCCUPIED. The semantic mask disambiguates
  // it.
  const std::vector<uint8_t> dynamic_mask = {0U, 0U, 1U, 0U};
  const std::vector<uint8_t> dynamic_values = {254U, 254U, 0U, 254U};
  const std::vector<uint8_t> dynamic_unknown_mask = {1U, 0U, 0U, 1U};
  std::vector<uint8_t> fused_mask;
  std::vector<uint8_t> fused_values;
  rog_map::fusePriorMapProjection(
      true, true, prior, dynamic_mask, dynamic_values, dynamic_unknown_mask,
      {0U, 0U, 0U, 0U}, {0U, 0U, 0U, 0U}, fused_mask, fused_values);

  EXPECT_EQ(fused_mask, (std::vector<uint8_t>{1U, 0U, 0U, 0U}));
  EXPECT_EQ(fused_values, (std::vector<uint8_t>{0U, 254U, 254U, 254U}));
}

TEST(PriorMapFusion, DoesNotTrustStaticFreeUnlessExplicitlyEnabled) {
  rog_map::PriorMapData prior;
  prior.loaded = true;
  prior.transform_ready = true;
  prior.projection_cache_ready = true;
  prior.cached_mask = {1U};
  prior.cached_free_mask = {1U};
  std::vector<uint8_t> fused_mask;
  std::vector<uint8_t> fused_values;

  rog_map::fusePriorMapProjection(true, false, prior, {0U}, {254U}, {1U}, {0U},
                                  {0U}, fused_mask, fused_values);

  EXPECT_EQ(fused_mask, (std::vector<uint8_t>{0U}));
  EXPECT_EQ(fused_values, (std::vector<uint8_t>{254U}));
}

TEST(PriorMapFusion, VerifiedNavigationClearanceOverridesOnlyItsPriorCell) {
  rog_map::PriorMapData prior;
  prior.loaded = true;
  prior.transform_ready = true;
  prior.projection_cache_ready = true;
  prior.cached_mask = {0U, 0U, 0U};
  prior.cached_free_mask = {0U, 0U, 0U};
  std::vector<uint8_t> fused_mask;
  std::vector<uint8_t> fused_values;

  rog_map::fusePriorMapProjection(true, false, prior, {1U, 1U, 0U},
                                  {0U, 50U, 254U}, {0U, 0U, 0U}, {0U, 0U, 0U},
                                  {1U, 0U, 0U}, fused_mask, fused_values);

  EXPECT_EQ(fused_mask, (std::vector<uint8_t>{1U, 0U, 0U}));
  EXPECT_EQ(fused_values, (std::vector<uint8_t>{0U, 254U, 254U}));
}

TEST(PriorMapFusion, RequiredSupportDisablesEveryTwoDimensionalFreeFill) {
  rog_map::PriorMapData prior;
  prior.loaded = true;
  prior.transform_ready = true;
  prior.projection_cache_ready = true;
  prior.cached_mask = {1U};
  prior.cached_free_mask = {1U};
  std::vector<uint8_t> fused_mask;
  std::vector<uint8_t> fused_values;

  rog_map::fusePriorMapProjection(true, true, prior, {0U}, {254U}, {1U}, {1U},
                                  {0U}, fused_mask, fused_values, true);

  EXPECT_EQ(fused_mask, (std::vector<uint8_t>{0U}));
  EXPECT_EQ(fused_values, (std::vector<uint8_t>{254U}));
}

TEST(PriorMapFusion, BoundedNearFieldFillRequiresKnownStaticFree) {
  rog_map::PriorMapData prior;
  prior.loaded = true;
  prior.transform_ready = true;
  prior.projection_cache_ready = true;
  prior.cached_mask = {1U, 1U, 0U};
  prior.cached_free_mask = {1U, 0U, 0U};
  std::vector<uint8_t> fused_mask;
  std::vector<uint8_t> fused_values;

  rog_map::fusePriorMapProjection(
      true, false, prior, {0U, 0U, 0U}, {254U, 254U, 254U}, {0U, 0U, 0U},
      {1U, 1U, 1U}, {0U, 0U, 0U}, fused_mask, fused_values);

  EXPECT_EQ(fused_mask, (std::vector<uint8_t>{1U, 0U, 0U}));
  EXPECT_EQ(fused_values, (std::vector<uint8_t>{0U, 254U, 254U}));
}

TEST(PriorMapFusion, MissingTransformBlocksEveryCell) {
  rog_map::PriorMapData prior;
  prior.loaded = true;
  std::vector<uint8_t> fused_mask;
  std::vector<uint8_t> fused_values;

  rog_map::fusePriorMapProjection(true, false, prior, {1U, 1U}, {0U, 0U},
                                  {0U, 0U}, {0U, 0U}, {0U, 0U}, fused_mask,
                                  fused_values);

  EXPECT_EQ(fused_mask, (std::vector<uint8_t>{0U, 0U}));
  EXPECT_EQ(fused_values, (std::vector<uint8_t>{254U, 254U}));
}

TEST(PriorMapFusion, TransformChangeInvalidatesProjectionCache) {
  rog_map::PriorMapData prior;
  prior.loaded = true;
  prior.origin_yaw = 0.0;
  prior.projection_cache_ready = true;

  EXPECT_TRUE(rog_map::updatePriorMapTransform(
      prior, rog_map::PriorMapTransform2D{1.0, 2.0, 0.25}));
  EXPECT_TRUE(prior.transform_ready);
  EXPECT_FALSE(prior.projection_cache_ready);

  prior.projection_cache_ready = true;
  EXPECT_FALSE(rog_map::updatePriorMapTransform(
      prior, rog_map::PriorMapTransform2D{1.0, 2.0, 0.25}));
  EXPECT_TRUE(prior.projection_cache_ready);

  EXPECT_TRUE(rog_map::updatePriorMapTransform(
      prior, rog_map::PriorMapTransform2D{1.1, 2.0, 0.25}));
  EXPECT_FALSE(prior.projection_cache_ready);

  EXPECT_TRUE(rog_map::invalidatePriorMapTransform(prior));
  EXPECT_FALSE(prior.transform_ready);
  EXPECT_FALSE(rog_map::invalidatePriorMapTransform(prior));
}

TEST(PriorMapFusion, TransformUsesConfiguredHorizontalTolerance) {
  rog_map::PriorMapData prior;
  prior.loaded = true;
  rog_map::PriorMapTransform2D transform;
  transform.roll = 2.0e-5;
  transform.pitch = -2.0e-5;

  EXPECT_FALSE(rog_map::updatePriorMapTransform(prior, transform));
  EXPECT_FALSE(prior.transform_ready);
  EXPECT_TRUE(rog_map::updatePriorMapTransform(prior, transform, 0.01));
  EXPECT_TRUE(prior.transform_ready);

  prior.projection_cache_ready = true;
  transform.pitch = 0.02;
  EXPECT_TRUE(rog_map::updatePriorMapTransform(prior, transform, 0.01));
  EXPECT_FALSE(prior.transform_ready);
  EXPECT_FALSE(prior.projection_cache_ready);

  EXPECT_FALSE(rog_map::updatePriorMapTransform(prior, transform, -1.0));
  EXPECT_FALSE(prior.transform_ready);
}

TEST(PriorMapLoader, PreservesMapSaverGrayAsUnknownWithStandardThreshold) {
  const auto test_dir = std::filesystem::temp_directory_path() /
                        "rog_map_prior_loader_threshold_test";
  std::filesystem::create_directories(test_dir);
  const auto pgm_path = test_dir / "map.pgm";
  const auto yaml_path = test_dir / "map.yaml";
  {
    std::ofstream pgm(pgm_path);
    pgm << "P2\n3 1\n255\n0 205 254\n";
  }
  {
    std::ofstream yaml(yaml_path);
    yaml << "image: map.pgm\n"
         << "resolution: 0.05\n"
         << "origin: [0.0, 0.0, 0.0]\n"
         << "negate: 0\n"
         << "occupied_thresh: 0.65\n"
         << "free_thresh: 0.196\n";
  }

  const auto prior = rog_map::loadPriorMap(yaml_path.string(), "");
  ASSERT_EQ(prior.occupied.size(), 3U);
  ASSERT_EQ(prior.known_free.size(), 3U);
  EXPECT_EQ(prior.occupied, (std::vector<uint8_t>{1U, 0U, 0U}));
  EXPECT_EQ(prior.known_free, (std::vector<uint8_t>{0U, 0U, 1U}));

  std::filesystem::remove_all(test_dir);
}

TEST(PriorMapLoader, GroundElevationAppliesMapToRogZTranslation) {
  const auto test_dir = std::filesystem::temp_directory_path() /
                        "rog_map_ground_elevation_transform_test";
  std::filesystem::create_directories(test_dir);
  const auto pgm_path = test_dir / "map.pgm";
  const auto yaml_path = test_dir / "map.yaml";
  {
    std::ofstream pgm(pgm_path);
    pgm << "P2\n3 3\n255\n"
        << "255 255 255\n255 255 255\n255 255 255\n";
  }
  {
    std::ofstream yaml(yaml_path);
    yaml << "image: map.pgm\n"
         << "resolution: 1.0\n"
         << "origin: [-1.5, -1.5, 0.0]\n"
         << "negate: 0\n"
         << "occupied_thresh: 0.65\n"
         << "free_thresh: 0.25\n"
         << "ground_elevation:\n"
         << "  default_height: 0.0\n"
         << "  patches:\n"
         << "    - bounds: [0.25, -0.5, 1.25, 0.5]\n"
         << "      reference: [0.25, 0.0, 0.10]\n"
         << "      slope: [0.20, 0.0]\n";
  }

  auto prior = rog_map::loadPriorMap(yaml_path.string(), "");
  rog_map::PriorMapTransform2D transform;
  transform.tz = 0.06;
  ASSERT_TRUE(rog_map::updatePriorMapTransform(prior, transform));
  double support_z = 0.0;
  ASSERT_TRUE(rog_map::priorMapGroundSupport(prior, 0.0, 0.0, support_z));
  EXPECT_NEAR(support_z, -0.06, 1.0e-9);
  ASSERT_TRUE(rog_map::priorMapGroundSupport(prior, 0.75, 0.0, support_z));
  EXPECT_NEAR(support_z, 0.14, 1.0e-9);

  transform.pitch = 2.0e-5;
  EXPECT_TRUE(rog_map::updatePriorMapTransform(prior, transform));
  EXPECT_FALSE(prior.transform_ready);
  EXPECT_FALSE(rog_map::priorMapGroundSupport(prior, 0.0, 0.0, support_z));

  std::filesystem::remove_all(test_dir);
}

TEST(PriorMapLoader, LoadsAlignedSixteenBitGroundElevationGridFailClosed) {
  const auto test_dir = std::filesystem::temp_directory_path() /
                        "rog_map_ground_elevation_grid_test";
  std::filesystem::create_directories(test_dir);
  const auto pgm_path = test_dir / "map.pgm";
  const auto elevation_path = test_dir / "elevation.pgm";
  const auto yaml_path = test_dir / "map.yaml";
  {
    std::ofstream pgm(pgm_path);
    pgm << "P2\n3 2\n255\n255 255 255\n255 255 255\n";
  }
  {
    std::ofstream elevation(elevation_path, std::ios::binary);
    elevation << "P5\n3 2\n65535\n";
    const std::array<uint16_t, 6> values{65535U, 1100U, 1200U,
                                         1000U,  1050U, 65535U};
    for (const uint16_t value : values) {
      elevation.put(static_cast<char>((value >> 8U) & 0xffU));
      elevation.put(static_cast<char>(value & 0xffU));
    }
  }
  {
    std::ofstream yaml(yaml_path);
    yaml << "image: map.pgm\n"
         << "resolution: 1.0\n"
         << "origin: [0.0, 0.0, 0.0]\n"
         << "negate: 0\n"
         << "occupied_thresh: 0.65\n"
         << "free_thresh: 0.25\n"
         << "ground_elevation:\n"
         << "  default_height: 0.0\n"
         << "  grid:\n"
         << "    image: elevation.pgm\n"
         << "    scale: 0.001\n"
         << "    offset: -1.0\n"
         << "    no_data: 65535\n"
         << "  patches:\n"
         << "    - bounds: [0.0, 1.0, 1.0, 2.0]\n"
         << "      reference: [0.0, 1.0, 0.25]\n"
         << "      slope: [0.0, 0.0]\n";
  }

  auto prior = rog_map::loadPriorMap(yaml_path.string(), "");
  EXPECT_TRUE(prior.ground_elevation_grid_loaded);
  EXPECT_EQ(prior.ground_elevation_grid_width, 3);
  EXPECT_EQ(prior.ground_elevation_grid_height, 2);
  ASSERT_TRUE(
      rog_map::updatePriorMapTransform(prior, rog_map::PriorMapTransform2D{}));

  double support_z = 0.0;
  ASSERT_TRUE(rog_map::priorMapGroundSupport(prior, 0.5, 0.5, support_z));
  EXPECT_NEAR(support_z, 0.0, 1.0e-9);
  ASSERT_TRUE(rog_map::priorMapGroundSupport(prior, 1.5, 1.5, support_z));
  EXPECT_NEAR(support_z, 0.10, 1.0e-9);
  EXPECT_FALSE(rog_map::priorMapGroundSupport(prior, 2.5, 0.5, support_z));

  // A deliberately surveyed patch may authorize and override a no-data cell.
  ASSERT_TRUE(rog_map::priorMapGroundSupport(prior, 0.5, 1.5, support_z));
  EXPECT_NEAR(support_z, 0.25, 1.0e-9);

  std::filesystem::remove_all(test_dir);
}

TEST(PriorMapLoader, RejectsMismatchedGroundElevationGridDimensions) {
  const auto test_dir = std::filesystem::temp_directory_path() /
                        "rog_map_ground_elevation_grid_dimensions_test";
  std::filesystem::create_directories(test_dir);
  const auto pgm_path = test_dir / "map.pgm";
  const auto elevation_path = test_dir / "elevation.pgm";
  const auto yaml_path = test_dir / "map.yaml";
  {
    std::ofstream pgm(pgm_path);
    pgm << "P2\n2 2\n255\n255 255 255 255\n";
  }
  {
    std::ofstream elevation(elevation_path);
    elevation << "P2\n1 2\n65535\n1000 1000\n";
  }
  {
    std::ofstream yaml(yaml_path);
    yaml << "image: map.pgm\n"
         << "resolution: 1.0\n"
         << "origin: [0.0, 0.0, 0.0]\n"
         << "negate: 0\n"
         << "occupied_thresh: 0.65\n"
         << "free_thresh: 0.25\n"
         << "ground_elevation:\n"
         << "  default_height: 0.0\n"
         << "  grid: {image: elevation.pgm, scale: 0.001, offset: -1.0, "
            "no_data: 65535}\n";
  }

  EXPECT_THROW(rog_map::loadPriorMap(yaml_path.string(), ""),
               std::runtime_error);
  std::filesystem::remove_all(test_dir);
}

TEST(PriorMapLoader, RejectsMalformedGroundElevation) {
  const auto test_dir = std::filesystem::temp_directory_path() /
                        "rog_map_ground_elevation_malformed_test";
  std::filesystem::create_directories(test_dir);
  const auto pgm_path = test_dir / "map.pgm";
  const auto yaml_path = test_dir / "map.yaml";
  {
    std::ofstream pgm(pgm_path);
    pgm << "P2\n1 1\n255\n255\n";
  }
  {
    std::ofstream yaml(yaml_path);
    yaml << "image: map.pgm\n"
         << "resolution: 1.0\n"
         << "origin: [0.0, 0.0, 0.0]\n"
         << "negate: 0\n"
         << "occupied_thresh: 0.65\n"
         << "free_thresh: 0.25\n"
         << "ground_elevation:\n"
         << "  patches: []\n";
  }

  EXPECT_THROW(rog_map::loadPriorMap(yaml_path.string(), ""),
               std::runtime_error);
  std::filesystem::remove_all(test_dir);
}

TEST(PriorMapLoader, SlidingProjectionKeepsGroundSupportAligned) {
  const auto test_dir = std::filesystem::temp_directory_path() /
                        "rog_map_ground_elevation_cache_test";
  std::filesystem::create_directories(test_dir);
  const auto pgm_path = test_dir / "map.pgm";
  const auto yaml_path = test_dir / "map.yaml";
  {
    std::ofstream pgm(pgm_path);
    pgm << "P2\n5 3\n255\n";
    for (int index = 0; index < 15; ++index) {
      pgm << "255 ";
    }
    pgm << "\n";
  }
  {
    std::ofstream yaml(yaml_path);
    yaml << "image: map.pgm\n"
         << "resolution: 1.0\n"
         << "origin: [0.0, 0.0, 0.0]\n"
         << "negate: 0\n"
         << "occupied_thresh: 0.65\n"
         << "free_thresh: 0.25\n"
         << "ground_elevation:\n"
         << "  default_height: 0.0\n"
         << "  patches:\n"
         << "    - bounds: [2.0, 0.0, 5.0, 3.0]\n"
         << "      reference: [2.0, 0.0, 0.20]\n"
         << "      slope: [0.10, 0.0]\n";
  }

  auto prior = rog_map::loadPriorMap(yaml_path.string(), "");
  rog_map::PriorMapTransform2D transform;
  transform.tz = 0.10;
  ASSERT_TRUE(rog_map::updatePriorMapTransform(prior, transform));
  ASSERT_TRUE(rog_map::refreshPriorMapProjectionCache(prior, 0, 0, 3, 3, 1.0,
                                                      0.0, 0.0));
  ASSERT_EQ(prior.cached_ground_support_mask.size(), 9U);
  EXPECT_EQ(prior.cached_ground_support_mask.at(3U), 1U);
  EXPECT_NEAR(prior.cached_ground_support_z.at(3U), -0.10, 1.0e-6);
  EXPECT_NEAR(prior.cached_ground_support_z.at(5U), 0.15, 1.0e-6);

  ASSERT_TRUE(rog_map::refreshPriorMapProjectionCache(prior, 1, 0, 3, 3, 1.0,
                                                      1.0, 0.0));
  EXPECT_NEAR(prior.cached_ground_support_z.at(3U), -0.10, 1.0e-6);
  EXPECT_NEAR(prior.cached_ground_support_z.at(4U), 0.15, 1.0e-6);
  EXPECT_NEAR(prior.cached_ground_support_z.at(5U), 0.25, 1.0e-6);

  std::filesystem::remove_all(test_dir);
}

rog_map::ColumnStats preciseTunnelColumn(bool ground, bool roof, double ceiling = 0.2499) {
  rog_map::ColumnStats stats;
  stats.scan_z_min_abs = 0.025;
  stats.vertical_states.assign(16, rog_map::VerticalVoxelState::KNOWN_FREE);
  stats.hit_z_min.assign(16, NAN);
  stats.hit_z_max.assign(16, NAN);
  stats.hit_stamps.assign(16, 0.0);
  stats.observed_count = 16;
  stats.prior_known_free = 1U;
  stats.last_hit_time = 1.0;
  const auto hit = [&](int index, float low, float high) {
    stats.vertical_states[index] = rog_map::VerticalVoxelState::OCCUPIED;
    stats.hit_z_min[index] = low;
    stats.hit_z_max[index] = high;
    stats.hit_stamps[index] = 1.0;
    ++stats.occupied_count;
  };
  if (ground) { hit(0, 0.0F, 0.0F); }
  if (roof) {
    const int first = static_cast<int>(std::floor(ceiling / 0.05));
    for (int index = first; index <= first + 3; ++index) {
      hit(index, static_cast<float>(ceiling + (index - first) * 0.05),
          static_cast<float>(ceiling + (index - first) * 0.05));
    }
  }
  return stats;
}

rog_map::ProjectionLayerConfig downhillTunnelConfig() {
  auto config = clearanceConfig();
  config.robot_x = 0.325;
  config.robot_y = 0.325;
  config.reference_ground_z_abs = 0.15;
  config.vehicle_height = 0.24;
  config.headroom_margin = 0.0;
  config.headroom_voxel_inset_fraction = 0.0;
  config.surface_height_delta_max = 0.12;
  config.ground_seed_tolerance = 0.18;
  config.ground_seed_radius = 2.0;
  config.observed_empty_as_free = true;
  config.min_observed_overhead_headroom_known_ratio = 0.0;
  config.unknown_as_occupied = false;
  config.clearance_unknown_as_occupied = false;
  return config;
}

TEST(ProjectionClearance, RawHeightsPreserve249mmTunnelFor240mmBody) {
  rog_map::ProjectionLayer layer;
  auto config = downhillTunnelConfig();
  layer.update(13, 13, 0.05, kOrigin, 1.0, config, [](int, int) {
    return preciseTunnelColumn(true, true);
  });
  const auto &cell = layer.cells().at(84);
  EXPECT_EQ(cell.type, rog_map::CellType::PASSABLE);
  EXPECT_NEAR(cell.headroom, 0.2499, 1e-6);
  EXPECT_NEAR(cell.ground_z_abs, 0.0, 1e-6);
}

TEST(ProjectionClearance, DownhillRoofFindsSparseLowerLandingOutsideOldRadius) {
  rog_map::ProjectionLayer layer;
  auto config = downhillTunnelConfig();
  layer.update(25, 25, 0.05, kOrigin, 1.0, config, [](int x, int y) {
    const double distance = std::hypot(x - 12, y - 12) * 0.05;
    return preciseTunnelColumn(distance >= 0.35 && distance <= 0.45,
                               x == 12 && y == 12);
  });
  const auto &roof = layer.cells().at(312);
  EXPECT_EQ(roof.type, rog_map::CellType::PASSABLE);
  EXPECT_EQ(roof.raw_reason, rog_map::ProjectionClassReason::OVERHEAD_CLEARANCE_OK);
  EXPECT_NEAR(roof.headroom, 0.2499, 1e-6);
  EXPECT_EQ(rog_map::navigationOverlayValue(roof), 0);
}

TEST(ProjectionClearance, PendingRoofIsLocallyBlockedButNotGlobalObstacle) {
  rog_map::ProjectionLayer layer;
  auto config = downhillTunnelConfig();
  layer.update(13, 13, 0.05, kOrigin, 1.0, config, [](int x, int y) {
    return preciseTunnelColumn(false, x == 6 && y == 6);
  });
  const auto &roof = layer.cells().at(84);
  EXPECT_EQ(roof.type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(roof.value, 254U);
  EXPECT_EQ(roof.raw_reason, rog_map::ProjectionClassReason::OVERHEAD_GROUND_UNVERIFIED);
  EXPECT_EQ(rog_map::navigationOverlayValue(roof), -1);
}

TEST(ProjectionClearance, UnsupportedPriorFreeReturnNeedsPersistence) {
  rog_map::ProjectionLayer layer;
  auto config = downhillTunnelConfig();
  config.prior_free_uncertain_obstacle_confirmations = 3;
  const auto scan = [](int x, int y) {
    return preciseTunnelColumn(false, x == 6 && y == 6);
  };

  layer.update(13, 13, 0.05, kOrigin, 1.0, config, scan);
  const auto &first = layer.cells().at(84);
  EXPECT_EQ(first.type, rog_map::CellType::UNKNOWN);
  EXPECT_EQ(first.raw_type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(first.raw_reason,
            rog_map::ProjectionClassReason::OVERHEAD_GROUND_UNVERIFIED);
  EXPECT_EQ(rog_map::navigationOverlayValue(first), -1);

  layer.update(13, 13, 0.05, kOrigin, 1.1, config, scan);
  EXPECT_EQ(layer.cells().at(84).type, rog_map::CellType::UNKNOWN);
  EXPECT_EQ(layer.cells().at(84).pending_count, 2U);

  layer.update(13, 13, 0.05, kOrigin, 1.2, config, scan);
  EXPECT_EQ(layer.cells().at(84).type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(layer.cells().at(84).raw_reason,
            rog_map::ProjectionClassReason::OVERHEAD_GROUND_UNVERIFIED);
  // Once persistent evidence is confirmed it must not become UNKNOWN every
  // time the generic hysteresis counter is reset by an OCCUPIED commit.
  for (int frame = 3; frame < 12; ++frame) {
    layer.update(13, 13, 0.05, kOrigin, 1.0 + .1 * frame, config, scan);
    EXPECT_EQ(layer.cells().at(84).type, rog_map::CellType::OCCUPIED);
  }
}

TEST(ProjectionClearance, MeasuredLowBeamStillBlocksAndMarksGlobalObstacle) {
  rog_map::ProjectionLayer layer;
  auto config = downhillTunnelConfig();
  layer.update(13, 13, 0.05, kOrigin, 1.0, config, [](int x, int y) {
    const bool roof = x == 6 && y == 6;
    return preciseTunnelColumn(!roof, roof, 0.21);
  });
  const auto &roof = layer.cells().at(84);
  EXPECT_EQ(roof.type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(roof.raw_reason, rog_map::ProjectionClassReason::HEADROOM_BLOCKED);
  EXPECT_EQ(rog_map::navigationOverlayValue(roof), 100);
}

TEST(ProjectionClearance, RoofFloorHistoryExpiresWithoutRenewingOnDirtyUpdate) {
  rog_map::ProjectionLayer layer;
  auto config = downhillTunnelConfig();
  layer.update(13, 13, 0.05, kOrigin, 1.0, config, [](int, int) {
    return preciseTunnelColumn(true, false);
  });
  const auto scan = [](int x, int y) {
    return preciseTunnelColumn(false, x == 6 && y == 6);
  };
  layer.update(13, 13, 0.05, kOrigin, 1.1, config, scan);
  EXPECT_EQ(layer.cells().at(84).type, rog_map::CellType::PASSABLE);
  layer.updateDirty(13, 13, 0.05, kOrigin, 1.9, config, scan, {}, false);
  EXPECT_EQ(layer.cells().at(84).type, rog_map::CellType::PASSABLE);
  layer.updateDirty(13, 13, 0.05, kOrigin, 2.1, config, scan, {}, false);
  EXPECT_EQ(layer.cells().at(84).type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(layer.cells().at(84).raw_reason,
            rog_map::ProjectionClassReason::OVERHEAD_GROUND_UNVERIFIED);
}

TEST(ProjectionClearance, LocalGroundRecheckRetainsNonzeroBodyObservationGate) {
  rog_map::ProjectionLayer layer;
  auto config = downhillTunnelConfig();
  config.min_observed_overhead_headroom_known_ratio = 0.8;
  const auto scan = [](bool known, int x, int y) {
    const bool roof = x == 6 && y == 6;
    auto stats = preciseTunnelColumn(!roof, roof);
    if (roof && !known) {
      for (auto &state : stats.vertical_states) {
        if (state == rog_map::VerticalVoxelState::KNOWN_FREE) {
          state = rog_map::VerticalVoxelState::UNKNOWN;
        }
      }
      stats.observed_count = stats.occupied_count;
    }
    return stats;
  };
  layer.update(13, 13, 0.05, kOrigin, 1.0, config,
               [&](int x, int y) { return scan(false, x, y); });
  EXPECT_EQ(layer.cells().at(84).type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(layer.cells().at(84).raw_reason, rog_map::ProjectionClassReason::HEADROOM_UNVERIFIED);
  layer.update(13, 13, 0.05, kOrigin, 1.1, config,
               [&](int x, int y) { return scan(true, x, y); });
  EXPECT_EQ(layer.cells().at(84).type, rog_map::CellType::PASSABLE);
}

TEST(ProjectionClearance, DownhillContactTangentOnlyResolvesCurrentGroundEnvelope) {
  rog_map::ProjectionLayer layer;
  auto config = downhillTunnelConfig();
  config.robot_x = 0.225;
  config.reference_ground_z_abs = 0.03;
  config.reference_ground_plane_valid = true;
  config.reference_ground_slope_x = -0.12;
  config.clear_robot_footprint_unknown = true;
  config.robot_footprint_clear_length = 0.82;
  config.robot_footprint_clear_width = 0.82;
  const auto scan = [](int x, int y) {
    return preciseTunnelColumn(false, (x == 10 || x == 20) && y == 6);
  };
  layer.update(25, 13, 0.05, kOrigin, 1.0, config, scan);
  const auto &near = layer.cells().at(6 * 25 + 10);
  EXPECT_EQ(near.type, rog_map::CellType::PASSABLE);
  EXPECT_NEAR(near.reference_ground_z_abs, -0.006, 1e-6);
  EXPECT_EQ(layer.cells().at(6 * 25 + 20).raw_reason,
            rog_map::ProjectionClassReason::OVERHEAD_GROUND_UNVERIFIED);

  config.reference_ground_plane_valid = false;
  layer.updateDirty(25, 13, 0.05, kOrigin, 1.1, config, scan, {}, false);
  EXPECT_EQ(layer.cells().at(6 * 25 + 10).raw_reason,
            rog_map::ProjectionClassReason::OVERHEAD_GROUND_UNVERIFIED);
}

TEST(ProjectionClearance, ThinRoofUsesSameDownhillContactTangentAsThickLeadingFace) {
  rog_map::ProjectionLayer layer;
  auto config = downhillTunnelConfig();
  config.robot_x = 0.225;
  config.reference_ground_z_abs = 0.03;
  config.reference_ground_plane_valid = true;
  config.reference_ground_slope_x = -0.12;
  config.clear_robot_footprint_unknown = true;
  config.robot_footprint_clear_length = 0.82;
  config.robot_footprint_clear_width = 0.82;
  const auto scan = [](int x, int y) {
    auto stats = preciseTunnelColumn(false, x == 10 && y == 6);
    if (x == 10 && y == 6) {
      for (int index = 5; index <= 7; ++index) {
        stats.vertical_states[index] = rog_map::VerticalVoxelState::KNOWN_FREE;
      }
      stats.occupied_count = 1;
    }
    return stats;
  };
  layer.update(25, 13, 0.05, kOrigin, 1.0, config, scan);
  const auto &roof = layer.cells().at(6 * 25 + 10);
  EXPECT_EQ(roof.type, rog_map::CellType::PASSABLE);
  EXPECT_EQ(roof.raw_reason, rog_map::ProjectionClassReason::OVERHEAD_CLEARANCE_OK);
  EXPECT_NEAR(roof.headroom, 0.2559, 1e-6);

  config.min_observed_overhead_headroom_known_ratio = 0.8;
  layer.update(25, 13, 0.05, kOrigin, 1.1, config, [&](int x, int y) {
    auto stats = scan(x, y);
    for (int index = 0; index < 4; ++index) {
      stats.vertical_states[index] = rog_map::VerticalVoxelState::UNKNOWN;
    }
    return stats;
  });
  EXPECT_EQ(layer.cells().at(6 * 25 + 10).type, rog_map::CellType::OCCUPIED);
  EXPECT_EQ(layer.cells().at(6 * 25 + 10).clearance_verified, 0U);
}

} // namespace
