#!/usr/bin/env python3

import os
import random
import math
import xml.etree.ElementTree as ET

import yaml
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, OpaqueFunction, TimerAction
from launch.substitutions import Command, FindExecutable, LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


def _load_yaml(path):
    with open(path, "r", encoding="utf-8") as config_file:
        return yaml.safe_load(config_file) or {}


def _world_name(context):
    package_share = get_package_share_directory("rm_27_stimulation")
    config_path = LaunchConfiguration("worlds_config").perform(context)
    world_key = LaunchConfiguration("sim_world").perform(context)

    worlds = _load_yaml(config_path).get("worlds", {})
    if world_key not in worlds:
        valid_worlds = ", ".join(sorted(worlds.keys()))
        raise RuntimeError(f"Unknown world '{world_key}'. Valid worlds: {valid_worlds}")

    relative_path = worlds[world_key].get("path")
    if not relative_path:
        raise RuntimeError(f"World '{world_key}' does not define a 'path' field")

    world_path = os.path.join(package_share, "world", relative_path)
    if not os.path.exists(world_path):
        raise RuntimeError(f"World file does not exist: {world_path}")

    root = ET.parse(world_path).getroot()
    world_element = root.find("world")
    if world_element is None or not world_element.get("name"):
        raise RuntimeError(f"World file does not define a named <world>: {world_path}")

    return world_element.get("name")


def _spawn_robot(context, *args, **kwargs):
    del args, kwargs

    config_path = LaunchConfiguration("spawn_poses_config").perform(context)
    world_name = LaunchConfiguration("sim_world").perform(context)
    entity_name = LaunchConfiguration("entity").perform(context)
    spawn_delay = float(LaunchConfiguration("spawn_delay").perform(context))
    robot_description_file = LaunchConfiguration("robot_description_file")
    robot_description = {
        "robot_description": ParameterValue(
            Command([FindExecutable(name="xacro"), " ", robot_description_file]),
            value_type=str,
        )
    }

    if LaunchConfiguration("rviz_spawn").perform(context).lower() in (
        "true",
        "1",
        "yes",
    ):
        return [
            Node(
                package="rm_27_stimulation",
                executable="spawn_from_rviz.py",
                output="screen",
                parameters=[
                    {
                        "use_sim_time": True,
                        "map_yaml": LaunchConfiguration("spawn_map_yaml"),
                        "world_name": _world_name(context),
                        "entity": entity_name,
                    }
                ],
            )
        ]

    spawn_poses = _load_yaml(config_path).get("spawn_poses", {})
    if world_name not in spawn_poses:
        valid_worlds = ", ".join(sorted(spawn_poses.keys()))
        raise RuntimeError(
            f"Unknown spawn pose world '{world_name}'. Valid worlds: {valid_worlds}"
        )

    pose = spawn_poses[world_name]
    if LaunchConfiguration("random_spawn").perform(context).lower() in (
        "true",
        "1",
        "yes",
    ):
        candidates = _load_yaml(
            LaunchConfiguration("random_spawn_config").perform(context)
        ).get(world_name, [])
        if not candidates:
            raise RuntimeError(f"No validated random spawn positions for {world_name}")
        seed = LaunchConfiguration("random_seed").perform(context).strip()
        rng = random.Random(int(seed) if seed else None)
        pose = dict(rng.choice(candidates))
        pose["yaw"] = rng.uniform(-math.pi, math.pi)
        print(f"[random_spawn] seed={seed or 'system'} pose={pose}", flush=True)
    spawn_arguments = [
        "-world",
        _world_name(context),
        "-name",
        entity_name,
        "-param",
        "robot_description",
        "-x",
        str(pose.get("x", 0.0)),
        "-y",
        str(pose.get("y", 0.0)),
        "-z",
        str(pose.get("z", 0.0)),
        "-R",
        str(pose.get("roll", 0.0)),
        "-P",
        str(pose.get("pitch", 0.0)),
        "-Y",
        str(pose.get("yaw", 0.0)),
    ]

    return [
        TimerAction(
            period=spawn_delay,
            actions=[
                Node(
                    package="ros_gz_sim",
                    executable="create",
                    name="spawn_rm27_sentry",
                    output="screen",
                    arguments=spawn_arguments,
                    parameters=[robot_description],
                )
            ],
        )
    ]


def generate_launch_description():
    package_share = get_package_share_directory("rm_27_stimulation")
    robot_description_file = LaunchConfiguration("robot_description_file")
    use_sim_time = LaunchConfiguration("use_sim_time")

    robot_description = {
        "robot_description": ParameterValue(
            Command([FindExecutable(name="xacro"), " ", robot_description_file]),
            value_type=str,
        )
    }

    return LaunchDescription(
        [
            DeclareLaunchArgument(
                "sim_world",
                default_value="RMUC2026",
                description="World key used to select the spawn pose",
            ),
            DeclareLaunchArgument(
                "spawn_poses_config",
                default_value=os.path.join(package_share, "config", "spawn_poses.yaml"),
                description="YAML file describing robot spawn poses",
            ),
            DeclareLaunchArgument(
                "worlds_config",
                default_value=os.path.join(package_share, "config", "worlds.yaml"),
                description="YAML file describing available Gazebo worlds",
            ),
            DeclareLaunchArgument(
                "robot_description_file",
                default_value=os.path.join(
                    package_share, "urdf", "simulation_waking_robot.xacro"
                ),
                description="Robot xacro file to spawn",
            ),
            DeclareLaunchArgument(
                "entity",
                default_value="rm27_sentry",
                description="Gazebo entity name",
            ),
            DeclareLaunchArgument(
                "use_sim_time",
                default_value="true",
                description="Use Gazebo simulation time",
            ),
            DeclareLaunchArgument(
                "spawn_delay",
                default_value="6.0",
                description="Delay before spawning the robot, in seconds",
            ),
            DeclareLaunchArgument(
                "spawn_timeout",
                default_value="60.0",
                description="Kept for launch-file compatibility; ros_gz_sim create does not use it",
            ),
            Node(
                package="joint_state_publisher",
                executable="joint_state_publisher",
                name="joint_state_publisher",
                output="screen",
                parameters=[{"use_sim_time": use_sim_time}, robot_description],
            ),
            Node(
                package="robot_state_publisher",
                executable="robot_state_publisher",
                name="robot_state_publisher",
                output="screen",
                parameters=[{"use_sim_time": use_sim_time}, robot_description],
            ),
            DeclareLaunchArgument("rviz_spawn", default_value="false"),
            DeclareLaunchArgument("spawn_map_yaml", default_value=""),
            DeclareLaunchArgument("random_spawn", default_value="false"),
            DeclareLaunchArgument("random_seed", default_value=""),
            DeclareLaunchArgument(
                "random_spawn_config",
                default_value=os.path.join(
                    package_share, "config", "random_spawn_poses.yaml"
                ),
            ),
            OpaqueFunction(function=_spawn_robot),
        ]
    )
