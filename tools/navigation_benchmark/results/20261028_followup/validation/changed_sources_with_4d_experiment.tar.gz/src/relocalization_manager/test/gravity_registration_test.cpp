// Copyright 2026
// SPDX-License-Identifier: Apache-2.0
#include <gtest/gtest.h>

#include <cstdio>
#include <limits>
#include <random>
#include <unistd.h>

#include "pcl/common/transforms.h"
#include "relocalization_manager/relocalization_manager.hpp"

namespace rm = relocalization_manager;

namespace
{
using Cloud = pcl::PointCloud<pcl::PointXYZ>;

Cloud sampleCloud()
{
  std::mt19937 generator(42);
  std::uniform_real_distribution<float> d(-1.0F, 1.0F);
  Cloud cloud;
  for (int i = 0; i < 1200; ++i) {
    cloud.push_back(pcl::PointXYZ(2.0F * d(generator), d(generator), 0.7F * d(generator)));
  }
  return cloud;
}

Eigen::Isometry3d pose(double roll, double pitch, double yaw)
{
  Eigen::Isometry3d t = Eigen::Isometry3d::Identity();
  t.linear() = (Eigen::AngleAxisd(yaw, Eigen::Vector3d::UnitZ()) *
    Eigen::AngleAxisd(pitch, Eigen::Vector3d::UnitY()) *
    Eigen::AngleAxisd(roll, Eigen::Vector3d::UnitX())).toRotationMatrix();
  t.translation() = Eigen::Vector3d(0.08, -0.06, 0.04);
  return t;
}

bool loadTarget(rm::SmallGicpVerifier & verifier, const Cloud & target)
{
  char path[] = "/tmp/relocalization_gravity_test_XXXXXX";
  const int fd = mkstemp(path);
  if (fd < 0) { ADD_FAILURE() << "mkstemp failed"; return false; }
  close(fd);
  if (pcl::io::savePCDFileBinary(path, target) != 0) {
    std::remove(path); ADD_FAILURE() << "PCD write failed"; return false;
  }
  const bool loaded = verifier.loadGlobalMap(path);
  std::remove(path);
  return loaded;
}

rm::SmallGicpParams testParams(bool constrained, double max_mean_error = 0.30)
{
  rm::SmallGicpParams params;
  params.gravity_aligned_registration = constrained;
  params.max_mean_error = max_mean_error;
  params.global_leaf_size = 0.02F;
  params.registered_leaf_size = 0.02F;
  params.num_threads = 1;
  params.num_neighbors = 20;
  params.max_iterations = 80;
  params.max_dist_sq = 1.0F;
  params.min_inliers = 100;
  params.filter_source_by_prior_map = false;
  params.max_delta_xy = 1.0;
  params.max_delta_z = 1.0;
  params.max_delta_yaw = 1.0;
  return params;
}

rm::VerificationResult registerCloud(const Cloud & source, const Eigen::Isometry3d & expected,
  bool constrained, double max_mean_error = 0.30)
{
  Cloud target;
  pcl::transformPointCloud(source, target, expected.matrix().cast<float>());
  const auto params = testParams(constrained, max_mean_error);
  rm::SmallGicpVerifier verifier(rclcpp::get_logger("gravity_test"), params, {});
  if (!loadTarget(verifier, target)) { ADD_FAILURE() << "load failed"; return {}; }
  return verifier.verify(source, Eigen::Isometry3d::Identity());
}
}  // namespace

TEST(GravityRegistration, RecoversTranslationAndYaw)
{
  const auto expected = pose(0, 0, 0.07);
  const auto result = registerCloud(sampleCloud(), expected, true);
  ASSERT_TRUE(result.accepted);
  EXPECT_LT((result.transform.matrix() - expected.matrix()).norm(), 0.01);
  EXPECT_TRUE(rm::validGravityAlignedInitialGuess(result.transform));
}

TEST(GravityRegistration, TiltIsNotHiddenAndLegacyRemainsSixDof)
{
  const auto cloud = sampleCloud();
  const auto expected = pose(0.10, -0.08, 0.04);
  const auto constrained = registerCloud(cloud, expected, true);
  const auto legacy = registerCloud(cloud, expected, false);
  ASSERT_TRUE(legacy.accepted);
  if (constrained.accepted) {
    EXPECT_TRUE(rm::validGravityAlignedInitialGuess(constrained.transform));
  }
  EXPECT_LT((legacy.transform.matrix() - expected.matrix()).norm(), 0.02);
  ASSERT_TRUE(std::isfinite(constrained.mean_error));
  ASSERT_GT(constrained.mean_error, legacy.mean_error + 1e-5);
  const double threshold = (constrained.mean_error + legacy.mean_error) / 2.0;
  const auto constrained_checked = registerCloud(cloud, expected, true, threshold);
  const auto legacy_checked = registerCloud(cloud, expected, false, threshold);
  EXPECT_TRUE(constrained_checked.converged);
  EXPECT_FALSE(constrained_checked.accepted);
  EXPECT_GT(constrained_checked.mean_error, threshold);
  EXPECT_TRUE(legacy_checked.accepted);
  EXPECT_LT(legacy_checked.mean_error, threshold);
}

TEST(GravityRegistration, InvalidInitialGuessRejected)
{
  const auto params = testParams(true);
  rm::SmallGicpVerifier verifier(rclcpp::get_logger("gravity_test"), params, {});
  const auto cloud = sampleCloud();
  ASSERT_TRUE(loadTarget(verifier, cloud));
  ASSERT_TRUE(verifier.verify(cloud, Eigen::Isometry3d::Identity()).accepted);
  EXPECT_FALSE(verifier.verify(cloud, pose(0.03, 0, 0)).accepted);
  auto invalid = Eigen::Isometry3d::Identity();
  invalid.linear()(0, 0) = 2.0;
  EXPECT_FALSE(verifier.verify(cloud, invalid).accepted);
  invalid = Eigen::Isometry3d::Identity();
  invalid.linear()(0, 0) = -1.0;
  EXPECT_FALSE(verifier.verify(cloud, invalid).accepted);
  invalid = Eigen::Isometry3d::Identity();
  invalid.translation().x() = std::numeric_limits<double>::quiet_NaN();
  EXPECT_FALSE(verifier.verify(cloud, invalid).accepted);
}
