// Copyright 2026
// SPDX-License-Identifier: Apache-2.0
#ifndef RELOCALIZATION_MANAGER__GRAVITY_ALIGNED_REGISTRATION_HPP_
#define RELOCALIZATION_MANAGER__GRAVITY_ALIGNED_REGISTRATION_HPP_

#include <Eigen/Geometry>
#include <cmath>

namespace relocalization_manager
{
// The frames must have independently verified matching gravity directions.
// Reject inconsistent initial guesses; do not silently project them onto SE(2).
inline bool validGravityAlignedInitialGuess(const Eigen::Isometry3d & transform)
{
  const auto & r = transform.linear();
  constexpr double tolerance = 1e-9;
  return transform.matrix().allFinite() &&
         (r.transpose() * r - Eigen::Matrix3d::Identity()).norm() < tolerance &&
         std::abs(r.determinant() - 1.0) < tolerance &&
         (r * Eigen::Vector3d::UnitZ() - Eigen::Vector3d::UnitZ()).norm() < tolerance &&
         (transform.matrix().row(3) - Eigen::RowVector4d(0, 0, 0, 1)).norm() < tolerance;
}

// small_gicp uses right-multiplied increments ordered rx, ry, rz, tx, ty, tz.
// Decouple and freeze rx/ry, keeping the residual and candidate error unchanged.
struct GravityAlignedFactor
{
  template<typename Target, typename Source, typename Tree>
  void update_linearized_system(
    const Target &, const Source &, const Tree &, const Eigen::Isometry3d &,
    Eigen::Matrix<double, 6, 6> * h, Eigen::Matrix<double, 6, 1> * b, double *) const
  {
    h->topRows<2>().setZero();
    h->leftCols<2>().setZero();
    (*h)(0, 0) = 1.0;
    (*h)(1, 1) = 1.0;
    b->head<2>().setZero();
  }

  template<typename Target, typename Source>
  void update_error(const Target &, const Source &, const Eigen::Isometry3d &, double *) const {}
};
}  // namespace relocalization_manager
#endif  // RELOCALIZATION_MANAGER__GRAVITY_ALIGNED_REGISTRATION_HPP_
