# RM27 新场景与导航地图对齐审计

## 结论

新场景可以独立新增为 `RM27_Blender`，保留原 `RMUC2026` 默认和所有导航/传感器/里程计配置。不能认定旧 `RMUC2026` 栅格、高程图或 PCD 与新场地对齐；本包不创建旧图别名。几何转换正确与导航地图对齐正确，是两项分别需要验证的条件。

## 固定来源

- 导航仓库：[PnX-HKUSTGZ/sentry_navgation_RM27](https://github.com/PnX-HKUSTGZ/sentry_navgation_RM27/tree/b55a9d22b677f37409b60af19c8e80a6d980fdc4)，审计提交 `b55a9d22b677f37409b60af19c8e80a6d980fdc4`。
- 新场 MJCF：[rm27_battlefield_mjcf/model.xml](https://github.com/CosmosMount/rm_mjcf/blob/38230a17573816c6a46cb75c1e35a9308af0b12f/rm27_battlefield_mjcf/model.xml)，提交 `38230a17573816c6a46cb75c1e35a9308af0b12f`。
- 本次按固定提交读取了 19 份相关源码/地图文件，均用 Git blob SHA 校验字节一致性；索引见 `reference_source_manifest.json`。没有重新下载整个导航仓库。

## 已核实的启动链

`sim_with_nav.launch.py` 分别启动 `rm_simulation.launch.py`、`spawn_robot.launch.py`，再延时启动 `rm_navigation_simulation_launch.py`。

- `worlds.yaml` 是 world key→相对 world 路径及可选 `nav_world` 的注册表。
- `spawn_robot.launch.py` 还会独立读取 `spawn_poses.yaml`，必须有同名 key；仅加 worlds key 不足以生成机器人。
- world 文件名后缀不是限制，现有代码按 XML 读取 `<world name=...>`，传给 `ros_gz_sim create -world`。
- `rm_simulation.launch.py` 固定 `gz_version=8`，默认 physics plugin 为 `gz-physics-dartsim-plugin`。CMake 依赖 `gz-sim8` 等 Harmonic 库。README 所写 Classic 与现有代码不符。
- 原 world 用 DART，并指定 Bullet 碰撞检测器以缓解轮球在 STL 接缝卡住。新 world 采用同样检测器配置；动力学数值等价性没有运行证明。
- `sim_with_nav` 的 `nav_world=auto` 遇到未配置映射时会拒绝启动导航，这是本次安全接入所保留的检查。
- 当前一键入口默认 `use_ground_truth_odom=true`。本转换没有改变它，也没有改为 Point-LIO。底层 ground-truth localizer 用第一次 Gazebo 位姿建立 `map→odom`，组合后的 map 坐标保留 Gazebo world 的坐标关系；它不会自动把新场几何配准到旧地图。

## 坐标与范围

### 旧 RMUC2026

[旧 world](https://github.com/PnX-HKUSTGZ/sentry_navgation_RM27/blob/b55a9d22b677f37409b60af19c8e80a6d980fdc4/src/rm_27_stimulation/world/RMUC2026_world/RMUC2026_world.world) 的 `map` 模型：

- mesh 为 `model://RMUC2026_world/meshes/RMUC2026.stl`
- scale=`1 1 1`，模型 pose=`0 0 1.65 0 0 0`，无附加 link/collision pose
- 地面模型中心 `(-0.025, 1.640, 0)`；声明平面尺寸 `29.10×14.95 m`，矩形范围 x=`[-14.575,14.525]`，y=`[-5.835,9.115]`
- 地面视觉略缩为 `28.90×14.75 m`；另有四道只参与碰撞的边界墙
- 原机器人 spawn=`(-11.7, 2.9, 0.06, roll=0,pitch=0,yaw=0)`，对应原地面 z=0

旧 STL 在仓库中是 9,926,934 字节的 blob，Git SHA=`8e066aa61472fd994abed9ed026f80217ed101d5`。本次只读获取没有成功返回该二进制大文件；因此没有取到顶点数据，不能声称测得旧 STL 精确包围盒、尺寸或逐顶点配准。上述范围来自 world 地面声明，不是 STL 测量结果。

### 新 RM27

MJCF 主场 body pose=`(-0.02,-1.624344,1.641344)`，主场 ground box 经 body 变换后中心为 `(0,0,-0.1)`，顶面 z=0，全尺寸 `29.05×16.05×0.2 m`，XY 范围 x=`[-14.525,14.525]`、y=`[-8.025,8.025]`。

转换检查得到整个新场碰撞包围盒为 x=`[-14.525,14.525]`、y=`[-8.025,8.025]`、z=`[-0.2,2.746706]` m。视觉包围盒约 x=`[-14.901,14.861]`、y=`[-8.025,8.025]`、z=`[-0.2,3.486036]` m；视觉与碰撞范围本来就不同。

转换保留了 MJCF 世界坐标，world include pose 为零。不能再给新场整体加旧 `z=1.65`，否则已经落地的几何会再次被抬高。

如果某个局部 mesh 的原始坐标确实相同，仅比较两个主 body pose，会得到新→旧的候选平移 `(0.02,1.624344,0.008656)`。这只是坐标约定线索，并非测得的全场配准：新场有独立 body、新机库、隧道与移动/替换的发射区，且旧 STL 尚未读取。不得据此自动平移新场或旧图。

## 5 cm 栅格与高程图

[地图 YAML](https://github.com/PnX-HKUSTGZ/sentry_navgation_RM27/blob/b55a9d22b677f37409b60af19c8e80a6d980fdc4/src/pb2025_nav_bringup/map/simulation/RMUC2026.yaml) 已与二进制 PGM 一起读取：

- `resolution=0.05`，`origin=[-14.6,-5.86,0]`，PGM `583×300`
- 栅格外边界 x=`[-14.6,14.55]`，y=`[-5.86,9.14]`，零 yaw
- 像素中心 x=`-14.6+(col+0.5)×0.05`，y=`-5.86+(300-row-0.5)×0.05`
- 8-bit 占据图在 YAML 的阈值下有 114,018 个已知 free cell

新场南界 y=-8.025，比旧栅格下界还向南 2.165 m。其北端也不能通过简单复用 old origin 证明对齐。这是明确的覆盖范围差异，不只是在同一地图里换材质。

`RMUC2026_elevation.pgm` 为同尺寸的 16-bit big-endian PGM，`z=0.001×value-1.0`，`65535` 表示 no-data。读取统计：113,792 个有效支撑格、高度 z=`0…0.31 m`，226 个旧图 known-free cell 仍无高程支撑；不能把 no-data 当平地。

其头部记录并验证：

- 原占据图 SHA256=`2409c96c469adb81c2dbb2251c8978669d5dc2d9a34f53d3d315265b2b894c63`
- 原 world SHA256=`28e889f82166b90a94093c5a8334f230bec8abccf7f2b0b772373e80993f45e2`
- 记录的原 STL SHA256=`7c58d1775b7ffe7a74b763c8cc230be72cce0696b402cbaa30db3919a61e1e51`，因 STL 未取得，未独立验证此项

原高程生成器基于旧 occupancy、旧 STL、旧 world 的姿态，筛选坡度≤28°、高度≤0.60 m、可从地面坡度连续到达的支撑面，未知/断连区域 fail-closed。它只识别直接的 `ground_plane` 和单 `map` mesh，不支持本次 include 的复合场地。要给新场生成高程，需另行适配几何读取与支撑面提取，而非复制旧 elevation 文件。

## PCD、机器人与保留边界

审计提交的 tree 不包含 `RMUC2026.pcd`，只有 pcd 目录说明。因此旧 PCD 点云本身、坐标及新旧匹配质量都未核实。`nav2_params.yaml` 和 `minco_params.yaml` 仍有旧重定位初始化 `[-11.7,2.9,0.26,0,0,0]`，并有旧场用的 `prior_pcd_transform=[0,0,1.65,0,0,0]`。本安装器不复制、不更新这些值。

实际机器人 xacro 的 MID360 挂点为 `[0,0.18,0.14]`，与当前 ground-truth 配置一致；README 中的 0.28 m 不是该仿真 xacro 的值。轮碰撞球半径 0.06 m，base 初始离地 0.06 m；这些参数只用于解释出生高度，不在本次转换范围内修改。

## 最小安全接入及尚缺验收

使用 `integration/install_into_navigation.py`，只添加新 world 目录和新配置键；默认 dry-run，保留旧默认，缺少 `nav_world` 时不让一键导航误加载旧图。出生候选 `(-10,0,0.06,0)` 已做 0.7×0.7 m/1.2 m 高净空保守几何检查，但仍需 Gazebo 接触与运动验证。

尚未证明：旧 STL 精确几何、新旧地标配准、新栅格和高程、旧或新 PCD 的可定位性、Gazebo 的实际载入/接触/传感器输出、Nav2/MINCO 的运行与跨坡/隧道通行。当前云端没有 ROS 或 `gz` 可执行文件，安装器和静态几何测试通过不等于上述运行验收通过。
