# 技术参考与检查边界

- Gazebo Common 5 支持 Collada、STL 等模型格式：https://gazebosim.org/api/common/5/classgz_1_1common_1_1MeshManager.html
- Gazebo Harmonic Sensors/Ogre2 配置：https://gazebosim.org/docs/harmonic/sensors/
- Gazebo Harmonic 的 GPU 传感器可见渲染网格：https://gazebosim.org/docs/harmonic/actors/
- SDF 1.9 四元数 pose 定义：https://github.com/gazebosim/sdformat/blob/sdf14/sdf/1.9/pose.sdf
- MuJoCo mesh 凸包碰撞语义与 MSH 格式：https://mujoco.readthedocs.io/en/stable/XMLreference.html#asset-mesh
- Gazebo Sim 8 无界面渲染与 Ogre2/EGL：https://gazebosim.org/api/sim/8/headless_rendering.html

以上参考用于选择标准格式与解释接口。实际工件检查以 checks/ 内结果为准。Assimp 是独立格式解析器，不是 Gazebo 的 ColladaLoader；其通过结果不能替代 Gazebo 的运行验证。静态检查也不检测机器人控制、点云质量或导航收敛。
