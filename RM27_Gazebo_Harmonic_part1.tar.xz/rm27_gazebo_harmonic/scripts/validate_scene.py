#!/usr/bin/env python3
"""Offline structural/resource/mesh checks. Does not claim a Gazebo runtime test.
Python3 + numpy required. --source additionally verifies pinned-source hashes.
"""
import argparse, json, struct, hashlib, ctypes, ctypes.util, shutil, xml.etree.ElementTree as E
from pathlib import Path
import numpy as np
p=argparse.ArgumentParser();p.add_argument('--package',default=str(Path(__file__).resolve().parents[1]));p.add_argument('--source');p.add_argument('--report');a=p.parse_args();root=Path(a.package).resolve()
report={'validation_kind':'offline checks, not Gazebo/ROS runtime','checks':{},'warnings':[]}
def check(k,cond):
    report['checks'][k]=bool(cond)
    if not cond:raise AssertionError(k)
model=root/'models/rm27_battlefield/model.sdf';tree=E.parse(model).getroot();link=tree.find('model/link');visuals=link.findall('visual');cols=link.findall('collision');audit=json.loads((root/'checks/conversion_audit.json').read_text())
check('sdf_version_1_9',tree.get('version')=='1.9');check('static_model',tree.findtext('model/static')=='true');check('185_visuals',len(visuals)==185);check('607_collisions',len(cols)==607)
for tag,es in [('visual',visuals),('collision',cols)]:check(tag+'_names_unique',len({e.get('name') for e in es})==len(es))
check('no_unexpected_models_or_links',len(tree.findall('model'))==1 and len(tree.findall('model/link'))==1)
check('no_preview_geometry',not any(s in E.tostring(tree,encoding='unicode').lower() for s in ['studio','backdrop','softbox']))
refs=[]
for elem in visuals+cols:
    v=np.fromstring(elem.findtext('pose'),sep=' ');check('pose_'+elem.get('name'),len(v)==7 and np.all(np.isfinite(v)) and abs(np.linalg.norm(v[3:])-1)<1e-9)
    geom=elem.find('geometry');check('one_geometry_'+elem.get('name'),len(geom)==1)
    if geom.find('mesh') is not None:
        uri=geom.findtext('mesh/uri');check('model_uri_'+elem.get('name'),uri.startswith('model://rm27_battlefield/'));path=root/'models'/uri.removeprefix('model://');check('resource_'+elem.get('name'),path.is_file());refs.append(path)
    else:
        v=np.fromstring(geom.findtext('box/size'),sep=' ');check('box_'+elem.get('name'),len(v)==3 and np.all(v>0))
    if elem.tag=='visual':
        for k in ['ambient','diffuse','specular','emissive']:
            c=np.fromstring(elem.findtext('material/'+k),sep=' ');check('material_'+k+'_'+elem.get('name'),len(c)==4 and np.all((c>=0)&(c<=1)))
        check('opaque_'+elem.get('name'),float(elem.findtext('material/diffuse').split()[-1])==1)
ns={'c':'http://www.collada.org/2005/11/COLLADASchema'};meshes={};degenerate_visual=0;max_normal_err=0
for path in sorted(set(refs)):
    if path.suffix=='.dae':
        d=E.parse(path).getroot();check('axis_'+path.stem,d.findtext('c:asset/c:up_axis',namespaces=ns)=='Z_UP');check('unit_'+path.stem,d.find('c:asset/c:unit',ns).get('meter')=='1')
        v=np.fromstring(d.find(".//c:float_array[@id='positions-array']",ns).text,sep=' ').reshape(-1,3);n=np.fromstring(d.find(".//c:float_array[@id='normals-array']",ns).text,sep=' ').reshape(-1,3);tri=d.find('.//c:triangles',ns);inds=np.fromstring(tri.findtext('c:p',namespaces=ns),sep=' ',dtype=int).reshape(-1,3,2)
        check('indices_'+path.stem,len(inds)==int(tri.get('count')) and inds[:,:,0].min()>=0 and inds[:,:,0].max()<len(v) and inds[:,:,1].min()>=0 and inds[:,:,1].max()<len(n));check('finite_'+path.stem,np.all(np.isfinite(v)) and np.all(np.isfinite(n)))
        lengths=np.linalg.norm(n,axis=1);check('normals_'+path.stem,np.all((abs(lengths-1)<1e-6)|(lengths<1e-10)))
        fs=inds[:,:,0];norm=np.cross(v[fs[:,1]]-v[fs[:,0]],v[fs[:,2]]-v[fs[:,0]]);degenerate_visual+=int(np.sum(np.linalg.norm(norm,axis=1)<1e-14));meshes[path]=(v,fs)
        check('material_binding_'+path.stem,tri.get('material')==d.find('.//c:instance_material',ns).get('symbol'))
    else:
        raw=path.read_bytes();nf=struct.unpack('<I',raw[80:84])[0];check('stl_length_'+path.stem,len(raw)==84+nf*50);dt=np.dtype([('normal','<f4',(3,)),('vertices','<f4',(3,3)),('attr','<u2')]);data=np.frombuffer(raw,dt,nf,84);f=data['vertices'].astype(float);check('finite_'+path.stem,np.all(np.isfinite(f)))
        v,inv=np.unique(f.reshape(-1,3),axis=0,return_inverse=True);fs=inv.reshape(-1,3);edges=np.sort(np.concatenate([fs[:,[0,1]],fs[:,[1,2]],fs[:,[2,0]]]),axis=1);_,cnt=np.unique(edges,axis=0,return_counts=True);check('watertight_'+path.stem,np.all(cnt==2));volume=np.sum(np.einsum('ij,ij->i',f[:,0],np.cross(f[:,1],f[:,2])))/6;check('positive_volume_'+path.stem,volume>1e-14);meshes[path]=(v,fs)
# Recompute each world AABB from serialized resources and serialized quaternion.
def quatmat(q):
    x,y,z,w=q;return np.array([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]])
records={x['name']:x for x in audit['objects']};maxerr=0
for elem in visuals+cols:
    pp=np.fromstring(elem.findtext('pose'),sep=' ');geom=elem.find('geometry')
    if geom.find('mesh') is not None:vs=meshes[root/'models'/geom.findtext('mesh/uri').removeprefix('model://')][0]
    else:
        sz=np.fromstring(geom.findtext('box/size'),sep=' ')/2;vs=np.array([(x,y,z) for x in (-sz[0],sz[0]) for y in (-sz[1],sz[1]) for z in (-sz[2],sz[2])])
    w=vs@quatmat(pp[3:]).T+pp[:3];b=records[elem.get('name')]['bounds_m'];maxerr=max(maxerr,float(np.max(np.abs(w.min(0)-b['min']))),float(np.max(np.abs(w.max(0)-b['max']))))
check('serialized_world_bbox_within_2_micrometres',maxerr<2e-6);report['max_serialized_world_bbox_error_m']=maxerr
world=E.parse(root/'worlds/rm27_battlefield.sdf').getroot();we=world.find('world');check('include_model_resource',we.findtext('include/uri')=='model://rm27_battlefield');check('no_global_offset',we.findtext('include/pose')=='0 0 0 0 0 0');check('no_added_ground_plane',not we.findall('model'));check('sensors_ogre2',any(e.findtext('render_engine')=='ogre2' for e in we.findall('plugin')))
conf=E.parse(root/'models/rm27_battlefield/model.config').getroot();check('model_config',conf.findtext('sdf')=='model.sdf')
if a.source:
    src=Path(a.source);check('pinned_xml_sha256',hashlib.sha256(src.read_bytes()).hexdigest()==audit['source_xml_sha256']);check('all_source_asset_hashes',all(hashlib.sha256((src.parent/f).read_bytes()).hexdigest()==sha for f,sha in audit['source_mesh_sha256'].items()))
# Independent file importer, if already installed. This is NOT Gazebo's ColladaLoader.
lib=ctypes.util.find_library('assimp');report['assimp_import']='not_available'
if lib:
    ass=ctypes.CDLL(lib);ass.aiImportFile.argtypes=[ctypes.c_char_p,ctypes.c_uint];ass.aiImportFile.restype=ctypes.c_void_p;ass.aiReleaseImport.argtypes=[ctypes.c_void_p];ass.aiGetErrorString.restype=ctypes.c_char_p
    for path in sorted(set(refs)):
        scene=ass.aiImportFile(str(path).encode(),0)
        if not scene:raise RuntimeError(f'Assimp rejected {path.name}: {ass.aiGetErrorString().decode()}')
        ass.aiReleaseImport(scene)
    report['assimp_import']={'unique_files_passed':len(set(refs))}
report['unique_mesh_resources']=len(set(refs));report['degenerate_visual_triangles']=degenerate_visual
if degenerate_visual:report['warnings'].append(f'{degenerate_visual} near-zero-area triangles retained from source visual geometry; no geometry cleanup applied.')
report['runtime']={'gz_available':bool(shutil.which('gz')),'ros2_available':bool(shutil.which('ros2')),'gazebo_load':'NOT_RUN','gpu_lidar':'NOT_RUN','robot_contact':'NOT_RUN','navigation':'NOT_RUN','official_sdf_schema':'NOT_RUN: libsdformat not installed; structure checked offline'}
report['passed']=all(report['checks'].values());report['check_count']=len(report['checks']);dest=Path(a.report) if a.report else root/'checks/static_validation.json';dest.write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='checks'},indent=2))
