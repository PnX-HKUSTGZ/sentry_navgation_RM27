#!/usr/bin/env bash
# On a machine with Gazebo Harmonic: run authoritative SDF checks, then start
# a headless scene. Inspect terminal logs; Ctrl+C stops it. This does not test
# a robot, GPU lidar measurements, contact quality, localization or navigation.
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
if ! command -v gz >/dev/null 2>&1; then
  echo '未找到 gz。运行验证未执行。请在已安装 Gazebo Harmonic 的机器运行。' >&2
  exit 127
fi
export GZ_SIM_RESOURCE_PATH="$ROOT/models${GZ_SIM_RESOURCE_PATH:+:$GZ_SIM_RESOURCE_PATH}"
gz sdf -k "$ROOT/models/rm27_battlefield/model.sdf"
gz sdf -k "$ROOT/worlds/rm27_battlefield.sdf"
exec gz sim -v 4 -s -r --headless-rendering "$ROOT/worlds/rm27_battlefield.sdf"
