#!/usr/bin/env python3
"""Build Gazebo Harmonic SDF from reviewed Blender visuals and original MJCF collisions.
Dependencies: Python 3, numpy, scipy. Input source must be the pinned RM27 bundle.
"""
import argparse, json, math, struct, hashlib, shutil, xml.etree.ElementTree as E
from pathlib import Path
import numpy as np
from scipy.spatial import ConvexHull
from scipy.spatial.transform import Rotation
P=argparse.ArgumentParser();P.add_argument('--source',required=True);P.add_argument('--blender-export',required=True);P.add_argument('--out',required=True);A=P.parse_args()
source=Path(A.source).resolve();inter=Path(A.blender_export).resolve();out=Path(A.out).resolve();model=out/'models/rm27_battlefield'
for d in ['meshes/visual','meshes/collision']: (model/d).mkdir(parents=True,exist_ok=True)
(out/'checks').mkdir(parents=True,exist_ok=True);(out/'worlds').mkdir(parents=True,exist_ok=True)
r=E.parse(source).getroot();assets={x.get('name'):x for x in r.find('asset').findall('mesh')}; mats={x.get('name'):x for x in r.find('asset').findall('material')}
bl=json.loads((inter/'blender_visuals.json').read_text());bo={x['name']:x for x in bl['objects']}
assert bl['source_commit']=='38230a17573816c6a46cb75c1e35a9308af0b12f'
assert hashlib.sha256(source.read_bytes()).hexdigest()=='b363ffd0c37dea3e6a78ee4881789d8a25896b67a301d5a8614d38a060b02811'
def arr(e,k,d):return np.fromstring(e.get(k,d),sep=' ')
def fmt(v):return ' '.join(format(float(x),'.12g') for x in np.asarray(v).ravel())
def tr(e):
    m=np.eye(4);m[:3,3]=arr(e,'pos','0 0 0');R=Rotation.identity()
    if e.get('quat'):
        q=arr(e,'quat','1 0 0 0');R=Rotation.from_quat(np.roll(q,-1))
    elif e.get('euler'):
        vals=arr(e,'euler','0 0 0');vals*=math.pi/180 if r.find('compiler').get('angle','degree')=='degree' else 1
        for axis,val in zip(r.find('compiler').get('eulerseq','xyz'),vals):
            rv=np.zeros(3);rv['xyz'.index(axis.lower())]=val;d=Rotation.from_rotvec(rv);R=R*d if axis.islower() else d*R
    elif e.get('axisangle'):
        aa=arr(e,'axisangle','0 0 1 0');v=aa[3]*(math.pi/180 if r.find('compiler').get('angle','degree')=='degree' else 1);R=Rotation.from_rotvec(aa[:3]/np.linalg.norm(aa[:3])*v)
    m[:3,:3]=R.as_matrix();return m
geoms=[]
def visit(el,m=np.eye(4)):
    for e in el:
        if e.tag=='body':visit(e,m@tr(e))
        elif e.tag=='geom':geoms.append((e,m@tr(e)))
visit(r.find('worldbody'))
def add(p,t,text=None,**attrs):
    e=E.SubElement(p,t,attrs)
    if text is not None:e.text=str(text)
    return e

def pose(parent,m):
    q=Rotation.from_matrix(m[:3,:3]).as_quat()
    add(parent,'pose',fmt(np.r_[m[:3,3],q]),rotation_format='quat_xyzw')

def write_xml(p,root):
    E.indent(root,space='  ');E.ElementTree(root).write(p,encoding='utf-8',xml_declaration=True)

def box_vertices(sz):return np.array([(x,y,z) for x in (-sz[0],sz[0]) for y in (-sz[1],sz[1]) for z in (-sz[2],sz[2])])

def load_src_mesh(name):
    a=assets[name]
    if a.get('file'):
        buf=(source.parent/a.get('file')).read_bytes();nv,nn,nt,nf=struct.unpack('<4i',buf[:16]);assert len(buf)==16+12*nv+12*nn+8*nt+12*nf
        v=np.frombuffer(buf,'<f4',nv*3,16).reshape(-1,3).astype(float);f=np.frombuffer(buf,'<i4',nf*3,16+12*nv+12*nn+8*nt).reshape(-1,3).copy()
        source_hashes[a.get('file')]=hashlib.sha256(buf).hexdigest()
    else:v=arr(a,'vertex','').reshape(-1,3);f=np.empty((0,3),dtype=int)
    assert not a.get('refpos') and not a.get('refquat')
    return v*arr(a,'scale','1 1 1'),f

def dae(path,vs,fs,ns,rgba):
    # COLLADA explicit Z_UP, metre unit, identity node: no implicit Blender axis conversion.
    root=E.Element('COLLADA',{'xmlns':'http://www.collada.org/2005/11/COLLADASchema','version':'1.4.1'})
    asset=add(root,'asset');con=add(asset,'contributor');add(con,'authoring_tool','RM27 reviewed Blender visual export');add(asset,'created','2026-10-07T00:00:00Z');add(asset,'modified','2026-10-07T00:00:00Z');add(asset,'unit',name='meter',meter='1');add(asset,'up_axis','Z_UP')
    fx=add(add(root,'library_effects'),'effect',id='fx');p=add(add(add(fx,'profile_COMMON'),'technique',sid='common'),'phong')
    for k,c in [('emission',[0,0,0,1]),('ambient',rgba),('diffuse',rgba),('specular',[.08,.08,.08,1])]:add(add(p,k),'color',fmt(c))
    add(add(p,'shininess'),'float','12');ma=add(add(root,'library_materials'),'material',id='mat',name='source_color');add(ma,'instance_effect',url='#fx')
    mesh=add(add(add(root,'library_geometries'),'geometry',id='geometry',name='geometry'),'mesh')
    unique, ni=np.unique(np.round(ns.astype(float),8),axis=0,return_inverse=True)
    for sid,values in [('positions',vs),('normals',unique)]:
        s=add(mesh,'source',id=sid);add(s,'float_array',fmt(values),id=sid+'-array',count=str(values.size));ac=add(add(s,'technique_common'),'accessor',source='#'+sid+'-array',count=str(len(values)),stride='3')
        for axis in 'XYZ':add(ac,'param',name=axis,type='float')
    verts=add(mesh,'vertices',id='vertices');add(verts,'input',semantic='POSITION',source='#positions')
    tri=add(mesh,'triangles',count=str(len(fs)),material='MATERIAL');add(tri,'input',semantic='VERTEX',source='#vertices',offset='0');add(tri,'input',semantic='NORMAL',source='#normals',offset='1')
    inds=np.empty((len(fs),3,2),dtype=int);inds[:,:,0]=fs;inds[:,:,1]=ni[:,None];add(tri,'p',' '.join(map(str,inds.ravel())))
    sc=add(add(root,'library_visual_scenes'),'visual_scene',id='Scene',name='Scene');node=add(sc,'node',id='Object',name='Object',type='NODE');ig=add(node,'instance_geometry',url='#geometry');tc=add(add(ig,'bind_material'),'technique_common');add(tc,'instance_material',symbol='MATERIAL',target='#mat');add(add(root,'scene'),'instance_visual_scene',url='#Scene')
    write_xml(path,root)

def hull_stl(path,vs):
    hull=ConvexHull(vs);faces=hull.simplices.copy();normals=hull.equations[:,:3]
    for i,f in enumerate(faces):
        if np.dot(np.cross(vs[f[1]]-vs[f[0]],vs[f[2]]-vs[f[0]]),normals[i])<0:faces[i,[1,2]]=faces[i,[2,1]]
    dt=np.dtype([('normal','<f4',(3,)),('vertices','<f4',(3,3)),('attr','<u2')]);data=np.zeros(len(faces),dtype=dt);data['normal']=normals;data['vertices']=vs[faces]
    path.write_bytes(b'RM27 original per-geom convex collision; metres, Z up'.ljust(80,b' ')+struct.pack('<I',len(faces))+data.tobytes())
    return hull,faces

sdf=E.Element('sdf',version='1.9');mo=add(sdf,'model',name='rm27_battlefield');add(mo,'static','true');link=add(mo,'link',name='field')
source_hashes={};vis_cache={};col_cache={};audit=[];max_err=0;v_lo=np.full(3,np.inf);v_hi=-v_lo;c_lo=v_lo.copy();c_hi=v_hi.copy()
for g,m in geoms:
    cls=g.get('class');name=g.get('name');typ=g.get('type','box');assert cls in ('visual','collision');elem=add(link,cls,name=name);pose(elem,m);geometry=add(elem,'geometry');rec={'name':name,'class':cls,'type':typ,'pose_matrix':m.tolist()}
    if cls=='visual':
        b=bo[name];bm=np.array(b['matrix_world']);max_err=max(max_err,float(np.max(np.abs(bm-m))))
        rgba=b['rgba'];material=add(elem,'material')
        for k,c in [('ambient',rgba),('diffuse',rgba),('specular',[.08,.08,.08,1]),('emissive',[0,0,0,1])]:add(material,k,fmt(c))
        add(material,'double_sided','true');metal=add(add(material,'pbr'),'metal');add(metal,'roughness',format(b['roughness'],'.9g'));add(metal,'metalness',format(b['metallic'],'.9g'));add(elem,'cast_shadows','true')
        if typ=='mesh':
            key=(b['mesh'],tuple(rgba));mi=bl['meshes'][b['mesh']];data=np.load(inter/mi['file']);vs=data['vertices'];fs=data['faces'];ns=data['normals']
            if key not in vis_cache:
                fn=f'visual_{len(vis_cache):03d}.dae';dae(model/'meshes/visual'/fn,vs,fs,ns,rgba);vis_cache[key]=fn
            uri='model://rm27_battlefield/meshes/visual/'+vis_cache[key];add(add(geometry,'mesh'),'uri',uri);src_vs,src_fs=load_src_mesh(g.get('mesh'));assert len(src_vs)==len(vs)
            max_err=max(max_err,float(np.max(np.abs(vs-src_vs))))
            rec.update(mesh_uri=uri,vertices=len(vs),triangles=len(fs),material=rgba)
        else:
            assert typ=='box';sz=arr(g,'size','');vs=box_vertices(sz);add(add(geometry,'box'),'size',fmt(sz*2));rec['size']=(sz*2).tolist()
        w=vs@m[:3,:3].T+m[:3,3];v_lo=np.minimum(v_lo,w.min(0));v_hi=np.maximum(v_hi,w.max(0))
        bd=np.load(inter/bl['meshes'][b['mesh']]['file'])['vertices'];bw=bd@bm[:3,:3].T+bm[:3,3];max_err=max(max_err,float(np.max(np.abs(w.min(0)-bw.min(0)))),float(np.max(np.abs(w.max(0)-bw.max(0)))))
    else:
        if typ=='mesh':
            key=g.get('mesh');vs,fs=load_src_mesh(key)
            if key not in col_cache:
                fn=f'collision_{len(col_cache):03d}.stl';h,hf=hull_stl(model/'meshes/collision'/fn,vs);col_cache[key]={'file':fn,'source_vertices':len(vs),'hull_vertices':len(h.vertices),'source_triangles':len(fs),'hull_triangles':len(hf),'volume_m3':h.volume}
            uri='model://rm27_battlefield/meshes/collision/'+col_cache[key]['file'];add(add(geometry,'mesh'),'uri',uri);rec.update(mesh_uri=uri,**col_cache[key])
        else:
            assert typ=='box';sz=arr(g,'size','');vs=box_vertices(sz);add(add(geometry,'box'),'size',fmt(sz*2));rec['size']=(sz*2).tolist()
        # Sliding coefficient mapped to SDF mu/mu2. MuJoCo solver and torsional/rolling friction are not equivalent.
        sf=add(elem,'surface');fr=add(sf,'friction');ode=add(fr,'ode');add(ode,'mu','0.8');add(ode,'mu2','0.8')
        w=vs@m[:3,:3].T+m[:3,3];c_lo=np.minimum(c_lo,w.min(0));c_hi=np.maximum(c_hi,w.max(0))
    rec['bounds_m']={'min':w.min(0).tolist(),'max':w.max(0).tolist()};audit.append(rec)
assert len(bo)==sum(a['class']=='visual' for a in audit)==185
assert sum(a['class']=='collision' for a in audit)==607
assert max_err<1e-5,max_err
write_xml(model/'model.sdf',sdf)
config=E.Element('model');add(config,'name','RM27 Battlefield');add(config,'version','1.0');add(config,'sdf','model.sdf',version='1.9');author=add(config,'author');add(author,'name','CosmosMount source; Gazebo conversion');add(config,'description','RM27 source geometry, reviewed Blender colors, 607 original collision proxies. Metres, Z-up, no global recentering.');write_xml(model/'model.config',config)
world=E.Element('sdf',version='1.9');we=add(world,'world',name='rm27_battlefield');ph=add(we,'physics',name='default',type='dart');add(ph,'max_step_size','0.001');add(ph,'real_time_factor','1');add(add(ph,'dart'),'collision_detector','bullet');add(we,'gravity','0 0 -9.81')
for fn,cl in [('physics','Physics'),('user-commands','UserCommands'),('scene-broadcaster','SceneBroadcaster'),('sensors','Sensors'),('imu','Imu')]:
    pl=add(we,'plugin',filename=f'gz-sim-{fn}-system',name=f'gz::sim::systems::{cl}')
    if cl=='Sensors':add(pl,'render_engine','ogre2')
scene=add(we,'scene');add(scene,'ambient','0.6 0.6 0.6 1');add(scene,'background','0.09 0.12 0.16 1');add(scene,'shadows','true')
li=add(we,'light',name='sun',type='directional');add(li,'pose','0 0 20 0 0 0');add(li,'cast_shadows','true');add(li,'diffuse','0.8 0.8 0.8 1');add(li,'specular','0.15 0.15 0.15 1');add(li,'direction','-0.4 0.1 -0.9');at=add(li,'attenuation');add(at,'range','1000');add(at,'constant','0.9');add(at,'linear','0.01');add(at,'quadratic','0.001')
inc=add(we,'include');add(inc,'uri','model://rm27_battlefield');add(inc,'name','rm27_battlefield');add(inc,'pose','0 0 0 0 0 0');write_xml(out/'worlds/rm27_battlefield.sdf',world)
report={'source_url':'https://github.com/CosmosMount/rm_mjcf/tree/38230a17573816c6a46cb75c1e35a9308af0b12f/rm27_battlefield_mjcf','source_commit':bl['source_commit'],'source_xml_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'blend_sha256':bl['blend_sha256'],'blender_version':bl['blender_version'],'visual_count':185,'collision_count':607,'visual_mesh_files':len(vis_cache),'collision_hull_files':len(col_cache),'native_visual_boxes':74,'native_collision_boxes':33,'visual_triangles':sum(a.get('triangles',12) for a in audit if a['class']=='visual'),'collision_hull_triangles_unique':sum(x['hull_triangles'] for x in col_cache.values()),'max_blender_source_bbox_or_transform_error_m':max_err,'visual_bounds_m':{'min':v_lo.tolist(),'max':v_hi.tolist()},'collision_bounds_m':{'min':c_lo.tolist(),'max':c_hi.tolist()},'geometry_policy':'Source visual topology unchanged. Each collision geom keeps its own exact vertex-set convex hull, matching MuJoCo mesh collision semantics; no hull across disconnected objects. No added support plane or studio objects.','material_policy':'Source RGBA, Blender roughness and metalness carried into Collada + SDF. Gazebo Ogre2 is not Cycles; no appearance identity claim.','physics_policy':'Static compound collisions. Sliding mu=mu2=0.8. MuJoCo solver, rolling/torsional friction not numerically equivalent.','collision_meshes':col_cache,'source_mesh_sha256':source_hashes,'objects':audit}
(out/'checks/conversion_audit.json').write_text(json.dumps(report,indent=2))
print(json.dumps({k:v for k,v in report.items() if k not in ('objects','collision_meshes','source_mesh_sha256')},indent=2))
