#!/usr/bin/env bash
# Launch the independent Gazebo Harmonic scene. Pass normal `gz sim` flags.
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
if ! command -v gz >/dev/null 2>&1; then
  echo '需要已安装的 Gazebo Harmonic (gz sim 8)。此脚本不会安装软件。' >&2
  exit 127
fi
export GZ_SIM_RESOURCE_PATH="$ROOT/models${GZ_SIM_RESOURCE_PATH:+:$GZ_SIM_RESOURCE_PATH}"
exec gz sim "$@" "$ROOT/worlds/rm27_battlefield.sdf"
