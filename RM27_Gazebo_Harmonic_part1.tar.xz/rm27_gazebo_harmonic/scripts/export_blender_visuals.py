#!/usr/bin/env python3
"""Extract only source visual objects from the reviewed Blender scene.
blender -b scene.blend --python export_blender_visuals.py -- --out intermediate
No camera, studio floor, light, modifier, decimation, or axis conversion is exported.
"""
import bpy, numpy as np, json, argparse, sys, hashlib
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--out',required=True)
a=p.parse_args(sys.argv[sys.argv.index('--')+1:]);out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
records=[]; meshes={};bpy.context.view_layer.update()
for obj in bpy.data.objects:
    if obj.type!='MESH' or obj.get('source_class')!='visual':continue
    if obj.modifiers:raise RuntimeError('Unreviewed modifiers on '+obj.name)
    mesh=obj.data
    if mesh.name not in meshes:
        mesh.calc_loop_triangles()
        vs=np.empty(len(mesh.vertices)*3,dtype=np.float32);mesh.vertices.foreach_get('co',vs);vs=vs.reshape(-1,3)
        fs=np.array([tuple(t.vertices) for t in mesh.loop_triangles],dtype=np.int32)
        ns=np.array([tuple(t.normal) for t in mesh.loop_triangles],dtype=np.float32)
        fn=f'mesh_{len(meshes):03d}.npz';np.savez_compressed(out/fn,vertices=vs,faces=fs,normals=ns)
        meshes[mesh.name]={'file':fn,'vertices':len(vs),'triangles':len(fs)}
    mat=obj.material_slots[0].material
    bs=mat.node_tree.nodes.get('Principled BSDF')
    records.append({'name':obj.get('source_geom_name'),'mesh':mesh.name,'source_mesh':obj.get('source_mesh'),'matrix_world':[list(r) for r in obj.matrix_world],'rgba':list(mat.get('source_rgba',mat.diffuse_color)),'roughness':float(bs.inputs['Roughness'].default_value),'metallic':float(bs.inputs['Metallic'].default_value),'material':mat.name})
assert len(records)==185,len(records)
report={'blender_version':bpy.app.version_string,'blend_sha256':hashlib.sha256(Path(bpy.data.filepath).read_bytes()).hexdigest(),'source_commit':bpy.context.scene.get('commit'),'objects':records,'meshes':meshes}
(out/'blender_visuals.json').write_text(json.dumps(report,indent=2))
print('EXTRACTED',len(records),'source visuals;',len(meshes),'unique meshes; studio excluded')
