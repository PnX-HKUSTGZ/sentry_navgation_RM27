# 接入 sentry_navgation_RM27：只新增场景，不替换默认世界

审计目标：`replace_gicp` 分支，提交 `b55a9d22b677f37409b60af19c8e80a6d980fdc4`。以该提交源码为准，它使用 Gazebo Harmonic / gz-sim8 / ros_gz_sim；主 README 中部分 Classic 和雷达高度描述已经过时。

## 最小改动

安装器默认只预览。加 `--apply` 才会执行：

1. 新建 `src/rm_27_stimulation/world/RM27_Blender_world/`，包含新 world、model 和全部 mesh。
2. 在 `config/worlds.yaml` 的 `worlds` 下追加 `RM27_Blender`。
3. 只有显式传入 `--spawn X Y Z YAW`，才在 `config/spawn_poses.yaml` 下追加同名出生点。

现有 YAML 内容、`default: RMUC2026`、旧 world、机器人、传感器、导航算法和所有里程计选择参数不变。不会执行 Git commit/push。已存在的新目录或同名键会报错，不覆盖。

新条目故意不写 `nav_world`。旧 `RMUC2026` 栅格、高程和 PCD 坐标不能证明与本场地对齐，直接把新场景指向旧地图会制造错误先验。详见 [坐标审计](../docs/navigation_alignment.md)。

## 安装与仅仿真验证

依赖 Python 3、PyYAML，以及目标仓库本来需要的 ROS 2 / Gazebo Harmonic 环境。以下路径替换为你实际的导航仓库根目录。

```bash
# 在本转换包根目录；第一次只检查和预览，不写目标仓库。
python3 integration/install_into_navigation.py \
  --repo /path/to/sentry_navgation_RM27 \
  --spawn -10 0 0.06 0

# 确认预览后再安装。
python3 integration/install_into_navigation.py \
  --repo /path/to/sentry_navgation_RM27 \
  --spawn -10 0 0.06 0 --apply

# 在目标 ROS workspace 根目录重新安装新增资源。
colcon build --symlink-install --packages-select rm_27_stimulation
source install/setup.bash
```

目标提交不同则 `--apply` 默认拒绝。只有自行检查新版本兼容性后，才使用 `--accept-revision-drift`。这不是对不同版本的兼容保证。

出生点 `(-10, 0, 0.06, yaw=0)` 只是离线几何检查候选：以该 XY 为中心的 0.7×0.7 m 范围、z=0.001…1.2 m 区间，没有与任何非地面 collision AABB 相交；地面顶部 z=0。原机器人轮球半径为 0.06 m，所以 base z=0.06 对应轮底接地。该检查不等于 Gazebo 接触/稳定性验收，不自动替换现有出生点，也不保证动态运动。

先只启动场景，在暂停状态插入机器人，再手动开始物理仿真检查落地：

```bash
# 终端 A
ros2 launch rm_27_stimulation rm_simulation.launch.py \
  sim_world:=RM27_Blender gui:=true pause:=true

# 终端 B，同样先 source install/setup.bash
ros2 launch rm_27_stimulation spawn_robot.launch.py \
  sim_world:=RM27_Blender spawn_delay:=0.0
```

若安装时没有传 `--spawn`，场景可启动，但机器人入口会明确报缺少同名出生点。这是预期行为。需要机器人时，第一次安装就传入经过检查的出生点；不要复制旧 `RMUC2026` 出生点。

资源 URI 被改写为 `model://RM27_Blender_world/models/rm27_battlefield/...`。现有 launch 已把包的 `world/` 加入 `GZ_SIM_RESOURCE_PATH`，因此不需要改 launch 或另设资源路径。world 名称由现有 spawn launch 从 XML 自动读取，无需硬编码 `default`。

## 启用导航前还需完成

- 为新场地生成/采集同一坐标系的占据栅格，并重新生成可通行地面的高程先验；当前旧图只有 583×300、5 cm 分辨率，覆盖范围不足。
- 对场地边界、两侧隧道口、发射区及中央机库等多处不共线地标，核对位置、方向、尺寸及高程。
- 如果选用 Point-LIO/重定位，另准备匹配的新先验 PCD，并检查初始化和 PCD 变换。该工作不由本安装器执行，也不切换现有定位开关。
- 通过 Gazebo 中的出生、传感器、边缘/坡面接触和短距离通行验收后，再明确配置新的 `nav_world`。不要为了让一键入口启动而写 `nav_world: RMUC2026`。

原高程生成器只接受直接 `ground_plane` 平面与单个 `map` STL。新场景为 include 的复合模型，不能直接把旧生成器指向新 SDF 使用。

## 本次验证范围

安装器已有 8 项本地夹具测试：dry-run 不写入、保留默认且无旧图别名、显式出生点、拒绝覆盖、拒绝异常 YAML 布局、拒绝非有限出生值、拒绝缺失 mesh、部分配置写失败回滚。完整新资源目录的临时云端接入及 URI 检查结果见 `checks/navigation_integration_test.json`。本执行环境没有 ROS/Gazebo，未声称运行仿真或导航已通过。
