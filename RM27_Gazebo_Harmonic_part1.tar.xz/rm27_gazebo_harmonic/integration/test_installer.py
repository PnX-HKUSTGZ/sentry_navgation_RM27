#!/usr/bin/env python3
"""Scene-only installer tests. Uses disposable local fixtures, no ROS or Git writes."""
import importlib.util
from pathlib import Path
import tempfile
import unittest
import xml.etree.ElementTree as ET

import yaml

SPEC = importlib.util.spec_from_file_location("installer", Path(__file__).with_name("install_into_navigation.py"))
installer = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(installer)


class InstallerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        root = Path(self.temp.name)
        self.repo, self.bundle = root / "repo", root / "bundle"
        self.pkg = self.repo / "src/rm_27_stimulation"
        (self.pkg / "config").mkdir(parents=True)
        (self.pkg / "world").mkdir()
        self.worlds = "# Existing defaults remain intact.\ndefault: RMUC2026\nworlds:\n  RMUC2026:\n    path: old/old.world\n    nav_world: RMUC2026\n"
        self.spawns = "default: RMUC2026\nspawn_poses:\n  RMUC2026: {x: -11.7, y: 2.9, z: 0.06, yaw: 0.0}\n"
        (self.pkg / "config/worlds.yaml").write_text(self.worlds)
        (self.pkg / "config/spawn_poses.yaml").write_text(self.spawns)
        model = self.bundle / "models/rm27_battlefield"
        (model / "meshes").mkdir(parents=True)
        (model / "meshes/test.stl").write_bytes(b"fixture mesh")
        (model / "model.config").write_text("<model><name>rm27_battlefield</name><sdf version='1.9'>model.sdf</sdf></model>")
        (model / "model.sdf").write_text("<sdf version='1.9'><model name='rm27_battlefield'><link name='field'><collision name='test'><geometry><mesh><uri>model://rm27_battlefield/meshes/test.stl</uri></mesh></geometry></collision></link></model></sdf>")
        (self.bundle / "worlds").mkdir()
        (self.bundle / "worlds/rm27_battlefield.sdf").write_text("<sdf version='1.9'><world name='rm27_battlefield'><include><uri>model://rm27_battlefield</uri></include></world></sdf>")

    def tearDown(self):
        self.temp.cleanup()

    def test_dry_run_no_changes(self):
        installer.prepare(self.repo, self.bundle)
        self.assertEqual((self.pkg / "config/worlds.yaml").read_text(), self.worlds)
        self.assertFalse((self.pkg / "world/RM27_Blender_world").exists())

    def test_scene_install_preserves_defaults_and_no_map_alias(self):
        installer.install(installer.prepare(self.repo, self.bundle))
        text = (self.pkg / "config/worlds.yaml").read_text()
        self.assertTrue(text.startswith(self.worlds))
        config = yaml.safe_load(text)
        self.assertEqual(config["default"], "RMUC2026")
        self.assertNotIn("nav_world", config["worlds"]["RM27_Blender"])
        self.assertEqual((self.pkg / "config/spawn_poses.yaml").read_text(), self.spawns)
        world = self.pkg / "world/RM27_Blender_world/rm27_battlefield.sdf"
        included = ET.parse(world).find("./world/include/uri").text
        self.assertEqual(included, installer.NEW_URI)
        self.assertTrue((self.pkg / "world" / included.removeprefix("model://") / "model.sdf").is_file())

    def test_explicit_spawn_only(self):
        installer.install(installer.prepare(self.repo, self.bundle, [-10.0, 0.0, 0.06, 0.0]))
        text = (self.pkg / "config/spawn_poses.yaml").read_text()
        self.assertTrue(text.startswith(self.spawns))
        config = yaml.safe_load(text)
        self.assertEqual(config["default"], "RMUC2026")
        self.assertEqual(config["spawn_poses"]["RM27_Blender"]["x"], -10.0)

    def test_refuses_overwrite(self):
        installer.install(installer.prepare(self.repo, self.bundle))
        with self.assertRaises(ValueError):
            installer.prepare(self.repo, self.bundle)

    def test_refuses_changed_yaml_layout(self):
        with self.assertRaises(ValueError):
            installer.append_mapping(self.worlds + "other: {}\n", "worlds", "NEW", {})

    def test_refuses_bad_spawn(self):
        with self.assertRaises(ValueError):
            installer.prepare(self.repo, self.bundle, [float("nan"), 0, 0, 0])

    def test_refuses_missing_mesh(self):
        (self.bundle / "models/rm27_battlefield/meshes/test.stl").unlink()
        with self.assertRaises(ValueError):
            installer.prepare(self.repo, self.bundle)

    def test_rolls_back_partial_config_failure(self):
        plan = installer.prepare(self.repo, self.bundle, [-10.0, 0.0, 0.06, 0.0])
        original_atomic = installer.atomic_text
        failed = False
        def fail_once(path, text):
            nonlocal failed
            if path.name == "spawn_poses.yaml" and not failed:
                failed = True
                raise OSError("Injected partial-write failure")
            original_atomic(path, text)
        installer.atomic_text = fail_once
        try:
            with self.assertRaises(OSError):
                installer.install(plan)
        finally:
            installer.atomic_text = original_atomic
        self.assertEqual((self.pkg / "config/worlds.yaml").read_text(), self.worlds)
        self.assertEqual((self.pkg / "config/spawn_poses.yaml").read_text(), self.spawns)
        self.assertFalse((self.pkg / "world/RM27_Blender_world").exists())
        self.assertFalse(list((self.pkg / "world").glob(".rm27-stage-*")))


if __name__ == "__main__":
    unittest.main()
