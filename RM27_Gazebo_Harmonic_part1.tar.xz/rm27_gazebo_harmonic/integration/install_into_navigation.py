#!/usr/bin/env python3
"""Opt-in, scene-only RM27 integration; dry run unless --apply is passed.

Requires Python 3 and PyYAML. Never changes launch defaults, nav maps, robot
descriptions, sensors, algorithms, localization switches, or Git state.
"""

import argparse
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import xml.etree.ElementTree as ET

import yaml


AUDITED_COMMIT = "b55a9d22b677f37409b60af19c8e80a6d980fdc4"
WORLD_KEY = "RM27_Blender"
WORLD_DIR = "RM27_Blender_world"
MODEL_NAME = "rm27_battlefield"
WORLD_FILE = "rm27_battlefield.sdf"
OLD_URI = "model://rm27_battlefield"
NEW_URI = "model://RM27_Blender_world/models/rm27_battlefield"


def append_mapping(text, root_key, key, value):
    """Append without rewriting any existing YAML text, and verify semantics."""
    old = yaml.safe_load(text)
    if not isinstance(old, dict) or not isinstance(old.get(root_key), dict):
        raise ValueError(f"Expected a {root_key} mapping")
    if key in old[root_key]:
        raise ValueError(f"Refusing to overwrite existing {root_key}.{key}")
    # The audited files end with the relevant top-level mapping. Appending to
    # a changed layout must not silently create the new key in a different map.
    block = yaml.safe_dump({key: value}, sort_keys=False, allow_unicode=True)
    addition = "\n" + "\n".join("  " + line for line in block.rstrip().splitlines()) + "\n"
    updated = text.rstrip("\n") + "\n" + addition
    expected = {**old, root_key: {**old[root_key], key: value}}
    try:
        parsed = yaml.safe_load(updated)
    except yaml.YAMLError as error:
        raise ValueError(f"Unexpected YAML layout; {root_key} must be the final root mapping") from error
    if parsed != expected:
        raise ValueError(f"Unexpected YAML layout; {root_key} must be the final root mapping")
    return updated


def validate_source(bundle):
    model = bundle / "models" / MODEL_NAME
    world = bundle / "worlds" / WORLD_FILE
    for path in (model / "model.sdf", model / "model.config", world):
        if not path.is_file():
            raise ValueError(f"Missing bundle file: {path}")
        ET.parse(path)
    if any(p.is_symlink() for p in model.rglob("*")):
        raise ValueError("Bundle model must contain regular files, not symbolic links")
    for path in (model / "model.sdf", world):
        root = ET.parse(path).getroot()
        for uri in root.iter("uri"):
            value = (uri.text or "").strip()
            if not (value == OLD_URI or value.startswith(OLD_URI + "/")):
                raise ValueError(f"Unexpected external resource URI in {path}: {value}")
            suffix = value[len(OLD_URI):].lstrip("/")
            target = (model / suffix).resolve()
            if not target.is_relative_to(model.resolve()) or not target.exists():
                raise ValueError(f"Missing or escaping resource: {value}")
    return model, world


def prepare(repo, bundle, spawn=None):
    package = repo / "src" / "rm_27_stimulation"
    config_path = package / "config" / "worlds.yaml"
    spawn_path = package / "config" / "spawn_poses.yaml"
    destination = package / "world" / WORLD_DIR
    if destination.exists():
        raise ValueError(f"Refusing to overwrite existing scene directory: {destination}")
    model, world = validate_source(bundle)
    config_text = config_path.read_text(encoding="utf-8")
    entry = {
        "path": f"{WORLD_DIR}/{WORLD_FILE}",
        "description": "RM27 Blender/MJCF scene. Navigation map alignment is not validated; no nav_world is configured.",
    }
    changes = {config_path: append_mapping(config_text, "worlds", WORLD_KEY, entry)}
    if spawn is not None:
        if not all(math.isfinite(x) for x in spawn):
            raise ValueError("Spawn coordinates must be finite")
        x, y, z, yaw = spawn
        spawn_entry = {"x": x, "y": y, "z": z, "roll": 0.0, "pitch": 0.0, "yaw": yaw}
        changes[spawn_path] = append_mapping(
            spawn_path.read_text(encoding="utf-8"), "spawn_poses", WORLD_KEY, spawn_entry
        )
    return destination, model, world, changes


def atomic_text(path, text):
    with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent, delete=False) as stream:
        tmp = Path(stream.name)
        stream.write(text)
    try:
        tmp.chmod(path.stat().st_mode & 0o777)
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def install(plan):
    destination, model, world, changes = plan
    originals = {p: p.read_text(encoding="utf-8") for p in changes}
    stage = Path(tempfile.mkdtemp(prefix=".rm27-stage-", dir=destination.parent))
    installed = False
    try:
        staged_model = stage / "models" / MODEL_NAME
        shutil.copytree(model, staged_model)
        shutil.copy2(world, stage / WORLD_FILE)
        for p in (staged_model / "model.sdf", stage / WORLD_FILE):
            text = p.read_text(encoding="utf-8").replace(OLD_URI, NEW_URI)
            ET.fromstring(text)
            p.write_text(text, encoding="utf-8")
        # Verify every rewritten resource against the exact resource root
        # appended by the existing rm_simulation.launch.py.
        for p in (staged_model / "model.sdf", stage / WORLD_FILE):
            for uri in ET.parse(p).getroot().iter("uri"):
                suffix = uri.text[len("model://" + WORLD_DIR + "/"):]
                if not (stage / suffix).exists():
                    raise ValueError(f"Unresolved staged resource: {uri.text}")
        stage.rename(destination)
        installed = True
        for path, text in changes.items():
            atomic_text(path, text)
    except BaseException:
        for path, text in originals.items():
            if path.read_text(encoding="utf-8") != text:
                atomic_text(path, text)
        if installed:
            shutil.rmtree(destination)
        raise
    finally:
        if stage.exists():
            shutil.rmtree(stage)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True, type=Path, help="Navigation repository root")
    parser.add_argument("--bundle", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--spawn", type=float, nargs=4, metavar=("X", "Y", "Z", "YAW"),
                        help="Explicitly selected and checked spawn pose; never copies the old pose")
    parser.add_argument("--apply", action="store_true", help="Write the previewed scene/config changes")
    parser.add_argument("--accept-revision-drift", action="store_true",
                        help="Permit --apply on a different repository revision after manual review")
    args = parser.parse_args()
    repo, bundle = args.repo.resolve(), args.bundle.resolve()
    plan = prepare(repo, bundle, args.spawn)
    revision = subprocess.run(["git", "-C", str(repo), "rev-parse", "HEAD"],
                              text=True, capture_output=True).stdout.strip()
    summary = {
        "mode": "apply" if args.apply else "dry-run",
        "audited_commit": AUDITED_COMMIT, "target_commit": revision or "not a Git checkout",
        "copy_scene_to": str(plan[0]), "append_config_keys": [str(p) for p in plan[3]],
        "world_key": WORLD_KEY, "nav_world": None,
        "spawn_pose": args.spawn, "existing_defaults_preserved": True,
    }
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    if args.apply:
        if revision != AUDITED_COMMIT and not args.accept_revision_drift:
            parser.error("Target revision differs from the audit. Review it before using --accept-revision-drift.")
        install(plan)
        print("Installed. Rebuild/source rm_27_stimulation before launching. Navigation remains deliberately unconfigured.")
    else:
        print("No files changed. Add --apply only after reviewing this plan.")


if __name__ == "__main__":
    main()
